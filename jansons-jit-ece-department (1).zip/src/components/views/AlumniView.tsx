import React from 'react';
import { Linkedin, Mail, MessageSquare, Award, ArrowUpRight, GraduationCap, Compass } from 'lucide-react';
import { ALUMNI_SPOTS } from '../../data/departmentData';

interface AlumniViewProps {
  highContrast: boolean;
}

export default function AlumniView({ highContrast }: AlumniViewProps) {
  return (
    <div className="py-12 px-6 sm:px-12 max-w-7xl mx-auto animate-fade-in" id="alumni-view-container">
      {/* Intro */}
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase">Worldwide Cohort</span>
        <h2 className="text-2xl sm:text-4xl font-display font-bold uppercase tracking-tight mt-1 mb-3">
          Alumni Network Portal
        </h2>
        <p className="text-xs opacity-75">
          Our global alumni footprint ranges from design teams in California, semiconductor foundries in Hsinchu, to core embedded integration houses across Bengaluru. They mentor current students and contribute to course advisory boards.
        </p>
      </div>

      {/* Spotlight Cards Grids */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        {ALUMNI_SPOTS.map((alum) => (
          <div 
            key={alum.id}
            className={`rounded-2xl border p-6 flex flex-col justify-between ${
              highContrast 
                ? 'bg-black border-yellow-400 text-yellow-400' 
                : 'bg-slate-100/50 dark:bg-slate-950 border-slate-200/50 dark:border-slate-900 shadow-sm'
            }`}
          >
            <div>
              {/* Batch info */}
              <div className="flex gap-4 items-center mb-4">
                <div className="p-2 bg-cyan-500/10 text-cyan-400 rounded-lg flex-shrink-0">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-display font-extrabold text-sm sm:text-base leading-snug">{alum.name}</h3>
                  <span className="text-[10px] font-mono font-bold text-cyan-400 block mt-0.5">{alum.batch}</span>
                </div>
              </div>

              {/* Message */}
              <p className="text-xs opacity-80 leading-relaxed italic mb-8 select-text">
                "{alum.message}"
              </p>
            </div>

            {/* Workplace metadata & linkedin */}
            <div className={`pt-3 border-t flex items-center justify-between text-xs ${
              highContrast ? 'border-yellow-400' : 'border-slate-100 dark:border-slate-900'
            }`}>
              <div>
                <span className="block text-[9px] font-mono uppercase tracking-wide opacity-60">Professional Role</span>
                <span className="font-semibold text-slate-300 truncate max-w-[150px] block">{alum.designation}</span>
                <span className="text-[10px] opacity-65">{alum.company}</span>
              </div>
              <div>
                {alum.linkedIn && (
                  <a 
                    href={alum.linkedIn} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className={`h-8 w-8 rounded-full flex items-center justify-center transition ${
                      highContrast ? 'bg-yellow-400 text-black border border-black' : 'bg-slate-900 hover:bg-slate-800 text-cyan-400'
                    }`}
                    aria-label={`LinkedIn channel for ${alum.name}`}
                  >
                    <Linkedin className="w-4 h-4" />
                  </a>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Collaborative Mentoring / Career Guide outline */}
      <div className={`p-6 rounded-2xl border ${
        highContrast ? 'border-yellow-405 text-yellow-400' : 'bg-slate-50 dark:bg-slate-900 border-slate-200/50 dark:border-slate-850 p-8 grid grid-cols-1 md:grid-cols-2 gap-8'
      }`}>
        <div>
          <Compass className="w-7 h-7 text-cyan-400 mb-3" />
          <h4 className="font-display font-bold uppercase tracking-tight text-sm text-cyan-400 mb-1">Alma-Mater Mentorship Programs</h4>
          <p className="text-xs opacity-75 leading-relaxed">
            Collaborative mentorships pair third-year ECE undergraduates with alumni advisors working in identical specialized sub-domains (e.g. ASIC layout, IoT firmware, microwave receivers) to review capstones monthly.
          </p>
        </div>

        <div className="flex flex-col gap-3 justify-center">
          <h5 className="text-[10px] font-mono uppercase tracking-widest font-bold opacity-60">Alumni Contribution Areas:</h5>
          <ul className="text-xs space-y-1.5 opacity-90 list-disc list-inside">
            <li>Guest lectures on Nano-Technology Physical Layout Tools</li>
            <li>Referral streams for industrial internships & placement drives</li>
            <li>Sponsorships for student hackathon fabrications</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
