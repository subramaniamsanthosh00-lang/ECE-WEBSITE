import React, { useState } from 'react';
import { Search, Image as ImageIcon, Camera, X, ChevronLeft, ChevronRight, SlidersHorizontal } from 'lucide-react';
import { MEDIA_GALLERY_DATA } from '../../data/departmentData';
import { MediaItem } from '../../types';

interface GalleryViewProps {
  highContrast: boolean;
}

export default function GalleryView({ highContrast }: GalleryViewProps) {
  const [activeCategory, setActiveCategory] = useState<'All' | 'Lab' | 'Event' | 'Project' | 'Campus'>('All');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const categories = ['All', 'Lab', 'Event', 'Project', 'Campus'];

  const filteredItems = MEDIA_GALLERY_DATA.filter((img) => {
    return activeCategory === 'All' || img.category === activeCategory;
  });

  const handlePrev = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex(lightboxIndex === 0 ? filteredItems.length - 1 : lightboxIndex - 1);
  };

  const handleNext = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex(lightboxIndex === filteredItems.length - 1 ? 0 : lightboxIndex + 1);
  };

  return (
    <div className="py-12 px-6 sm:px-12 max-w-7xl mx-auto animate-fade-in" id="gallery-view-container">
      {/* Intro */}
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase">Aesthetic Windows</span>
        <h2 className="text-2xl sm:text-4xl font-display font-bold uppercase tracking-tight mt-1 mb-3">
          Media Highlights Gallery
        </h2>
        <p className="text-xs opacity-75">
          Images capturing our practical sessions, guest workshops, out-station industrial visits, and student-designed robotics fabrications around the campus.
        </p>
      </div>

      {/* Filter Category pills */}
      <div className="flex flex-wrap gap-2 justify-center mb-8">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat as any)}
            className={`text-xs px-3.5 py-1.5 rounded-lg font-semibold transition ${
              activeCategory === cat
                ? highContrast ? 'bg-yellow-400 text-black font-extrabold' : 'bg-blue-600 text-white shadow'
                : 'bg-slate-50 dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800 text-slate-700 dark:text-slate-350 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {cat === 'All' ? 'View All Photos' : `${cat} Gallery`}
          </button>
        ))}
      </div>

      {/* Grid gallery layout */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" id="gallery-image-grid">
        {filteredItems.map((img, idx) => (
          <div 
            key={img.id}
            onClick={() => setLightboxIndex(idx)}
            className={`group rounded-2xl overflow-hidden border cursor-pointer relative aspect-video transition duration-300 ${
              highContrast 
                ? 'border-yellow-400' 
                : 'bg-slate-900 border-slate-105/60 dark:border-slate-900 shadow-sm hover:border-slate-400'
            }`}
          >
            <img 
              src={img.url} 
              alt={img.description} 
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover opacity-90 group-hover:opacity-100 group-hover:scale-105 transition duration-300"
            />
            {/* Hover overlay text content */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent flex flex-col justify-end p-4 opacity-0 group-hover:opacity-100 transition duration-300">
              <span className="text-[9px] font-mono font-bold bg-cyan-500 text-black px-1.5 py-0.5 rounded w-max uppercase mb-1">
                {img.category} Photo
              </span>
              <h4 className="text-xs font-bold text-white leading-tight">{img.title}</h4>
              <p className="text-[10px] text-slate-300 truncate mt-0.5">{img.description}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Accessibility Alert when lightbox is open */}
      {lightboxIndex !== null && (
        <div 
          className="fixed inset-0 z-50 bg-black/95 flex flex-col justify-center items-center p-4 animate-fade-in"
          id="gallery-lightbox-overlay"
          role="dialog"
          aria-modal="true"
        >
          {/* Controls bar */}
          <div className="absolute top-4 right-4 flex gap-4 text-white">
            <button 
              onClick={() => setLightboxIndex(null)}
              className="p-1.5 rounded-full hover:bg-slate-800"
              aria-label="Close Lightbox"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Previous / next arrows */}
          <button 
            onClick={handlePrev}
            className="absolute left-4 p-2 rounded-full hover:bg-slate-805 text-white"
            aria-label="Previous Photo"
          >
            <ChevronLeft className="w-8 h-8" />
          </button>

          <button 
            onClick={handleNext}
            className="absolute right-4 p-2 rounded-full hover:bg-slate-805 text-white"
            aria-label="Next Photo"
          >
            <ChevronRight className="w-8 h-8" />
          </button>

          {/* Image & details */}
          <div className="max-w-4xl text-center max-h-[80vh] flex flex-col justify-center">
            <img 
              src={filteredItems[lightboxIndex].url} 
              alt={filteredItems[lightboxIndex].description} 
              referrerPolicy="no-referrer"
              className="max-h-[70vh] object-contain rounded-lg mx-auto"
            />
            <div className="mt-4 text-white text-xs px-6">
              <span className="text-[9px] font-mono bg-cyan-400 text-black font-extrabold px-1.5 py-0.5 rounded uppercase">
                {filteredItems[lightboxIndex].category} Item
              </span>
              <h3 className="font-display font-extrabold text-sm md:text-base mt-2">{filteredItems[lightboxIndex].title}</h3>
              <p className="opacity-80 mt-1 max-w-md mx-auto">{filteredItems[lightboxIndex].description}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
