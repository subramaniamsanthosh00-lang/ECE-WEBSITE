import React, { useState } from 'react';
import { 
  Award, Shield, FileText, CheckCircle, HelpCircle, ArrowUpRight, 
  BookOpen, Star, DollarSign, Calendar, TrendingUp, Cpu
} from 'lucide-react';
import { RESEARCH_PORTFOLIO } from '../../data/departmentData';

interface ResearchViewProps {
  highContrast: boolean;
}

export default function ResearchView({ highContrast }: ResearchViewProps) {
  const [activeTab, setActiveTab] = useState<'areas' | 'publications' | 'patents' | 'grants'>('areas');

  const countsObj = {
    areas: RESEARCH_PORTFOLIO.areas.length,
    publications: RESEARCH_PORTFOLIO.publications.length,
    patents: RESEARCH_PORTFOLIO.patents.length,
    grants: RESEARCH_PORTFOLIO.fundedProjects.length
  };

  return (
    <div className="py-12 px-6 sm:px-12 max-w-7xl mx-auto animate-fade-in" id="research-portal-container">
      {/* Intro */}
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase">Scientific Endeavors</span>
        <h2 className="text-2xl sm:text-4xl font-display font-bold uppercase tracking-tight mt-1 mb-3">
          Research & Innovation Hub
        </h2>
        <p className="text-xs opacity-75">
          Pushing the frontiers of sub-micron circuit design, wireless antennas, and autonomous IoT architectures. The department actively executes funded consultation systems and holds several publications.
        </p>
      </div>

      {/* Selector Tabs Strip */}
      <div className={`p-2 rounded-xl mb-8 flex flex-wrap gap-2 justify-center border ${
        highContrast ? 'bg-black border-yellow-400' : 'bg-slate-50 dark:bg-slate-900 border-slate-250/40 dark:border-slate-800'
      }`}>
        {[
          { id: 'areas', label: 'Research Verticals', icon: <Cpu className="w-4 h-4" /> },
          { id: 'publications', label: `Journals (${countsObj.publications})`, icon: <BookOpen className="w-4 h-4" /> },
          { id: 'patents', label: `Patents & IP (${countsObj.patents})`, icon: <Award className="w-4 h-4" /> },
          { id: 'grants', label: `Funded Projects (${countsObj.grants})`, icon: <DollarSign className="w-4 h-4" /> }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`text-xs px-4 py-2.5 rounded-lg flex items-center gap-1.5 font-semibold transition ${
              activeTab === tab.id
                ? highContrast ? 'bg-yellow-400 text-black font-extrabold' : 'bg-blue-600 text-white shadow'
                : 'hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Area Content */}
      <div className="min-h-[400px]">
        {/* Tab 1: Research Areas */}
        {activeTab === 'areas' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {RESEARCH_PORTFOLIO.areas.map((area, idx) => (
              <div 
                key={idx} 
                className={`p-6 rounded-2xl border flex flex-col justify-between ${
                  highContrast 
                    ? 'border-yellow-400 text-yellow-400' 
                    : 'bg-slate-50 dark:bg-slate-950 border-slate-200/50 dark:border-slate-900'
                }`}
              >
                <div>
                  <div className="h-9 w-9 rounded bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-bold font-mono text-sm mb-4">
                    0{idx + 1}
                  </div>
                  <h3 className="font-display font-extrabold text-base mb-2">{area.title}</h3>
                  <p className="text-xs opacity-75 leading-relaxed mb-6">{area.description}</p>
                </div>
                <div className="border-t pt-2 mt-auto text-[10px] font-mono opacity-60">
                  Lead Coordinator: <span className="font-bold">{area.pInvestigator}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Publications List */}
        {activeTab === 'publications' && (
          <div className="flex flex-col gap-4">
            {RESEARCH_PORTFOLIO.publications.map((pub) => (
              <div 
                key={pub.id}
                className={`p-5 rounded-xl border ${
                  highContrast ? 'border-yellow-400' : 'bg-slate-100/50 dark:bg-slate-900/30 border-slate-200/40 dark:border-slate-800/60'
                }`}
              >
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-2">
                  <div className="flex flex-wrap gap-1.5">
                    <span className="text-[9px] font-mono font-bold bg-blue-100 text-blue-700 dark:bg-sky-950 dark:text-cyan-400 px-1.5 py-0.5 rounded">
                      {pub.category}
                    </span>
                    {pub.indexing.map((indx, i) => (
                      <span key={i} className="text-[9px] font-mono text-slate-500 bg-slate-200 dark:bg-slate-800 dark:text-slate-400 px-1.5 py-0.5 rounded font-semibold">
                        {indx}
                      </span>
                    ))}
                  </div>
                  <span className="text-xs font-mono font-extrabold text-cyan-400">{pub.year}</span>
                </div>
                <h3 className="text-sm font-extrabold select-all italic opacity-95">"{pub.title}"</h3>
                <p className="text-xs opacity-65 font-medium mt-1">Authors: {pub.authors.join(', ')}</p>
                <div className="flex justify-between items-center text-[10px] font-mono mt-3 opacity-60 border-t pt-2 border-slate-200 dark:border-slate-850">
                  <span>Journal: <span className="font-bold italic">{pub.journal}</span></span>
                  {pub.doi && (
                    <a 
                      href={`https://doi.org/${pub.doi}`} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="text-cyan-400 hover:underline flex items-center gap-1"
                    >
                      DOI Reference <ArrowUpRight className="w-3 h-3" />
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 3: Patents */}
        {activeTab === 'patents' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {RESEARCH_PORTFOLIO.patents.map((pat) => (
              <div 
                key={pat.id} 
                className={`p-6 rounded-2xl border flex flex-col justify-between ${
                  highContrast ? 'border-yellow-400 text-yellow-400' : 'bg-slate-900/20 border-slate-800'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded uppercase ${
                      pat.status === 'Granted' 
                        ? 'bg-emerald-500/10 text-emerald-400' 
                        : 'bg-yellow-500/10 text-yellow-400'
                    }`}>
                      Patent {pat.status}
                    </span>
                    <span className="font-mono text-xs font-bold text-slate-500">{pat.year}</span>
                  </div>
                  <h3 className="font-display font-extrabold text-sm mb-3 opacity-90 italic">"{pat.title}"</h3>
                  <p className="text-xs opacity-75">Inventors: {pat.inventors.join(', ')}</p>
                </div>
                <div className="border-t border-slate-800 pt-2 mt-4 text-[10px] font-mono opacity-65 flex justify-between items-center select-all">
                  <span>Application ID:</span>
                  <span className="font-bold text-slate-350">{pat.applicationNo}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 4: Ongoing / Completed Grants */}
        {activeTab === 'grants' && (
          <div className="flex flex-col gap-4">
            {RESEARCH_PORTFOLIO.fundedProjects.map((gp) => (
              <div 
                key={gp.id}
                className={`p-6 rounded-2xl border ${
                  highContrast ? 'border-yellow-400' : 'bg-slate-50 dark:bg-slate-950 border-slate-200/50 dark:border-slate-900'
                }`}
              >
                <div className="flex justify-between items-center mb-3">
                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${
                    gp.status === 'Ongoing' 
                      ? 'bg-amber-500/10 text-amber-500' 
                      : 'bg-emerald-500/10 text-emerald-400'
                  }`}>
                    {gp.status} Status
                  </span>
                  <span className="text-xs font-mono font-extrabold text-cyan-400 flex items-center gap-1">
                    <DollarSign className="w-3.5 h-3.5" /> {gp.amount}
                  </span>
                </div>
                <span className="text-[10px] font-mono uppercase tracking-widest opacity-60 block mb-1">
                  Funding Scheme: {gp.fundingAgency}
                </span>
                <h3 className="font-display font-bold text-sm mb-2 opacity-95">
                  {gp.title}
                </h3>
                <div className="grid grid-cols-2 gap-4 border-t pt-3 mt-4 text-xs font-mono opacity-80">
                  <div>
                    <span>Principal Investigator:</span>
                    <p className="font-bold text-slate-350">{gp.pInvestigator}</p>
                  </div>
                  <div>
                    <span>Timeline Multiplier:</span>
                    <p className="font-bold text-slate-350">{gp.duration}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Consultancy Spotlight summary card */}
      <div className={`p-6 rounded-2xl mt-12 border ${
        highContrast ? 'border-yellow-400 text-yellow-400' : 'bg-blue-600/5 border-blue-900/10 p-8 flex flex-col md:flex-row justify-between items-center gap-6'
      }`}>
        <div className="flex gap-4 items-start max-w-xl">
          <TrendingUp className="w-8 h-8 text-cyan-400 flex-shrink-0 mt-1" />
          <div>
            <h4 className="font-display font-bold uppercase tracking-tight text-sm text-cyan-400">
              Departmental Technical Consultancy
            </h4>
            <p className="text-xs opacity-75 mt-0.5 leading-relaxed">
              Jansons ECE faculty members offer consultation services under regulatory NDAs to regional electronics design houses in Coimbatore, specialising in PCB signal integrity, RF circuit layout corrections, and firmware security optimization.
            </p>
          </div>
        </div>
        <button 
          onClick={() => alert("Consultancy Brochure Requested. Redirecting...")}
          className={`px-4 py-2 rounded text-xs font-semibold whitespace-nowrap transition ${
            highContrast ? 'bg-yellow-400 text-black font-extrabold' : 'bg-slate-900 border border-slate-705 text-white hover:bg-slate-800'
          }`}
        >
          Download Consultation Brochure
        </button>
      </div>
    </div>
  );
}
