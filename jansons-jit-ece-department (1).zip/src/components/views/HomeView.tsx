import React from 'react';
import { 
  Radio, Award, BookOpen, Users, Cpu, FileText, ArrowRight, ShieldCheck, 
  Layers, Rocket, Database, Landmark, ChevronRight, Binary, Volume2
} from 'lucide-react';
import { 
  DEPARTMENT_METADATA, 
  NEWS_ANNOUNCEMENTS, 
  ACADEMIC_EVENTS, 
  VISION_MISSION 
} from '../../data/departmentData';

interface HomeViewProps {
  onNavigate: (view: string) => void;
  highContrast: boolean;
}

export default function HomeView({ onNavigate, highContrast }: HomeViewProps) {
  const stats = [
    { value: "2009", label: "Year Established", desc: "A decade of stellar growth" },
    { value: "92.5%", label: "Placement Rate", desc: "Top tech recruiters nationwide" },
    { value: "35+", label: "Research Patents & IP", desc: "Constant technological pipeline" },
    { value: "6+", label: "Core Labs", desc: "Modern Cadence & ARM testbeds" }
  ];

  const highlights = [
    {
      icon: <Cpu className="w-6 h-6 text-cyan-400" />,
      title: "VLSI System Prototyping",
      desc: "Cadence synthesis suites, transistor layout boards, and FPGA co-simulation designs.",
      page: "laboratories"
    },
    {
      icon: <Layers className="w-6 h-6 text-pink-400" />,
      title: "Funded Research Portfolio",
      desc: "Active AICTE RPS and MODROBS telemetry setups exploring multi-band RF harvesting layers.",
      page: "research"
    },
    {
      icon: <Radio className="w-6 h-6 text-indigo-400" />,
      title: "Advanced Communications",
      desc: "Millimeter wave evaluation, X-Band Microwave setups, and continuous digital optical analyzers.",
      page: "laboratories"
    }
  ];

  return (
    <div className="animate-fade-in" id="home-view-container">
      {/* 1. Hero Section */}
      <section 
        className={`relative overflow-hidden min-h-[85vh] flex items-center justify-center px-6 sm:px-12 py-16 text-center ${
          highContrast 
            ? 'bg-black text-yellow-400 border-b-2 border-yellow-400' 
            : 'bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white'
        }`}
        id="hero-section"
      >
        {/* Animated Circuit Decorative Grid Overlay */}
        <div className="absolute inset-0 opacity-20 pointer-events-none overflow-hidden" aria-hidden="true">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" strokeOpacity="0.3" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
            {/* Animated Pulsing Data Line Traces */}
            <path d="M 0 100 Q 250 50 500 200 T 1000 100 T 1500 300" fill="none" stroke="#22d3ee" strokeWidth="1.5" className="animate-pulse" />
            <path d="M 120 400 Q 300 200 680 500 T 1300 120" fill="none" stroke="#3b82f6" strokeWidth="1" />
            <circle cx="500" cy="200" r="4" fill="#06b6d4" />
            <circle cx="1000" cy="100" r="4" fill="#3b82f6" />
          </svg>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto flex flex-col items-center">
          <span className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-mono font-bold tracking-wider uppercase mb-6 ${
            highContrast ? 'bg-yellow-400 text-black' : 'bg-blue-600/10 text-cyan-400 border border-cyan-500/20'
          }`}>
            <Binary className="w-4 h-4" /> Academic Year 2026-2027 Admission Cycle
          </span>

          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-display font-extrabold tracking-tight uppercase leading-tight mb-4">
            Electronics & <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">Communication</span> Engineering
          </h2>

          <p className="text-sm sm:text-lg opacity-85 hover:opacity-100 transition max-w-2xl mb-8 leading-relaxed font-sans">
            Empowering innovative minds at Jansons Institute of Technology. Our state-of-the-art curriculum, industry-backed labs, and research focus prepare graduates to lead global digital revolutions.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => onNavigate('about')}
              className={`px-6 py-3 rounded-lg text-xs font-bold tracking-wider uppercase flex items-center gap-2 transition duration-200 ${
                highContrast 
                  ? 'bg-yellow-400 text-black border-2 border-yellow-400 font-extrabold' 
                  : 'bg-gradient-to-r from-blue-700 to-cyan-500 hover:from-blue-600 hover:to-cyan-400 text-white shadow-xl hover:shadow-cyan-500/20'
              }`}
            >
              Explore Department <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('laboratories')}
              className={`px-6 py-3 rounded-lg text-xs font-bold tracking-wider uppercase flex items-center gap-2 border transition duration-200 ${
                highContrast 
                  ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-950/40' 
                  : 'border-slate-700 text-slate-200 hover:border-slate-500 hover:bg-slate-800/50'
              }`}
            >
              Practical Labs <Cpu className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('research')}
              className={`px-6 py-3 rounded-lg text-xs font-bold tracking-wider uppercase flex items-center gap-2 border transition duration-200 ${
                highContrast 
                  ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-950/40' 
                  : 'border-slate-700 text-slate-200 hover:border-slate-500 hover:bg-slate-800/50'
              }`}
            >
              Intellectual Patents <FileText className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* 2. Key Metrics Dashboard */}
      <section className={`py-12 border-b ${
        highContrast ? 'bg-black text-yellow-400 border-yellow-400' : 'bg-slate-900/40 border-slate-800'
      }`} id="stats-strip">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 lg:grid-cols-4 gap-6 text-center">
          {stats.map((stat, idx) => (
            <div 
              key={idx} 
              className={`p-4 rounded-xl border transition-all ${
                highContrast ? 'border-yellow-400' : 'bg-slate-900/60 border-slate-800 hover:border-slate-705'
              }`}
            >
              <div className="text-3xl sm:text-4xl font-display font-extrabold text-cyan-400 tracking-tight">
                {stat.value}
              </div>
              <div className="text-xs font-bold uppercase tracking-wider text-slate-300 mt-1">
                {stat.label}
              </div>
              <div className="text-[10px] opacity-65 font-sans mt-0.5">
                {stat.desc}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Vision & Mission Section */}
      <section className="py-16 px-6 sm:px-12 max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12" id="vision-mission-section">
        <div className="flex flex-col justify-center">
          <span className="text-xs font-mono tracking-widest font-bold text-cyan-500 uppercase flex items-center gap-1.5 mb-2">
            <Landmark className="w-4 h-4" /> Institutional Intent
          </span>
          <h3 className="text-2xl sm:text-3xl font-display font-bold uppercase tracking-tight mb-6">
            Vision & Academic Framework
          </h3>
          <p className="border-l-4 border-cyan-500 pl-4 py-2 italic opacity-85 leading-relaxed text-sm mb-6 font-sans">
            "{VISION_MISSION.vision}"
          </p>
          <div className="flex flex-col gap-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-500">Program Educational Objectives (PEOs)</h4>
            <div className="flex flex-col gap-2">
              {VISION_MISSION.peos.map((peo) => (
                <div key={peo.id} className="p-3 bg-slate-100/50 dark:bg-slate-900/60 rounded border border-slate-200/50 dark:border-slate-800/50 text-xs">
                  <span className="font-bold text-cyan-500 mr-1.5">{peo.id}:</span>
                  <span className="font-semibold text-slate-700 dark:text-slate-300">{peo.title} — </span>
                  <span className="opacity-80">{peo.description}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <h4 className="text-sm font-display font-bold uppercase tracking-wider mb-2 text-cyan-400">
            Core Educational Mission Goals
          </h4>
          <div className="flex flex-col gap-4">
            {VISION_MISSION.mission.map((milestone, idx) => (
              <div key={idx} className="flex gap-4">
                <div className="h-8 w-8 rounded-full bg-blue-600/10 text-cyan-400 flex items-center justify-center font-bold text-xs flex-shrink-0">
                  {idx + 1}
                </div>
                <div>
                  <h5 className="font-semibold text-sm mb-1">Mission Strategy Step</h5>
                  <p className="text-xs opacity-80 leading-relaxed">{milestone}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Innovations / Core Highlights */}
      <section className={`py-16 px-6 sm:px-12 ${
        highContrast ? 'bg-black text-yellow-400 border-t border-b border-yellow-400' : 'bg-slate-900/30'
      }`} id="highlights-section">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-xl mx-auto mb-12">
            <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase">Highlights</span>
            <h3 className="text-2xl sm:text-3xl font-display font-bold uppercase tracking-tight mt-1 mb-3">
              Ecosystem Core Capabilities
            </h3>
            <p className="text-xs opacity-75">
              The ECE department drives student capacity building by aligning laboratories with contemporary micro-technology demands.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {highlights.map((item, idx) => (
              <div 
                key={idx}
                className={`p-6 rounded-2xl border transition-all duration-300 group ${
                  highContrast 
                    ? 'border-yellow-400 hover:bg-yellow-950/30' 
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700 hover:-translate-y-1'
                }`}
              >
                <div className="h-12 w-12 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center mb-4 group-hover:scale-110 transition duration-300">
                  {item.icon}
                </div>
                <h4 className="text-base font-bold mb-2 group-hover:text-cyan-400 transition">
                  {item.title}
                </h4>
                <p className="text-xs opacity-75 leading-relaxed mb-4">
                  {item.desc}
                </p>
                <button
                  onClick={() => onNavigate(item.page)}
                  className="text-xs font-mono font-semibold flex items-center gap-1 text-cyan-400 hover:underline group-hover:gap-2 transition-all"
                >
                  Inspect Directory <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Live Updates & Upcoming Event Previews */}
      <section className="py-16 px-6 sm:px-12 max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8" id="bulletin-section">
        {/* News Updates Panel */}
        <div className="lg:col-span-2 flex flex-col">
          <h3 className="text-lg font-display font-bold uppercase tracking-wider mb-4 border-b pb-2 flex items-center gap-2">
            📌 Recent Academic Announcements
          </h3>
          <div className="flex flex-col gap-4">
            {NEWS_ANNOUNCEMENTS.slice(0, 3).map((news) => (
              <div 
                key={news.id} 
                className={`p-4 rounded-xl border transition ${
                  highContrast 
                    ? 'border-yellow-400' 
                    : 'bg-slate-100/50 dark:bg-slate-900/40 border-slate-200/60 dark:border-slate-800/80 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded uppercase tracking-widest ${
                    news.isUrgent 
                      ? 'bg-red-500 text-white' 
                      : 'bg-blue-600/10 text-cyan-500'
                  }`}>
                    {news.category}
                  </span>
                  <span className="text-[10px] opacity-60 font-mono">{news.date}</span>
                </div>
                <h4 className="text-sm font-bold opacity-90 mb-1.5">{news.title}</h4>
                <p className="text-xs opacity-75 leading-relaxed">{news.content}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Seminar/Events preview */}
        <div className="flex flex-col">
          <h3 className="text-lg font-display font-bold uppercase tracking-wider mb-4 border-b pb-2 flex items-center gap-2">
            🗓️ Events Calendar
          </h3>
          <div className="flex flex-col gap-3">
            {ACADEMIC_EVENTS.map((evt) => (
              <div 
                key={evt.id} 
                className={`p-3 rounded-lg border flex gap-3 ${
                  highContrast ? 'border-yellow-400' : 'bg-slate-50 dark:bg-slate-900/60 border-slate-100 dark:border-slate-800/80'
                }`}
              >
                <div className={`h-11 w-11 rounded flex flex-col items-center justify-center font-mono text-[10px] leading-tight ${
                  highContrast ? 'bg-yellow-400 text-black font-bold' : 'bg-slate-900 text-cyan-400 border border-slate-800'
                }`}>
                  <span className="font-extrabold uppercase">Sept</span>
                  <span className="text-sm font-bold">24</span>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold truncate opacity-90">{evt.title}</h4>
                  <p className="text-[10px] opacity-60 mt-0.5 capitalize">Type: {evt.type}</p>
                  <button 
                    onClick={() => onNavigate('events')}
                    className="text-[10px] text-cyan-400 hover:underline font-semibold mt-1 block"
                  >
                    Details & Enrollment →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. Contact CTA Engagement block */}
      <section 
        className={`my-12 p-8 sm:p-12 rounded-3xl mx-6 sm:mx-12 text-center relative overflow-hidden ${
          highContrast 
            ? 'bg-black text-yellow-400 border-2 border-yellow-400' 
            : 'bg-gradient-to-r from-blue-900/80 via-blue-950 to-indigo-900 text-white'
        }`}
        id="cta-enrollment-banner"
      >
        <div className="relative z-10 max-w-2xl mx-auto flex flex-col items-center">
          <Award className="w-10 h-10 text-cyan-400 mb-4 animate-pulse" />
          <h3 className="text-2xl sm:text-3xl font-display font-extrabold uppercase tracking-tight mb-3">
            Build the Future in Nanometers & Gigahertz
          </h3>
          <p className="text-xs sm:text-sm opacity-85 mb-6 max-w-md">
            Whether your goal is custom IoT architectures, submicron semiconductor prototyping, or high-frequency communication receivers, we provide the platform to succeed.
          </p>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => onNavigate('contact')}
              className={`px-5 py-2.5 rounded-lg text-xs font-bold tracking-wider uppercase transition ${
                highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-500 hover:bg-cyan-600 text-black'
              }`}
            >
              Contact Admissions
            </button>
            <button
              onClick={() => onNavigate('placements')}
              className="px-5 py-2.5 rounded-lg text-xs font-mono font-bold tracking-wider uppercase bg-white/10 hover:bg-white/20 transition"
            >
              Recruiter Guide PDF
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
