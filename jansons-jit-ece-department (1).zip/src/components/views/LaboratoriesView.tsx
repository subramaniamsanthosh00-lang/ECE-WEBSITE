import React, { useState } from 'react';
import { Cpu, Users, Layers, Shield, Clock, BookOpen, MapPin, ChevronRight } from 'lucide-react';
import { LABORATORIES_DATA } from '../../data/departmentData';

interface LaboratoriesViewProps {
  highContrast: boolean;
}

export default function LaboratoriesView({ highContrast }: LaboratoriesViewProps) {
  const [activeLabId, setActiveLabId] = useState(LABORATORIES_DATA[0].id);

  const selectedLab = LABORATORIES_DATA.find((lab) => lab.id === activeLabId) || LABORATORIES_DATA[0];

  return (
    <div className="py-12 px-6 sm:px-12 max-w-7xl mx-auto animate-fade-in" id="laboratories-view-container">
      {/* Header */}
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase">Practical Pedagogy</span>
        <h2 className="text-2xl sm:text-4xl font-display font-bold uppercase tracking-tight mt-1 mb-3">
          State-of-the-Art Laboratories
        </h2>
        <p className="text-xs opacity-75">
          Engineering is best learned through doing. Our laboratories are equipped with industrial hardware setups (X-Band Microwave Benches, ARM Cortex processors, Cadence IC layouts) allowing deep engineering capabilities.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Lab List Sidebar */}
        <div className="lg:col-span-4 flex flex-col gap-2.5">
          <span className="text-xs font-mono font-bold tracking-widest text-slate-500 block uppercase mb-1.5">
            Active Research Venues
          </span>
          {LABORATORIES_DATA.map((lab) => (
            <button
              key={lab.id}
              onClick={() => setActiveLabId(lab.id)}
              className={`text-left p-4 rounded-xl border transition-all duration-200 group flex items-start gap-3.5 ${
                activeLabId === lab.id
                  ? highContrast ? 'bg-yellow-400 text-black border-yellow-400 font-extrabold' : 'bg-blue-600/10 border-blue-600/30 text-blue-600 dark:text-cyan-400'
                  : 'bg-slate-50 dark:bg-slate-950 border-slate-205/60 dark:border-slate-900 text-slate-700 dark:text-slate-350 hover:bg-slate-100 dark:hover:bg-slate-900'
              }`}
            >
              <div className="h-8 w-8 rounded bg-slate-900 border flex items-center justify-center font-bold text-xs text-cyan-400">
                <Cpu className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <h3 className="text-xs font-bold uppercase tracking-tight truncate group-hover:text-cyan-500 transition">
                  {lab.name}
                </h3>
                <p className="text-[10px] opacity-70 mt-0.5 font-mono">Location: {lab.roomNo}</p>
              </div>
            </button>
          ))}

          {/* Infrastructure support note */}
          <div className="mt-4 p-4 rounded-xl bg-slate-100/50 dark:bg-slate-900/40 p-4 border border-dashed border-slate-200 dark:border-slate-800 text-[11px] opacity-75 select-text">
            <span className="font-bold flex items-center gap-1"><Shield className="w-3.5 h-3.5" /> Safety & Accessibility Vetted</span>
            <p className="mt-1">All lab facilities comply with general fire-safety rules, house dedicated ESD safety bands, and are fully keyboard assistive for any academic evaluation cycles.</p>
          </div>
        </div>

        {/* Selected Lab Details View Panel */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {/* Photo banner and metadata */}
          <div className="relative aspect-[21/9] rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-850 bg-slate-900">
            <img 
              src={selectedLab.image} 
              alt={selectedLab.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover opacity-80" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex items-end p-6">
              <div>
                <span className="text-[10px] font-mono bg-cyan-500 text-black font-extrabold px-2 py-0.5 rounded tracking-widest uppercase">
                  ACTIVE EXPERIMENT CELL
                </span>
                <h3 className="font-display font-extrabold text-lg sm:text-2xl text-white uppercase mt-1">
                  {selectedLab.name}
                </h3>
              </div>
            </div>
          </div>

          {/* Quick Stats Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: 'Room Code', value: selectedLab.roomNo, labelIcon: <MapPin className="w-3.5 h-3.5 text-cyan-400" /> },
              { label: 'Total Capacity Area', value: `${selectedLab.areaSqM} SqM`, labelIcon: <Layers className="w-3.5 h-3.5 text-cyan-400" /> },
              { label: 'Staff Coordinator', value: selectedLab.labInCharge, labelIcon: <Users className="w-3.5 h-3.5 text-cyan-400" /> },
              { label: 'Routine Schedule', value: selectedLab.schedule || 'Regular Term Days', labelIcon: <Clock className="w-3.5 h-3.5 text-cyan-400" /> }
            ].map((fact, idx) => (
              <div 
                key={idx} 
                className={`p-3 rounded-lg border flex flex-col gap-0.5 select-text ${
                  highContrast ? 'border-yellow-400 text-yellow-400' : 'bg-slate-50 dark:bg-slate-900/60 border-slate-200/50 dark:border-slate-800'
                }`}
              >
                <span className="text-[9px] uppercase tracking-wider opacity-60 font-mono font-bold flex items-center gap-1">
                  {fact.labelIcon} {fact.label}
                </span>
                <span className="text-xs font-semibold">{fact.value}</span>
              </div>
            ))}
          </div>

          {/* Overview Statement */}
          <div className={`p-4 rounded-xl border ${
            highContrast ? 'border-yellow-400 text-yellow-400' : 'bg-slate-100/50 dark:bg-slate-900/30 border-slate-200/50 dark:border-slate-800/80'
          }`}>
            <span className="font-mono text-[9px] uppercase tracking-widest opacity-60 font-bold block mb-1">General Operations Summary</span>
            <p className="text-xs leading-relaxed opacity-90">{selectedLab.overview}</p>
          </div>

          {/* Major Equipments list */}
          <div className="overflow-hidden">
            <h4 className="text-xs font-display font-bold uppercase tracking-wider mb-3 text-cyan-400 border-b pb-1">
              🛠️ State-of-the-art Equipment List
            </h4>
            <div className="overflow-x-auto min-w-full">
              <table className="w-full text-[11px] text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/15 opacity-60 font-mono text-[10px] uppercase">
                    <th className="py-2 pr-4">Apparatus Name</th>
                    <th className="py-2 px-4">Specifications</th>
                    <th className="py-2 pl-4 text-right">Qty</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 opacity-90">
                  {selectedLab.majorEquipment.map((eq, i) => (
                    <tr key={i} className="hover:bg-slate-900/30">
                      <td className="py-2.5 pr-4 font-semibold">{eq.name}</td>
                      <td className="py-2.5 px-4 font-mono select-all opacity-85">{eq.specs}</td>
                      <td className="py-2.5 pl-4 text-right font-mono font-bold text-cyan-400">{eq.quantity}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Core Lab Experiments (Syllabus checklist) */}
          <div>
            <h4 className="text-xs font-display font-bold uppercase tracking-wider mb-2.5 text-cyan-400">
              📘 Major Curricular Experiments
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {selectedLab.experiments.map((exp, i) => (
                <div key={i} className="flex gap-2 items-start opacity-85">
                  <span className="text-cyan-400 text-sm font-bold mt-0.5">·</span>
                  <p>{exp}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Outro Outcomes checklist */}
          <div>
            <h4 className="text-xs font-display font-bold uppercase tracking-wider mb-2.5 text-cyan-400">
              🎯 Practical Learning Outcomes
            </h4>
            <div className="flex flex-col gap-2 p-4 bg-slate-950 border border-slate-900 rounded-xl">
              {selectedLab.learningOutcomes.map((out, i) => (
                <div key={i} className="flex gap-2 items-start">
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 mt-1.5 flex-shrink-0" />
                  <p className="text-[11px] opacity-80 leading-relaxed text-slate-300">{out}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
