import React, { useState } from 'react';
import { Calendar, User, UserCheck, ShieldCheck, MapPin, X, BookOpen, Volume2, Sparkles } from 'lucide-react';
import { ACADEMIC_EVENTS } from '../../data/departmentData';
import { AcademicEvent } from '../../types';

interface EventsViewProps {
  highContrast: boolean;
}

export default function EventsView({ highContrast }: EventsViewProps) {
  const [filterType, setFilterType] = useState<'All' | 'Symposium' | 'Workshop' | 'Guest Lecture'>('All');
  const [registeringEvent, setRegisteringEvent] = useState<AcademicEvent | null>(null);
  
  // Registration form state
  const [regName, setRegName] = useState('');
  const [regMail, setRegMail] = useState('');
  const [regId, setRegId] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regSuccess, setRegSuccess] = useState(false);
  const [regSubmitting, setRegSubmitting] = useState(false);

  const filteredEvents = ACADEMIC_EVENTS.filter((evt) => {
    return filterType === 'All' || evt.type === filterType;
  });

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regMail) return;
    setRegSubmitting(true);
    // Simulate interactive REST flow
    setTimeout(() => {
      setRegSubmitting(false);
      setRegSuccess(true);
      setTimeout(() => {
        setRegisteringEvent(null);
        setRegSuccess(false);
        setRegName('');
        setRegMail('');
        setRegId('');
        setRegPhone('');
      }, 2500);
    }, 1000);
  };

  return (
    <div className="py-12 px-6 sm:px-12 max-w-7xl mx-auto animate-fade-in" id="events-view-container">
      {/* Intro Header */}
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase">Scientific Gatherings</span>
        <h2 className="text-2xl sm:text-4xl font-display font-bold uppercase tracking-tight mt-1 mb-3">
          Events & Symposia Platform
        </h2>
        <p className="text-xs opacity-75">
          Connecting research with collective interaction. We regularly organize national level symposia, specialized virtual tool workshops, and guest panels featuring global IEEE researchers.
        </p>
      </div>

      {/* Selector Filters */}
      <div className="flex flex-wrap gap-2 justify-center mb-10">
        {['All', 'Symposium', 'Workshop', 'Guest Lecture'].map((type) => (
          <button
            key={type}
            onClick={() => setFilterType(type as any)}
            className={`text-xs px-3.5 py-2 rounded-lg font-semibold transition ${
              filterType === type
                ? highContrast ? 'bg-yellow-400 text-black font-extrabold' : 'bg-blue-600 text-white shadow'
                : 'bg-slate-50 dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {type === 'All' ? 'Inspect All Events' : type}
          </button>
        ))}
      </div>

      {/* Grid listing */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {filteredEvents.map((evt) => (
          <div 
            key={evt.id}
            className={`rounded-2xl border overflow-hidden flex flex-col justify-between transition duration-300 ${
              highContrast 
                ? 'bg-black border-yellow-400 text-yellow-400' 
                : 'bg-white dark:bg-slate-950 border-slate-100 dark:border-slate-900 hover:border-slate-200 dark:hover:border-slate-800'
            }`}
          >
            <div>
              {/* Photo Banner */}
              <div className="h-44 bg-slate-100 dark:bg-slate-900 overflow-hidden relative border-b border-slate-100 dark:border-slate-900">
                <img 
                  src={evt.image} 
                  alt={evt.title} 
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover opacity-90 hover:scale-105 transition duration-300"
                />
                <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur px-2.5 py-0.5 rounded text-[9px] font-mono font-bold text-cyan-400">
                  {evt.mode} Mode
                </div>
              </div>

              {/* Core Info */}
              <div className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`text-[9.5px] font-mono font-bold px-2 py-0.5 rounded tracking-wide uppercase ${
                    highContrast ? 'bg-yellow-400 text-black border border-black' : 'bg-blue-600/10 text-cyan-400'
                  }`}>
                    {evt.type}
                  </span>
                  <span className="text-[10px] font-mono text-slate-500 font-semibold">{evt.date}</span>
                </div>

                <h3 className="font-display font-extrabold text-sm md:text-base opacity-90 tracking-tight leading-snug">
                  {evt.title}
                </h3>
                <p className="text-xs opacity-75 leading-relaxed mt-2 line-clamp-3">
                  {evt.description}
                </p>

                {/* Speakers block if any */}
                {evt.speakers && evt.speakers.length > 0 && (
                  <div className="mt-4">
                    <span className="block text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold mb-1">
                      Guest Lecturer / Speaker:
                    </span>
                    <ul className="text-xs opacity-85 space-y-1">
                      {evt.speakers.map((spk, idx) => <li key={idx} className="font-semibold text-cyan-400">· {spk}</li>)}
                    </ul>
                  </div>
                )}
              </div>
            </div>

            {/* Quick action buttons */}
            <div className={`p-4 border-t flex items-center justify-between text-xs font-mono ${
              highContrast ? 'border-yellow-405' : 'border-slate-50 dark:border-slate-900/60'
            }`}>
              <div className="truncate pr-2">Coordinated by: <strong className="text-slate-300">{evt.coordinator}</strong></div>
              <div>
                {evt.registrationOpen ? (
                  <button
                    onClick={() => setRegisteringEvent(evt)}
                    className={`px-3 py-1.5 rounded transition font-bold ${
                      highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-500 hover:bg-cyan-600 text-black font-semibold'
                    }`}
                  >
                    Enroll Now
                  </button>
                ) : (
                  <span className="text-red-500 font-bold px-1 py-1">Closed</span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Registration dialog popup */}
      {registeringEvent && (
        <div 
          className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
          id="event-register-modal"
        >
          <div 
            className={`w-full max-w-md rounded-2xl p-6 shadow-2xl relative border ${
              highContrast ? 'bg-black text-yellow-400 border-yellow-400' : 'bg-slate-950 border-slate-900 text-white'
            }`}
          >
            <button
              onClick={() => setRegisteringEvent(null)}
              className="absolute right-4 top-4 p-1.5 rounded-full hover:bg-slate-800"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-xs font-mono text-cyan-400 block uppercase">
              SEAT RESERVATION PORTAL
            </span>
            <h3 className="font-display font-extrabold text-base sm:text-lg mb-2 truncate">
              {registeringEvent.title}
            </h3>

            {regSuccess ? (
              <div className="py-8 text-center flex flex-col items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
                  <UserCheck className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-sm">Enrollment Code Sanitized!</h4>
                <p className="text-xs opacity-70">
                  Confirmation token has been sent to your academic email. Present the code at the LH auditorium entry.
                </p>
              </div>
            ) : (
              <form onSubmit={handleRegisterSubmit} className="space-y-4 text-xs mt-3">
                <div className="flex flex-col gap-1">
                  <label className="font-bold uppercase tracking-wider block opacity-60 text-[9px]">Full Student Name</label>
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="Enter full name"
                    className={`p-2 rounded outline-none focus:ring-1 focus:ring-cyan-400 ${
                      highContrast ? 'bg-black border border-yellow-400 text-yellow-400' : 'bg-slate-900 border border-slate-800 text-white'
                    }`}
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <label className="font-bold uppercase tracking-wider block opacity-60 text-[9px]">Academic Institution / Roll No</label>
                  <input
                    type="text"
                    required
                    value={regId}
                    onChange={(e) => setRegId(e.target.value)}
                    placeholder="e.g. JIT ECE 2026 Roll"
                    className={`p-2 rounded outline-none ${
                      highContrast ? 'bg-black border border-yellow-400 text-yellow-400' : 'bg-slate-900 border border-slate-800 text-white'
                    }`}
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <label className="font-bold uppercase tracking-wider block opacity-60 text-[9px]">Academic Mail Address</label>
                  <input
                    type="email"
                    required
                    value={regMail}
                    onChange={(e) => setRegMail(e.target.value)}
                    placeholder="student@example.edu"
                    className={`p-2 rounded outline-none ${
                      highContrast ? 'bg-black border border-yellow-400 text-yellow-400' : 'bg-slate-900 border border-slate-800 text-white'
                    }`}
                  />
                </div>

                <button
                  type="submit"
                  disabled={regSubmitting}
                  className={`w-full py-2.5 rounded font-bold uppercase tracking-widest transition ${
                    highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-500 hover:bg-cyan-600 text-black font-semibold'
                  }`}
                >
                  {regSubmitting ? 'Registering...' : 'Sanitize & Book Seat'}
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
