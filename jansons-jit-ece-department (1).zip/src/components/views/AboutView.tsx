import React, { useState } from 'react';
import { 
  Building2, Milestone, ShieldCheck, FileCheck, Layers, BookOpen, 
  Award, Zap, Calendar, HeartHandshake, ArrowRight, Eye, Cpu, 
  Database, Settings, Play, Info, Download, CheckSquare, Plus, ChevronRight,
  Sparkles, Globe, Terminal, Users, ExternalLink, RefreshCw
} from 'lucide-react';
import { DEPARTMENT_METADATA } from '../../data/departmentData';

interface AboutViewProps {
  highContrast: boolean;
}

// Types for Roadmap Phase
interface RoadmapPhase {
  id: string;
  year: string;
  era: string;
  title: string;
  status: 'Completed' | 'Active' | 'Strategic Goal';
  desc: string;
  detailedGoals: string[];
  metricsPlaceholder: { label: string; value: string };
  ctaLabel: string;
  ctaActionId: string;
}

export default function AboutView({ highContrast }: AboutViewProps) {
  // Main Subsections Navigation toggle
  const [activeTab, setActiveTab] = useState<'profile' | 'skills' | 'roadmap' | 'cms'>('profile');

  // Interactive skills search and selection states
  const [skillsSearchQuery, setSkillsSearchQuery] = useState('');
  const [selectedSkillsCategory, setSelectedSkillsCategory] = useState<string>('All');
  const [selectedSkillDetail, setSelectedSkillDetail] = useState<{
    name: string;
    category: string;
    details: {
      labs: string[];
      semesters: string;
      competency: string;
      regulationLevel: string;
      careers: string[];
    }
  } | null>(null);

  // Deep interactive skill detailed mappings with comprehensive domain logic
  const getSkillMetaDetails = (skillName: string, categoryName: string) => {
    const defaultMeta = {
      labs: ["Analog & Digital Circuits Labs", "Embedded Systems Lab"],
      semesters: "Available starting Semester IV / V",
      competency: "Hardware Level Fabrication & Schematics Verification",
      regulationLevel: "JIT Autonomous Regulation 2021 Core",
      careers: ["Electronics Design Engineer", "IoT Systems Integrator"]
    };

    const specificMeta: Record<string, typeof defaultMeta> = {
      "Verilog HDL": {
        labs: ["VLSI Design Laboratory (LH-205)"],
        semesters: "Semester VI (Advanced Professional Core)",
        competency: "Synthesizable RTL Coding & FPGA Floorplanning, simulation, and hardware-in-the-loop validation.",
        regulationLevel: "Regulation 2021 Core (Credit Elective)",
        careers: ["VLSI Engineer", "FPGA Prototype Architect"]
      },
      "Embedded C": {
        labs: ["Embedded Systems & IoT Lab (LH-203)"],
        semesters: "Semester IV & V (Industry Core)",
        competency: "Sensing Node Interfacing & MQTT telemetry pipeline, multi-threaded task management.",
        regulationLevel: "High Core Requirement",
        careers: ["Embedded Systems Engineer", "Firmware Developer"]
      },
      "Cadence Tools": {
        labs: ["VLSI & Digital Signal Processing Lab (LH-205)"],
        semesters: "Semesters VI to VIII (Research Phase)",
        competency: "Cadence Virtuoso submicron circuit design & transistor schematics layout and design rule check (DRC).",
        regulationLevel: "Specialized Laboratory Syllabus Module",
        careers: ["Semiconductor Layout Designer", "ASIC Synthesis Engineer"]
      },
      "C Programming": {
        labs: ["Digital Programming Lab", "Embedded Systems Lab"],
        semesters: "Semester I & II (Engineering Foundation)",
        competency: "Algorithm Logic, Data Structures & Flow control execution, pointer manipulation, and memory management.",
        regulationLevel: "JIT Autonomous Foundation Syllabus",
        careers: ["Software Developer", "Firmware Programmer"]
      },
      "Microstrip Patch Antennas": {
        labs: ["Advanced Communication Systems Lab (LH-201)"],
        semesters: "Semester VII (RF Elective & Capstone Phase)",
        competency: "HFSS Simulation, return loss plots, VSWR and radiation parameters design and prototyping.",
        regulationLevel: "Advanced Wireless Elective",
        careers: ["RF Antenna Engineer", "Wireless Solutions Architect"]
      }
    };

    if (specificMeta[skillName]) {
      return specificMeta[skillName];
    }

    // Dynamic Context-Aware Generator to avoid generic placeholders for any of the skills in SKILL.md:
    let labs = ["Core Electronics Laboratory"];
    let semesters = "Semester III or IV (Foundation)";
    let competency = `In-depth practical mastery of ${skillName} with lab testing and quantitative simulation.`;
    let regulationLevel = "Autonomous Regulation 2021 Syllabus Block";
    let careers = ["Electronics Design Specialist", "Systems Integrator"];

    const nameLower = skillName.toLowerCase();
    const catLower = categoryName.toLowerCase();

    if (catLower.includes("electronics") || nameLower.includes("circuit") || nameLower.includes("analog") || nameLower.includes("pcb") || nameLower.includes("device")) {
      labs = ["Electronic Devices & Circuits Lab (LH-202)"];
      semesters = "Semester III (Core Foundation)";
      competency = `Design, breadboard prototyping, waveform verification, and hardware debugging of ${skillName} devices and circuits.`;
      careers = ["Hardware Design Engineer", "Electronic Bench Associate"];
    } else if (catLower.includes("communication") || nameLower.includes("rf") || nameLower.includes("wireless") || nameLower.includes("network") || nameLower.includes("modulation") || nameLower.includes("microwave") || nameLower.includes("satellite") || nameLower.includes("optical")) {
      labs = ["Communication Systems Laboratory (LH-201)"];
      semesters = "Semester V & VI (Advanced Communication Core)";
      competency = `Modulation testing, RF signal analysis, optical link-budget evaluation, and protocol setups for ${skillName}.`;
      careers = ["RF Wireless Specialist", "Telecom Systems Engineer"];
    } else if (catLower.includes("embedded") || nameLower.includes("microcontroller") || nameLower.includes("arduino") || nameLower.includes("sensor") || nameLower.includes("peripheral")) {
      labs = ["Embedded Systems & IoT Laboratory (LH-203)"];
      semesters = "Semester V (Professional Core)";
      competency = `Interfacing, debugging and writing low-overhead firmware drivers to program custom microcontrollers running ${skillName}.`;
      careers = ["Embedded Software Engineer", "Firmware Architect"];
    } else if (catLower.includes("iot") || nameLower.includes("smart") || nameLower.includes("cloud") || nameLower.includes("sensor net")) {
      labs = ["IoT Innovation Laboratory (LH-204)"];
      semesters = "Semester VI (Advanced Applied Core)";
      competency = `Architecting complete terminal-to-cloud telemetry pathways, configuring sensor arrays, and handling data storage for ${skillName}.`;
      careers = ["IoT Solutions Architect", "Smart Infrastructure Engineer"];
    } else if (catLower.includes("vlsi") || nameLower.includes("fpga") || nameLower.includes("asic") || nameLower.includes("hdl") || nameLower.includes("verilog") || nameLower.includes("cmos")) {
      labs = ["VLSI Design Lab (LH-205)"];
      semesters = "Semester VI & VII (Semiconductor Core)";
      competency = `Coding structural and behavioral hardware description models, validating RTL verification, and loading binary onto FPGAs to manifest ${skillName}.`;
      careers = ["Silicon Design & Verification Engineer", "ASIC Layout Designer"];
    } else if (catLower.includes("signal") || nameLower.includes("dsp") || nameLower.includes("processing") || nameLower.includes("image") || nameLower.includes("audio")) {
      labs = ["VLSI & Digital Signal Processing Lab (LH-205)"];
      semesters = "Semester V (Data Analytics Core)";
      competency = `Implementing numeric filtering routines, digital signal scaling, transform evaluation, and filter simulation for ${skillName}.`;
      careers = ["DSP Algorithmist", "Signal Integrity Analyst"];
    } else if (catLower.includes("programming") || nameLower.includes("c++") || nameLower.includes("python") || nameLower.includes("matlab")) {
      labs = ["Digital Programming & Simulation Lab"];
      semesters = "Semester I & II Engineering Foundations";
      competency = `Developing memory-efficient data arrays, object structures, algorithmic modeling, and programmatic scripts on ${skillName}.`;
      careers = ["Embedded Software Engineer", "Mathematical Simulation Analyst"];
    } else if (catLower.includes("tool") || nameLower.includes("simulink") || nameLower.includes("proteus") || nameLower.includes("multisim") || nameLower.includes("keil") || nameLower.includes("xilinx")) {
      labs = ["CAD Prototyping & EDA Environment Suite"];
      semesters = "Continuous Lab tool alignment from Semester III to VIII";
      competency = `Highly competent schematic entry, PCB circuit routing, virtual prototyping simulations, and workspace debugging utilizing ${skillName}.`;
      careers = ["EDA CAD Engineer", "Hardware Prototyping Technician"];
    } else if (catLower.includes("database") || nameLower.includes("sql") || nameLower.includes("data management")) {
      labs = ["Department Cloud Server Cell"];
      semesters = "Semester V / VI (Special Elective)";
      competency = `Structuring persistent database indexes, data tables, web serialization, and storage schema creation with ${skillName}.`;
      careers = ["Backend Database Administrator", "IoT Data Analyst"];
    } else if (catLower.includes("web") || nameLower.includes("html") || nameLower.includes("react") || nameLower.includes("node") || nameLower.includes("firebase")) {
      labs = ["Department Innovation Room"];
      semesters = "Semester V & VI Professional Pathway";
      competency = `Formulating clean web UI layouts, interactive dashboards, cloud databases, and real-time streams utilizing ${skillName}.`;
      careers = ["Web IoT Portal Architect", "Full-Stack Developer"];
    } else if (catLower.includes("laboratories") || nameLower.includes("lab")) {
      labs = [skillName];
      semesters = "Respective academic term co-requisite module";
      competency = `Conducting strict hardware calibrations, equipment operations, and formal laboratory record filings for ${skillName}.`;
      careers = ["Laboratory Superintendent", "Field Systems Support"];
    } else if (catLower.includes("competencies") || nameLower.includes("testing") || nameLower.includes("assembly")) {
      labs = ["Department Prototyping Center"];
      semesters = "All-Semester Integration Tracks";
      competency = `Soldering, oscilloscope measurement tracing, system debugging, and multi-sensor routing to establish ${skillName}.`;
      careers = ["Hardware Diagnostic Specialist", "Verification Analyst"];
    } else if (catLower.includes("smart systems") || catLower.includes("smart") || catLower.includes("automation") || catLower.includes("robot") || catLower.includes("healthcare") || catLower.includes("project")) {
      labs = ["Department Incubation Cell / Capstone Lab"];
      semesters = "Semester VII & VIII Capstone Phase";
      competency = `Translating abstract concepts into physical embedded machines, testing field performance, and public layout display of ${skillName}.`;
      careers = ["Systems Integration Analyst", "R&D Robotics Specialist"];
    } else if (catLower.includes("research") || nameLower.includes("intelligence") || nameLower.includes("learning")) {
      labs = ["Advanced Technologies Research Lab"];
      semesters = "Semester VII & VIII Core Electives";
      competency = `Synthesizing complex peer-reviewed study papers, implementing advanced software scripts, and executing parameter studies on ${skillName}.`;
      careers = ["Research Scientist", "Academic Scholar & Investigator"];
    } else if (catLower.includes("career") || catLower.includes("track")) {
      labs = ["Department Training & Placement Unit"];
      semesters = "Commences Semester V (Ongoing)";
      competency = `Gaining verified proficiency, interview simulations, and solving domain puzzles to enter the market as ${skillName}.`;
      careers = [skillName];
    } else if (catLower.includes("professional") || catLower.includes("soft") || catLower.includes("vis") || catLower.includes("workshop") || catLower.includes("internship")) {
      labs = ["Department Seminar & Placement Cell"];
      semesters = "Integrated Development Track (Semesters I-VIII)";
      competency = `Exhibiting seamless communication, structural report writing, team logistics, and structured presentation of ${skillName}.`;
      careers = ["Technical Project Manager", "Team Lead Engineer"];
    }

    return { labs, semesters, competency, regulationLevel, careers };
  };

  const eceSkillsData = [
    {
      category: "Core Technical Skills",
      icon: Cpu,
      subcategories: [
        {
          name: "Electronics Engineering",
          skills: ["Electronic Circuit Design", "Analog Electronics", "Digital Electronics", "Electronic Devices and Applications", "PCB Design and Development", "Power Electronics Fundamentals"],
          badge: "Hardware Base"
        },
        {
          name: "Communication Engineering",
          skills: ["Analog Communication Systems", "Digital Communication Systems", "Wireless Communication", "Optical Communication", "Microwave Engineering", "Satellite Communication Basics"],
          badge: "RF & Network"
        },
        {
          name: "Embedded Systems",
          skills: ["Arduino Development", "Microcontroller Programming", "Embedded C Programming", "Real-Time Embedded Systems", "Sensor Interfacing", "Industrial Automation"],
          badge: "Firmware Core"
        },
        {
          name: "Internet of Things (IoT)",
          skills: ["Smart Device Development", "IoT Sensor Networks", "Cloud-Based Monitoring Systems", "Remote Data Acquisition", "Smart Home Automation", "Smart Campus Solutions"],
          badge: "Smart Edge"
        },
        {
          name: "VLSI and Chip Design",
          skills: ["VLSI Design Fundamentals", "FPGA Programming", "ASIC Design Concepts", "CMOS Design", "Verilog HDL", "Low Power VLSI Systems"],
          badge: "Semiconductor"
        },
        {
          name: "Signal Processing",
          skills: ["Digital Signal Processing (DSP)", "Audio Signal Processing", "Image Processing Fundamentals", "Signal Analysis Techniques", "Real-Time Signal Applications"],
          badge: "DSP & MATLAB"
        },
        {
          name: "Networking and Communication",
          skills: ["Computer Networks", "Wireless Sensor Networks", "Network Protocols", "Network Security Basics", "Industrial Communication Systems"],
          badge: "Security & Protocols"
        },
        {
          name: "AI Applications",
          skills: ["Machine Learning Fundamentals", "AI-Based Monitoring Systems", "Computer Vision Applications", "Smart Surveillance Systems", "Intelligent Automation"],
          badge: "Edge AI"
        }
      ]
    },
    {
      category: "Software Skills",
      icon: Terminal,
      subcategories: [
        {
          name: "Programming Languages",
          skills: ["C Programming", "C++", "Python", "Embedded C", "MATLAB Programming"],
          badge: "Languages"
        },
        {
          name: "Development Tools",
          skills: ["Arduino IDE", "MATLAB", "Simulink", "Proteus", "Multisim", "Keil uVision", "Xilinx", "Cadence Tools"],
          badge: "EDA Toolchains"
        },
        {
          name: "Database Technologies",
          skills: ["MySQL", "SQLite", "Data Management Systems"],
          badge: "Storage Engine"
        },
        {
          name: "Web Technologies",
          skills: ["HTML5", "CSS3", "JavaScript", "React", "Node.js", "Firebase Integration"],
          badge: "Web Infrastructure"
        }
      ]
    },
    {
      category: "Laboratory Skills",
      icon: Layers,
      subcategories: [
        {
          name: "Electronics Laboratories",
          skills: ["Electronic Devices Laboratory", "Digital Electronics Laboratory", "Analog Circuits Laboratory", "Communication Engineering Laboratory"],
          badge: "Core Labs"
        },
        {
          name: "Advanced Laboratories",
          skills: ["Embedded Systems Laboratory", "VLSI Design Laboratory", "DSP Laboratory", "IoT Innovation Laboratory", "Optical Communication Laboratory", "Networking Laboratory"],
          badge: "Specialist Labs"
        },
        {
          name: "Practical Competencies",
          skills: ["Circuit Assembly", "PCB Testing", "Hardware Troubleshooting", "Sensor Calibration", "Signal Measurement", "System Integration"],
          badge: "Hands-on Skills"
        }
      ]
    },
    {
      category: "Project Development",
      icon: CheckSquare,
      subcategories: [
        {
          name: "Smart Systems",
          skills: ["Smart Energy Monitoring", "Smart Attendance Systems", "Smart Agriculture Solutions", "Smart Parking Systems", "Smart Hostel Management Systems"],
          badge: "Eco IoT"
        },
        {
          name: "Industrial Automation",
          skills: ["Automated Monitoring Systems", "Industrial Control Applications", "Wireless Automation Projects"],
          badge: "Industry 4.0"
        },
        {
          name: "Robotics",
          skills: ["Obstacle Avoidance Robots", "Autonomous Navigation Systems", "Smart Delivery Robots"],
          badge: "Mechatronics"
        },
        {
          name: "Healthcare Applications",
          skills: ["Health Monitoring Devices", "IoT-Based Medical Solutions", "Wearable Electronics"],
          badge: "Biomedical"
        }
      ]
    },
    {
      category: "Professional & Careers",
      icon: Award,
      subcategories: [
        {
          name: "Research and Innovation",
          skills: ["Internet of Things (IoT)", "Artificial Intelligence", "Machine Learning Applications", "Wireless Communication", "Embedded System Design", "VLSI Technologies", "Signal Processing", "Smart Infrastructure Development", "Industry 4.0 Solutions"],
          badge: "R&D Domains"
        },
        {
          name: "Career Tracks",
          skills: ["Electronics Design Engineer", "Embedded Systems Engineer", "IoT Developer", "VLSI Engineer", "Network Engineer", "Communication Engineer", "Software Developer", "Automation Engineer", "Research Engineer", "Technical Consultant"],
          badge: "Recruitment Roles"
        },
        {
          name: "Professional & Soft Skills",
          skills: ["Workshops", "Industrial Visits", "Internship Programs", "Industry Expert Sessions", "Certification Programs", "Leadership", "Team Collaboration", "Problem Solving", "Technical Documentation", "Project Management", "Presentation Skills"],
          badge: "Department Highlights"
        }
      ]
    }
  ];

  // Interactive state for Roadmap
  const [selectedPhaseIndex, setSelectedPhaseIndex] = useState<number>(3); // Default to current phase
  const [roadmapModalContent, setRoadmapModalContent] = useState<{
    title: string;
    description: string;
    blueprintSnippet?: string;
    indicators: string[];
  } | null>(null);

  // Interactive state for CMS strategy simulation
  const [selectedCmsModel, setSelectedCmsModel] = useState<'faculty' | 'labs' | 'events' | 'news'>('faculty');
  const [customFields, setCustomFields] = useState<string[]>(['Name', 'Designation', 'Specialization', 'OfficeMail', 'Bio']);
  const [newFieldName, setNewFieldName] = useState('');
  const [cmsWebhookStatus, setCmsWebhookStatus] = useState<'idle' | 'triggered' | 'live'>('idle');
  const [cmsApiLogs, setCmsApiLogs] = useState<string[]>([
    'GET /api/v1/faculty - 200 OK (cache HIT in 15ms)',
    'GET /api/v1/labs/embedded-lab - 200 OK (32ms)'
  ]);

  const historyMilestones = [
    { year: "2009", title: "Inception Year", desc: "The Department of Electronics and Communication Engineering was inaugurated with an initial intake of 60 undergraduate students." },
    { year: "2013", title: "Inaugural Graduation", desc: "Celebrating our first batch of graduates registering an outstanding 84% campus placement across multi-national software agencies." },
    { year: "2016", title: "Centre of Excellence", desc: "Collaborative laboratory setup with industrial hardware networks, establishing dedicated ARM Cortex microprocessing cells." },
    { year: "2021", title: "NBA Accreditation", desc: "Accredited by the National Board of Accreditation, aligning our core syllabi with AICTE Outcomes-Based Education." },
    { year: "2026", title: "B5G & IoT Lab Expansion", desc: "Deployment of state-of-the-art multi-user licensing for advanced Cadence VLSI EDA and sub-6GHz antenna verification setups." }
  ];

  const posList = [
    { num: "PO1", title: "Engineering Knowledge", desc: "Apply the knowledge of mathematics, science, engineering fundamentals, and an engineering specialization to the solution of complex engineering problems." },
    { num: "PO2", title: "Problem Analysis", desc: "Identify, formulate, review research literature, and analyze complex engineering problems reaching substantiated conclusions." },
    { num: "PO3", title: "Design/Development of Solutions", desc: "Design solutions for complex engineering problems and design system components or processes that meet the specified needs with appropriate consideration for public health and safety." },
    { num: "PO4", title: "Conduct Investigations of Complex Problems", desc: "Use research-based knowledge and research methods including design of experiments, analysis and interpretation of data, and synthesis of the information to provide valid conclusions." },
    { num: "PO5", title: "Modern Tool Usage", desc: "Create, select, and apply appropriate techniques, resources, and modern engineering and IT tools including prediction and modeling to complex engineering activities." },
    { num: "PO6", title: "The Engineer and Society", desc: "Apply reasoning informed by the contextual knowledge to assess societal, health, safety, legal and cultural issues and the consequent responsibilities." },
    { num: "PO7", title: "Environment and Sustainability", desc: "Understand the impact of the professional engineering solutions in societal and environmental contexts, and demonstrate the knowledge of, and need for sustainable development." },
    { num: "PO8", title: "Ethics", desc: "Apply ethical principles and commit to professional ethics and responsibilities and norms of the engineering practice." },
    { num: "PO9", title: "Individual and Team Work", desc: "Function effectively as an individual, and as a member or leader in diverse teams, and in multidisciplinary settings." },
    { num: "PO10", title: "Communication", desc: "Communicate effectively on complex engineering activities with the engineering community and with society at large." },
    { num: "PO11", title: "Project Management and Finance", desc: "Demonstrate knowledge and understanding of the engineering and management principles and apply these to one's own work." },
    { num: "PO12", title: "Life-long Learning", desc: "Recognize the need for, and have the preparation and ability to engage in independent and life-long learning in the broadest context of technological change." }
  ];

  const psosList = [
    { num: "PSO1", title: "Embedded & IoT Chip Synthesis", desc: "Design, verify, and implement hardware architectures using HDL toolchains and microcontrollers to realize industrial IoT control loops." },
    { num: "PSO2", title: "High-Frequency Communications", desc: "Analyze electronic components to design compact transmitter/receiver antenna models for wireless and optical systems, satisfying specified latency and bandwidth metrics." }
  ];

  // Roadmap detailed stages (Inception, Incubation, Benchmark, Current Ops, Strategic Horizon 2030)
  const roadmapPhases: RoadmapPhase[] = [
    {
      id: "PHASE-01",
      year: "2009 - 2014",
      era: "Foundational Inception",
      title: "Establishment & Syllabus Alignment",
      status: "Completed",
      desc: "Incepted with high-caliber lab benches and an intake of 60. Established basic analog communication, VLSI, and digital signal processing baseline courses with robust board-level validation.",
      detailedGoals: [
        "Inaugurated state-of-the-art DSP and Microwave benches.",
        "Syllabus alignment tailored for high-demand professional careers.",
        "Graduated 1st batch with an initial 84% campus placement record."
      ],
      metricsPlaceholder: { label: "Graduate Output", value: "240+ Engineers" },
      ctaLabel: "View Founding Charter MOU",
      ctaActionId: "charter-blueprint-2009"
    },
    {
      id: "PHASE-02",
      year: "2015 - 2019",
      era: "Core Incubation",
      title: "R&D Infrastructure & Centers of Excellence",
      status: "Completed",
      desc: "Incubated core hardware synthesis. Secured Texas Instruments, Keysight, and ARM industrial alliance models to train students on sub-micron IC layouts and RTOS nodes.",
      detailedGoals: [
        "Formed the TI Embedded Systems Design CoE Center.",
        "Published debut patents in sub-6GHz medical patch antennas.",
        "Vetted project sponsorships from Tamil Nadu State Council (TNSCST)."
      ],
      metricsPlaceholder: { label: "R&D Patents Filed", value: "8 Registered" },
      ctaLabel: "Inspect Embedded CoE Catalog",
      ctaActionId: "embedded-coe-2015"
    },
    {
      id: "PHASE-03",
      year: "2020 - 2024",
      era: "Elite Quality Standards",
      title: "NBA Tier-1 Compliance & National Awards",
      status: "Completed",
      desc: "Perfected Outcome-Based Education (OBE) mapping. Vetted by critical National Board of Accreditation (NBA) directives. Won consecutive gold and silver trophies at elite hackathons.",
      detailedGoals: [
        "Secured Tier-1 NBA Accreditation with top marks.",
        "Awarded First Prize of Rs. 1,00,000 at Smart India Hackathon.",
        "Integrated modern simulation layers (MATLAB, LabVIEW, Cadence EDA)."
      ],
      metricsPlaceholder: { label: "Average CGPA", value: "8.45 Zone Average" },
      ctaLabel: "Inspect NBA Outcome Metrics",
      ctaActionId: "nba-compliance-2021"
    },
    {
      id: "PHASE-04",
      year: "2025 - 2027",
      era: "Digital Edge Operations",
      title: "IoT smart grids, RISC-V Custom Chips & AI edge",
      status: "Active",
      desc: "Injecting modern industrial tech. Undergraduates design custom system modular microkernels, deploy edge computing nodes, and synthesize custom sub-micron circuits in advanced Labs.",
      detailedGoals: [
        "Launched RISC-V edge simulation hardware bootcamps.",
        "Expanded 100% placement-oriented micro-specializations.",
        "Implemented real-time accessibility engines for student tools."
      ],
      metricsPlaceholder: { label: "Placements Ratio", value: "92%+ Career Placement" },
      ctaLabel: "Launch Edge System Simulator",
      ctaActionId: "edge-simulation-2026"
    },
    {
      id: "PHASE-05",
      year: "2028 - 2030",
      era: "Strategic Vision 2030",
      title: "Green Semiconductor Lab & Autonomous Systems CoE",
      status: "Strategic Goal",
      desc: "Our Strategic 2030 mission. Developing a physical sub-6GHz microwave chamber, cloud-integrated clean-room testing, and robotic swarms powered by low-power LoRa telemetry arrays.",
      detailedGoals: [
        "Establish Coimbatore's finest custom chip micro-prototyping clean room.",
        "Collaborate with international foundries for double-degree streams.",
        "Zero-carbon embedded labs powered entirely by grid-level photovoltaics."
      ],
      metricsPlaceholder: { label: "Target Funding", value: "Rs. 75 Lakhs Grant Goal" },
      ctaLabel: "Explore Strategic Vision 2030 Roadmap",
      ctaActionId: "vision-horizon-2030"
    }
  ];

  // Perform Interactive actions for CTA Roadmaps
  const triggerRoadmapAction = (actionId: string, title: string) => {
    switch (actionId) {
      case "charter-blueprint-2009":
        setRoadmapModalContent({
          title: "Founding Charter MOU (2009-2010)",
          description: "This structural charter outlines JIT's primary goal: providing elite engineering training in sub-micron fabrication and signal processing. Formulated with reference to AICTE norms to bridge regional economic nodes.",
          blueprintSnippet: "OBJECTIVE_CODE: ECE_INCEPT\nMINIMUM_INTAKE: 60_PUPILS\nAFFILIATION: ANNA_UNIVERSITY_CHENNAI\nCAMPUS_COORDINATES: COIMBATORE_641659\nSTATUS: VERIFIED_FOUNDED_2009",
          indicators: ["Board of Trustees Approval", "AICTE Approval Letter", "Core Curriculum Foundation established"]
        });
        break;
      case "embedded-coe-2015":
        setRoadmapModalContent({
          title: "Embedded CoE Lab Config (2015)",
          description: "Technical configuration parameters for our Texas Instruments and ARM evaluation rooms. Provides student pathways to secure international certifications in firmware composition.",
          blueprintSnippet: "MICROCONTROLLER_CORE: ARM_Cortex_M4\nSENSORS_INTEGRATED: Analog_Telemetry_ADC\nFIRMWARE_SDK: TI_Code_Composer_Studio_v8\nPROJECTS_LOGGED: 15_STATE_FUNDED_PROTOTYPES",
          indicators: ["MOU with Texas Instruments", "Rs. 15,00,000 Hardware Vetting", "100+ Students Certified annually"]
        });
        break;
      case "nba-compliance-2021":
        setRoadmapModalContent({
          title: "NBA Compliance Matrix (2021)",
          description: "The official Outcome-Based Education (OBE) mapping used to analyze classroom performance and map final exams block grades with direct program objectives.",
          blueprintSnippet: "OBE_MODEL: DIRECT_CO_PO_MAPPING\nAUDIT_SCORE: TIER_1_OBE_APPROVED\nCONTINUOUS_ASSESSMENT: IAC_MATRIX_COMPLIANT\nFACULTY_TO_STUDENT_RATIO: 1_TO_15",
          indicators: ["Continuous IA logging verified", "12 Program Outcomes met fully", "External quality checks verified"]
        });
        break;
      case "edge-simulation-2026":
        setRoadmapModalContent({
          title: "Edge System Chip Simulator (2026)",
          description: "A sandbox environment representing our RISC-V edge computing tests. Undergraduates utilize layout tools to craft real-world VLSI designs and verify timing loops.",
          blueprintSnippet: "DESIGN_ENTITY: RISC_V_Dec_Stage\nCLOCK_FREQUENCY: 1.2_GHz_SubThreshold\nFABRICATION_GEOMETRY: TSMC_28nm_CMOS_FPGA\nTIMING_MARGINS: SLACK_POS_0.42_ns",
          indicators: ["Vercel cloud integration ready", "Microcontrollers state synced in real-time", "Cadence EDA licensing active"]
        });
        break;
      case "vision-horizon-2030":
        setRoadmapModalContent({
          title: "Strategic Horizon 2030 Blueprint",
          description: "The master planning framework for JIT ECE's future achievements. Focused heavily on physical microelectronics fabrication, IoT smart grid platforms, and zero-carbon research hubs.",
          blueprintSnippet: "HORIZON: YEAR_2030\nOBJECTIVE: 100_PERCENT_RENEWABLE_POWERED_LABS\nTARGET_IPR: 35_SCOPUS_PUBLICATIONS_YEARLY\nCOHORT: DOUBLE_DEGREE_TAIWAN_FOUNDRIES",
          indicators: ["Clean-room layout planning in progress", "Rs. 50 Lakhs extra research grant pipeline", "Autonomous drone workspace setup"]
        });
        break;
      default:
        break;
    }
  };

  // Interact Action for CMS Schema customization
  const addNewCmsField = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFieldName.trim()) return;
    if (customFields.includes(newFieldName)) return;
    setCustomFields([...customFields, newFieldName.trim()]);
    setCmsApiLogs([
      `Model Config Updated: Added field "${newFieldName.trim()}" to Schema`,
      ...cmsApiLogs
    ]);
    setNewFieldName('');
  };

  // Interact action for Triggering webhook mock deployment
  const triggerCmsWebhook = () => {
    setCmsWebhookStatus('triggered');
    setCmsApiLogs([
      'Webhook received: Deploy payload from Strapi CMS on branch "main"',
      'Initiating production build on Vercel Node Engine...',
      ...cmsApiLogs
    ]);

    setTimeout(() => {
      setCmsWebhookStatus('live');
      setCmsApiLogs([
        'Vercel Build SUCCEEDED: Static Edge Pages compiled in 420ms',
        'CDN Cache Purged across Vercel Global Edge PoPs',
        ...cmsApiLogs
      ]);
      setTimeout(() => {
        setCmsWebhookStatus('idle');
      }, 5000);
    }, 2000);
  };

  const selectedPhase = roadmapPhases[selectedPhaseIndex];

  return (
    <div className="py-12 px-6 sm:px-12 max-w-7xl mx-auto animate-fade-in" id="about-department-container">
      {/* Intro Header area */}
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase">JIT ECE CORE DATA</span>
        <h2 className="text-2xl sm:text-4xl font-display font-bold uppercase tracking-tight mt-1 mb-3">
          About our Department
        </h2>
        <p className="text-xs opacity-75">
          Outcomes-based technical training, world-class VLSI laboratories, dynamic national achievements and a state-of-the-art administrative framework matching elite Indian academic systems.
        </p>

        {/* Quad Segment Tab Controller */}
        <div className={`p-1 rounded-xl mt-8 inline-flex gap-1.5 border max-w-full overflow-x-auto ${
          highContrast ? 'border-yellow-400 bg-black' : 'bg-slate-900/40 border-slate-800'
        }`}>
          <button
            onClick={() => setActiveTab('profile')}
            className={`text-xs px-4 py-2 rounded-lg font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'profile'
                ? highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-500 text-black shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Building2 className="w-4 h-4" /> Academic Blueprint
          </button>

          <button
            onClick={() => setActiveTab('skills')}
            className={`text-xs px-4 py-2 rounded-lg font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'skills'
                ? highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-500 text-black shadow-lg font-extrabold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Cpu className="w-4 h-4" /> Skills & Expertise Portal
          </button>
          
          <button
            onClick={() => setActiveTab('roadmap')}
            className={`text-xs px-4 py-2 rounded-lg font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'roadmap'
                ? highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-500 text-black shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Milestone className="w-4 h-4" /> Interactive Roadmap (2028-2030 Plan)
          </button>

          <button
            onClick={() => setActiveTab('cms')}
            className={`text-xs px-4 py-2 rounded-lg font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'cms'
                ? highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-500 text-black shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Database className="w-4 h-4" /> CMS Integration Strategy
          </button>
        </div>
      </div>

      {/* RENDER VIEW 1: ACADEMIC PROFILE & STANDARDS */}
      {activeTab === 'profile' && (
        <div className="space-y-16 animate-fade-in">
          <section className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center" id="profile-narrative">
            <div>
              <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase flex items-center gap-1">
                <Sparkles className="w-4 h-4" /> Legacy & Mission
              </span>
              <h3 className="text-2xl sm:text-3xl font-display font-black uppercase tracking-tight mt-1 mb-4">
                Pioneering Electronics Engineering Since 2009
              </h3>
              <p className="text-xs opacity-85 leading-relaxed mb-4">
                Established with an intake of 60, the Department of Electronics and Communication Engineering at <strong>Jansons Institute of Technology</strong> has consistently set high benchmarks in technical pedagogy.
              </p>
              <p className="text-xs opacity-85 leading-relaxed">
                The department caters to a meticulously curated academic pathway accredited by both NAAC and NBA, governed under our Autonomous status. Our graduates play pivot roles in high-performance computing, automated robotics systems, nanometer semiconductor fabrication, and RF electromagnetic sensor hubs across the country.
              </p>

              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className={`p-4 rounded-xl border ${highContrast ? 'border-yellow-400' : 'bg-slate-900/20 border-white/10 backdrop-blur-md'}`}>
                  <div className="text-base font-bold text-cyan-400 flex items-center gap-1">
                    <Award className="w-4 h-4" /> Autonomous Status
                  </div>
                  <p className="text-[10px] opacity-75 uppercase tracking-wide mt-1">Independent Syllabi Industry Aligned</p>
                </div>
                <div className={`p-4 rounded-xl border ${highContrast ? 'border-yellow-400' : 'bg-slate-900/20 border-white/10 backdrop-blur-md'}`}>
                  <div className="text-base font-bold text-cyan-400 flex items-center gap-1">
                    <ShieldCheck className="w-4 h-4" /> Tier-1 NBA Accredited
                  </div>
                  <p className="text-[10px] opacity-75 uppercase tracking-wide mt-1">Outcomes-Based Education Certified</p>
                </div>
              </div>
            </div>

            {/* Static milestones summary */}
            <div className={`p-6 rounded-3xl border ${highContrast ? 'border-yellow-400 bg-black' : 'bg-slate-900/10 border-white/5'}`}>
              <h4 className="text-xs font-mono font-bold tracking-widest text-slate-400 mb-4 flex items-center gap-1.5">
                <Milestone className="w-4 h-4 text-cyan-500" /> Evolution Quick Highlights
              </h4>
              <div className="relative border-l-2 border-slate-200 dark:border-slate-800/80 pl-6 ml-2 space-y-6">
                {historyMilestones.map((milestone, idx) => (
                  <div key={idx} className="relative group text-xs text-left">
                    <span className="absolute -left-[31px] top-1 h-3 w-3 rounded-full border-2 bg-slate-950 border-cyan-400" />
                    <div>
                      <span className="font-mono text-[10px] font-bold text-cyan-400">{milestone.year}</span>
                      <h5 className="font-display font-bold mt-0.5">{milestone.title}</h5>
                      <p className="opacity-75 mt-0.5 leading-snug">{milestone.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Program outcomes matrices list */}
          <section className={`p-6 sm:p-10 rounded-3xl border ${
            highContrast ? 'bg-black border-yellow-400 text-yellow-400' : 'bg-white/5 border-white/10 backdrop-blur-xl'
          }`} id="program-outcomes-matrix">
            <div className="text-center max-w-2xl mx-auto mb-10">
              <span className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase">ACCREDITATION DIRECTIVES</span>
              <h3 className="text-xl sm:text-2xl font-display font-bold uppercase tracking-tight mt-1 mb-2">
                Program Outcomes (POs) & Specific Outcomes (PSOs)
              </h3>
              <p className="text-[11px] opacity-80 leading-relaxed">
                Our educational matrices strictly follow the twelve baseline technical parameters defined by the National Board of Accreditation, ensuring globally transferable engineering credentials for modern hardware integration houses.
              </p>
            </div>

            {/* PO grids list */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-10">
              {posList.map((po) => (
                <div 
                  key={po.num}
                  className={`p-4 rounded-xl border text-xs flex flex-col justify-between transition-all ${
                    highContrast 
                      ? 'border-yellow-400 hover:bg-yellow-950/20' 
                      : 'bg-slate-900/10 border-white/5 hover:border-white/15'
                  }`}
                >
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${
                      highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-500/10 text-cyan-400'
                    }`}>
                      {po.num}
                    </span>
                    <h4 className="font-bold uppercase tracking-wide truncate max-w-[170px]">{po.title}</h4>
                  </div>
                  <p className="opacity-75 leading-relaxed text-slate-350">{po.desc}</p>
                </div>
              ))}
            </div>

            {/* PSO Block */}
            <div className="border-t border-white/10 pt-8" id="pso-sub-block">
              <h4 className="text-xs font-display font-bold uppercase tracking-widest text-cyan-400 mb-4 flex items-center gap-1.5">
                <CheckSquare className="w-4 h-4" /> Program Specific Outcomes (PSOs)
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {psosList.map((pso) => (
                  <div 
                    key={pso.num}
                    className={`p-5 rounded-2xl border ${
                      highContrast ? 'border-yellow-400 bg-black' : 'bg-slate-950/20 border-white/5 backdrop-blur-md'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                        highContrast ? 'bg-yellow-400 text-black/80' : 'bg-cyan-500/10 text-cyan-400'
                      }`}>
                        {pso.num}
                      </span>
                      <h4 className="text-xs font-bold uppercase tracking-wide">{pso.title}</h4>
                    </div>
                    <p className="text-xs opacity-75 leading-relaxed">{pso.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Quality Assurance grids */}
          <section className="grid grid-cols-1 md:grid-cols-3 gap-8" id="quality-framework">
            <div className={`p-6 rounded-2xl border ${highContrast ? 'border-yellow-400 bg-black' : 'bg-white/5 border-white/5 backdrop-blur-xl'}`}>
              <div className="h-9 w-9 rounded bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-3">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-xs uppercase tracking-wider mb-2">Outcome-Based Evaluation</h4>
              <p className="text-[11px] opacity-75 mt-1 leading-relaxed">
                Continuous evaluation of Course Outcomes (COs) plotted against Program Outcomes (POs) monthly to fine-tune digital systems labs and physical layouts.
              </p>
            </div>

            <div className={`p-6 rounded-2xl border ${highContrast ? 'border-yellow-400 bg-black' : 'bg-white/5 border-white/5 backdrop-blur-xl'}`}>
              <div className="h-9 w-9 rounded bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-3">
                <FileCheck className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-xs uppercase tracking-wider mb-2">Internal Quality Assurance (IQAC)</h4>
              <p className="text-[11px] opacity-75 mt-1 leading-relaxed">
                Bi-annual audits of academic lesson plans, internal marks distribution, syllabus pacing registers, and laboratories log file verification.
              </p>
            </div>

            <div className={`p-6 rounded-2xl border ${highContrast ? 'border-yellow-400 bg-black' : 'bg-white/5 border-white/5 backdrop-blur-xl'}`}>
              <div className="h-9 w-9 rounded bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-3">
                <Layers className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-xs uppercase tracking-wider mb-2">Industrial Synergy Boards</h4>
              <p className="text-[11px] opacity-75 mt-1 leading-relaxed">
                Departmental advisory meet-ups including senior Robert Bosch core designers, semiconductor physical layouts advisors, and leading AI delegates.
              </p>
            </div>
          </section>
        </div>
      )}

      {/* RENDER VIEW 1.5: INTERACTIVE SKILLS & EXPERTISE PORTAL */}
      {activeTab === 'skills' && (
        <div className="space-y-12 animate-fade-in" id="skills-expertise-portal">
          {/* Section Introduction */}
          <div className="max-w-3xl mx-auto text-center space-y-4">
            <span className="text-xs font-mono font-bold tracking-widest text-[#06b6d4] uppercase flex items-center justify-center gap-1.5">
              <Sparkles className="w-4 h-4 animate-pulse" /> ECE Academic & Professional Map
            </span>
            <h3 className="text-3xl font-display font-extrabold uppercase mt-1 mb-2 text-white">
              ECE Skills, Tools & Expertise Atlas
            </h3>
            
            {/* Department Overview - Integrated directly from SKILL.md */}
            <div className={`p-6 rounded-2xl border text-left leading-relaxed ${
              highContrast ? 'border-yellow-400 bg-black text-yellow-400' : 'bg-white/5 border-white/5 backdrop-blur-md text-slate-300'
            }`}>
              <div className="flex gap-4 items-start">
                <div className="p-2.5 bg-cyan-500/10 text-cyan-400 rounded-xl flex-shrink-0 mt-1">
                  <Info className="w-5 h-5" />
                </div>
                <div className="space-y-2 text-xs">
                  <h4 className="font-bold font-mono text-white tracking-wider uppercase text-[11px]">Department Overview</h4>
                  <p>
                    The Electronics and Communication Engineering (ECE) Department is dedicated to developing innovative engineers with strong foundations in electronics, communication systems, embedded technologies, and emerging digital solutions. The department combines theoretical knowledge with practical laboratory experience, industry exposure, research activities, and project-based learning.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Search, Filter & Controls Console */}
          <div className={`p-4 rounded-3xl border text-left grid grid-cols-1 md:grid-cols-12 gap-4 items-center ${
            highContrast ? 'bg-black border-yellow-400 text-yellow-400' : 'bg-slate-900/30 border-white/10 backdrop-blur-md shadow-xl'
          }`} id="skills-catalog-console">
            {/* Search Input */}
            <div className="md:col-span-4 relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs">🔍</span>
              <input
                type="text"
                placeholder="Search skills (e.g., 'Verilog', 'PCB')..."
                value={skillsSearchQuery}
                onChange={(e) => setSkillsSearchQuery(e.target.value)}
                className={`w-full text-xs py-2.5 pl-10 pr-4 rounded-xl outline-none border transition ${
                  highContrast 
                    ? 'bg-black border-yellow-400 text-yellow-400 placeholder-yellow-600 focus:border-yellow-300' 
                    : 'bg-slate-950/60 border-white/10 text-white placeholder-slate-500 focus:border-cyan-400'
                }`}
              />
              {skillsSearchQuery && (
                <button 
                  onClick={() => setSkillsSearchQuery('')} 
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs font-bold cursor-pointer"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Category selection bar */}
            <div className="md:col-span-8 flex flex-wrap gap-1.5">
              {['All', 'Core Technical Skills', 'Software Skills', 'Laboratory Skills', 'Project Development', 'Professional & Careers'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedSkillsCategory(cat)}
                  className={`text-[11px] font-medium font-mono px-3 py-1.5 rounded-lg transition cursor-pointer ${
                    selectedSkillsCategory === cat
                      ? highContrast ? 'bg-yellow-400 text-black font-extrabold' : 'bg-cyan-500 text-black font-bold'
                      : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {cat === 'All' ? 'All Divisions' : cat}
                </button>
              ))}
            </div>
          </div>

          {/* Core Master Cards Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left box: Main Categories list */}
            <div className="lg:col-span-7 space-y-6">
              {eceSkillsData
                .filter(c => selectedSkillsCategory === 'All' || c.category === selectedSkillsCategory)
                .map((majorCat, majorIdx) => {
                  const CategoryIcon = majorCat.icon;
                  
                  return (
                    <div 
                      key={majorIdx}
                      className={`p-6 rounded-3xl border text-left transition duration-200 ${
                        highContrast ? 'bg-black border-yellow-400' : 'bg-white/5 border-white/5 backdrop-blur-xl'
                      }`}
                    >
                      {/* Header */}
                      <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-3">
                        <div className={`h-8 w-8 rounded-lg flex items-center justify-center ${
                          highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-400/10 text-cyan-400'
                        }`}>
                          <CategoryIcon className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-display font-black text-sm uppercase tracking-wide text-white">
                            {majorCat.category}
                          </h4>
                          <span className="text-[9px] font-mono opacity-50 uppercase tracking-widest block mt-0.5">Department Curriculum Focus</span>
                        </div>
                      </div>

                      {/* Subcategory map lists */}
                      <div className="space-y-4">
                        {majorCat.subcategories.map((sub, sIdx) => {
                          // Search filter
                          const filteredSkills = sub.skills.filter(sk => 
                            sk.toLowerCase().includes(skillsSearchQuery.toLowerCase()) ||
                            sub.name.toLowerCase().includes(skillsSearchQuery.toLowerCase())
                          );

                          if (skillsSearchQuery && filteredSkills.length === 0) return null;

                          return (
                            <div key={sIdx} className="space-y-2">
                              <div className="flex items-center justify-between">
                                <h5 className="text-xs font-bold text-slate-200 tracking-wide uppercase flex items-center gap-1.5">
                                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse" />
                                  {sub.name}
                                </h5>
                                <span className={`text-[8px] font-mono uppercase px-1.5 py-0.5 rounded border ${
                                  highContrast ? 'border-yellow-500 text-yellow-400' : 'bg-white/5 border-white/5 text-slate-400'
                                }`}>
                                  {sub.badge}
                                </span>
                              </div>
                              
                              <div className="flex flex-wrap gap-1.5">
                                {filteredSkills.map((sk, sKey) => {
                                  const isSelected = selectedSkillDetail?.name === sk;
                                  return (
                                    <button
                                      key={sKey}
                                      onClick={() => setSelectedSkillDetail({
                                        name: sk,
                                        category: sub.name,
                                        details: getSkillMetaDetails(sk, sub.name)
                                      })}
                                      className={`text-[11px] px-2.5 py-1 rounded-md transition duration-150 border text-left cursor-pointer ${
                                        isSelected 
                                          ? highContrast 
                                            ? 'bg-yellow-400 text-black border-black font-extrabold' 
                                            : 'bg-cyan-500 text-black border-cyan-400 font-bold scale-105 shadow-[0_0_12px_rgba(6,182,212,0.4)]'
                                          : highContrast
                                            ? 'bg-black border-yellow-800 text-yellow-500 hover:border-yellow-400'
                                            : 'bg-slate-900/60 border-white/5 text-slate-300 hover:border-white/20 hover:bg-slate-800'
                                      }`}
                                    >
                                      {sk}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
            </div>

            {/* Right block: Interactive curriculum alignment inspect box */}
            <div className="lg:col-span-5 lg:sticky lg:top-28 space-y-6 text-left">
              <div className={`p-6 rounded-3xl border text-left relative overflow-hidden ${
                highContrast ? 'bg-black border-yellow-400' : 'bg-slate-950/40 border-white/10 backdrop-blur-xl shadow-2xl'
              }`}>
                {/* Background ambient shine */}
                {!highContrast && (
                  <div className="absolute top-0 right-0 w-44 h-44 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
                )}

                {selectedSkillDetail ? (
                  <div className="space-y-5 animate-fade-in relative z-10" id="skill-inspector-dossier">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 block font-bold">
                      Interactive Competency Inspector
                    </span>
                    <div>
                      <h4 className="text-lg font-display font-extrabold uppercase leading-tight text-white mb-1">
                        {selectedSkillDetail.name}
                      </h4>
                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-white/5 border border-white/5 text-slate-400">
                        {selectedSkillDetail.category}
                      </span>
                    </div>

                    <div className="border-t border-white/5 pt-4 space-y-4">
                      {/* Curricular Lab */}
                      <div>
                        <span className="block text-[9px] font-mono uppercase opacity-50 mb-1 font-bold">Associated Department Labs:</span>
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {selectedSkillDetail.details.labs.map((lb, idx) => (
                            <span key={idx} className="inline-block text-[11px] text-cyan-300 font-semibold bg-cyan-950/40 px-2 py-1 rounded">
                              🧪 {lb}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Term Sequence */}
                      <div>
                        <span className="block text-[9px] font-mono uppercase opacity-50 mb-1 font-bold">Recommended Study Term:</span>
                        <p className="text-xs text-slate-300">
                          📅 {selectedSkillDetail.details.semesters}
                        </p>
                      </div>

                      {/* Standards Regulation Level */}
                      <div>
                        <span className="block text-[9px] font-mono uppercase opacity-50 mb-1 font-bold">Academic Compliance Level:</span>
                        <p className="text-xs text-indigo-300 font-medium">
                          📜 {selectedSkillDetail.details.regulationLevel}
                        </p>
                      </div>

                      {/* Skill verification */}
                      <div>
                        <span className="block text-[9px] font-mono uppercase opacity-50 mb-1 font-bold">Practical Output Competency:</span>
                        <p className="text-xs text-slate-300 leading-relaxed italic bg-slate-900/60 p-2.5 rounded-lg border border-white/5 font-mono text-[10.5px]">
                          💬 {selectedSkillDetail.details.competency}
                        </p>
                      </div>

                      {/* Career opportunities */}
                      <div>
                        <span className="block text-[9px] font-mono uppercase opacity-50 mb-1 font-bold">Primary Job Placements Target:</span>
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {selectedSkillDetail.details.careers.map((role, idx) => (
                            <span key={idx} className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                              💼 {role}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-white/5 pt-4 flex gap-2">
                      <a
                        href="#/laboratories"
                        className={`text-center py-2 rounded-xl text-[10.5px] uppercase font-bold tracking-wider transition-all flex-1 ${
                          highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-500 hover:bg-cyan-600 text-black font-extrabold flex items-center justify-center gap-1 hover:scale-105'
                        }`}
                      >
                        Explore Benches →
                      </a>
                      <button
                        onClick={() => setSelectedSkillDetail(null)}
                        className="p-2 border border-white/10 rounded-xl hover:bg-white/5 text-slate-400 text-xs font-semibold px-3 cursor-pointer"
                      >
                        Reset Inspector
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-10 space-y-4 font-mono text-xs text-slate-400 select-none">
                    <div className="text-3xl text-slate-600 animate-bounce">🛠</div>
                    <p className="px-6 font-display font-medium leading-relaxed text-slate-300">
                      Select any individual skill badge on the left panel (e.g. <strong>Verilog HDL</strong>, <strong>Embedded C</strong>, <strong>Cadence Tools</strong>, or <strong>Microstrip Patch Antennas</strong>) to load dynamic curriculum blueprints, laboratory mappings, and placement targets.
                    </p>
                  </div>
                )}
              </div>

              {/* Department Skills Highlight Stats Box */}
              <div className={`p-5 rounded-3xl border text-left ${
                highContrast ? 'bg-black border-yellow-400 text-yellow-400' : 'bg-gradient-to-br from-indigo-950/20 to-slate-900/40 border-white/5'
              }`}>
                <h5 className="text-[10px] font-mono font-bold tracking-widest uppercase text-indigo-400 mb-2">
                  Syllabus Highlights Integration
                </h5>
                <ul className="space-y-2 text-[11px] leading-relaxed opacity-90 text-slate-350">
                  <li className="flex gap-1.5 items-start">
                    <span className="text-cyan-400">✔</span> 
                    <span><strong>Autonomous Curriculum & Regulation aligned</strong> with robust credits for practical board prototyping.</span>
                  </li>
                  <li className="flex gap-1.5 items-start">
                    <span className="text-cyan-400">✔</span>
                    <span><strong>100% Core Hardware-in-Loop laboratories focus</strong> ensuring industry training on Xilinx & Cadence toolchains.</span>
                  </li>
                  <li className="flex gap-1.5 items-start">
                    <span className="text-cyan-400">✔</span>
                    <span><strong>Direct Placement micro-certifications integrated</strong> in modern IoT, Autonomous Robots, and Edge systems.</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Section 7. Career Opportunities Grid (integrated from SKILL.md) */}
          <div className="space-y-6 pt-6 text-left border-t border-white/5">
            <div className="max-w-2xl">
              <span className="text-[10px] font-mono font-bold tracking-widest text-[#06b6d4] uppercase">SECTION 7</span>
              <h4 className="text-xl font-display font-black text-white uppercase mt-1">
                Graduates Career Opportunities
              </h4>
              <p className="text-xs opacity-75 mt-1 leading-relaxed text-slate-300">
                Graduates from the ECE Department are thoroughly prepared with industry-aligned competencies, allowing them to excel directly in engineering, design, and analysis roles:
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4">
              {[
                { title: "Electronics Design Engineer", desc: "Developing schematics, testing analog layout filters, and engineering core hardware.", tag: "Hardware Core" },
                { title: "Embedded Systems Engineer", desc: "Developing low-level firmware in C/C++, sensor interfacing and hardware calibration.", tag: "Firmware" },
                { title: "IoT Developer", desc: "Constructing secure device networks, cloud messaging gateways, and sensor monitoring.", tag: "Smart Systems" },
                { title: "VLSI Engineer", desc: "Writing synthesizable Verilog, performing static timing analysis, and testing FPGA blueprints.", tag: "Semiconductor" },
                { title: "Network Engineer", desc: "Configuring telecom routing, managing high-security firewalls, and debugging protocols.", tag: "Infrastructure" },
                { title: "Communication Engineer", desc: "Designing microwave transmitters, optical linkages, and optimizing radio coverage.", tag: "RF Linkages" },
                { title: "Software Developer", desc: "Creating fullstack programs, processing scientific data models, and API integrations.", tag: "Computing" },
                { title: "Automation Engineer", desc: "Designing PLC ladders, SCADA controls, and integrating automated conveyor setups.", tag: "Industry 4.0" },
                { title: "Research Engineer", desc: "Simulating signal models, leading grant audits, and filing intellectual patents.", tag: "R&D" },
                { title: "Technical Consultant", desc: "Diagnosing client system architecture, presenting solutions, and reviewing specifications.", tag: "Consultative" }
              ].map((role, idx) => (
                <div 
                  key={idx}
                  onClick={() => setSelectedSkillDetail({
                    name: role.title,
                    category: "Career Tracks",
                    details: getSkillMetaDetails(role.title, "Career Tracks")
                  })}
                  className={`p-4 rounded-2xl border text-left flex flex-col justify-between hover:scale-103 hover:border-cyan-400 group cursor-pointer transition-all duration-200 ${
                    selectedSkillDetail?.name === role.title
                      ? highContrast ? 'bg-yellow-400 text-black border-black' : 'bg-cyan-950/40 border-cyan-400 shadow-md'
                      : highContrast ? 'bg-black border-yellow-800 text-yellow-500' : 'bg-white/5 border-white/5'
                  }`}
                >
                  <div className="space-y-2">
                    <span className={`text-[8px] font-mono uppercase px-1.5 py-0.5 rounded ${
                      highContrast ? 'bg-yellow-400/20 text-yellow-400' : 'bg-indigo-500/10 text-[#a5b4fc]'
                    }`}>
                      {role.tag}
                    </span>
                    <h5 className="font-bold text-xs text-white leading-tight mt-1 group-hover:text-cyan-300">
                      {role.title}
                    </h5>
                    <p className="text-[10px] opacity-75 leading-relaxed text-slate-300">
                      {role.desc}
                    </p>
                  </div>
                  <div className="text-[10px] font-mono text-cyan-400 text-right mt-3 font-semibold group-hover:underline">
                    Inspect Path →
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 8. Department Highlights (integrated from SKILL.md) */}
          <div className="space-y-6 pt-6 text-left border-t border-white/5">
            <div className="max-w-2xl">
              <span className="text-[10px] font-mono font-bold tracking-widest text-[#06b6d4] uppercase">SECTION 8</span>
              <h4 className="text-xl font-display font-black text-white uppercase mt-1">
                ECE Department Highlights & Outcomes
              </h4>
              <p className="text-xs opacity-75 mt-1 leading-relaxed text-slate-300">
                The continuous pursuit of academic excellence, student support, and engineering leadership is anchored in several institutional pillars:
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: "Industry-Oriented Curriculum", desc: "Rigorous syllabus elements mapped alongside emerging industrial demands to minimize training-to-work gaps.", icon: BookOpen },
                { title: "Modern Laboratory Facilities", desc: "Complete workbench hardware instrumentation, dynamic RF analyzers, plus licensed, industry-standard EDA tools.", icon: Layers },
                { title: "Innovation-Driven Projects", desc: "Developing real-world devices, medical monitors, obstacle-avoiding robots, and industrial IoT controls.", icon: Zap },
                { title: "Research Opportunities", desc: "Undergraduate guidance to publish abstracts in notable journals and draft functional layout patents.", icon: Award },
                { title: "Internship Support", desc: "Active guidance and pipelines linking students with tier-1 electronics, firmware, and compiler engineering corporations.", icon: Building2 },
                { title: "Placement Training Programs", desc: "Micro-credentials, dedicated coding challenges, and mock tech interviews commencing from early semesters.", icon: CheckSquare },
                { title: "Technical Competitions", desc: "Directing student involvement in national hackathons, robotic showcases, and paper presentations.", icon: Milestone },
                { title: "Entrepreneurship Development", desc: "Mentoring systems helping engineering students turn academic prototypes into industrial patents and startups.", icon: Sparkles }
              ].map((hl, idx) => {
                const HighlightIcon = hl.icon;
                return (
                  <div 
                    key={idx}
                    className={`p-5 rounded-2xl border text-left space-y-3 ${
                      highContrast ? 'border-yellow-450 bg-black text-yellow-400' : 'bg-slate-900/30 border-white/5'
                    }`}
                  >
                    <div className="h-8 w-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
                      <HighlightIcon className="w-5 h-5" />
                    </div>
                    <div className="space-y-1">
                      <h5 className="font-bold text-xs text-white uppercase tracking-wider">{hl.title}</h5>
                      <p className="text-[11px] opacity-75 leading-relaxed text-slate-300">{hl.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* RENDER VIEW 2: INTERACTIVE ROADMAP VISUALIZATION (Milestones & Goals) */}
      {activeTab === 'roadmap' && (
        <div className="space-y-12 animate-fade-in" id="interactive-roadmap-section">
          {/* Section Introduction */}
          <div className="max-w-2xl mx-auto text-center">
            <span className="text-xs font-mono font-bold tracking-widest text-[#06b6d4] uppercase flex items-center justify-center gap-1.5">
              <Milestone className="w-4 h-4 animate-bounce" /> History to Horizon
            </span>
            <h3 className="text-2xl font-display font-extrabold uppercase mt-1 mb-2">
              JIT ECE Strategic Roadmap
            </h3>
            <p className="text-xs opacity-75 leading-relaxed">
              Explore our journey from inception in 2009 to our critical Strategic 2030 initiatives. Click any era nodes below to inspect the detailed goals, performance metrics, and trigger interactive simulations.
            </p>
          </div>

          {/* Horizontally Stepped Interactive Node Selector */}
          <div className="relative max-w-4xl mx-auto py-8">
            {/* Background alignment line */}
            <div className={`absolute left-0 right-0 top-1/2 -translate-y-1/2 h-1 ${
              highContrast ? 'bg-yellow-400' : 'bg-slate-800'
            }`} />
            
            {/* Dynamic progress highlight indicator */}
            <div 
              className={`absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-cyan-500 transition-all duration-500`}
              style={{ width: `${(selectedPhaseIndex / (roadmapPhases.length - 1)) * 100}%` }}
            />

            {/* Stepper nodes bubbles */}
            <div className="relative flex justify-between items-center px-4 sm:px-10">
              {roadmapPhases.map((phase, idx) => {
                const isActive = selectedPhaseIndex === idx;
                const isCompleted = phase.status === 'Completed';
                
                return (
                  <button
                    key={phase.id}
                    onClick={() => setSelectedPhaseIndex(idx)}
                    className="flex flex-col items-center group relative focus:outline-none transition-all duration-300"
                    aria-label={`Select Era ${phase.year}`}
                  >
                    {/* Node bubble */}
                    <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-full border-2 flex items-center justify-center z-10 transition-all duration-300 ${
                      isActive
                        ? highContrast 
                          ? 'bg-yellow-400 border-black text-black scale-125' 
                          : 'bg-cyan-500 border-cyan-400 text-black scale-125 shadow-[0_0_20px_rgba(6,182,212,0.6)]'
                        : isCompleted
                          ? highContrast ? 'bg-black border-yellow-400 text-yellow-500' : 'bg-slate-900 border-cyan-500 text-cyan-400'
                          : highContrast ? 'bg-black border-yellow-800 text-yellow-800' : 'bg-slate-950 border-slate-700 text-slate-500'
                    }`}>
                      {isActive ? (
                        <Sparkles className="w-5 h-5 animate-spin" />
                      ) : (
                        <span className="text-[10px] sm:text-xs font-bold font-mono">{phase.year.split(' ')[0]}</span>
                      )}
                    </div>

                    {/* Timeline labels beneath */}
                    <span className={`text-[10px] font-mono mt-2 absolute top-12 font-bold tracking-tight whitespace-nowrap transition-colors ${
                      isActive ? 'text-cyan-400' : 'text-slate-400 group-hover:text-white'
                    }`}>
                      {phase.era}
                    </span>

                    {/* Status badge floating on top */}
                    <span className={`absolute -top-6 text-[8px] font-mono uppercase px-1 rounded border tracking-wide whitespace-nowrap transition-all opacity-0 group-hover:opacity-100 ${
                      phase.status === 'Completed' ? 'text-emerald-400 border-emerald-500/30' : phase.status === 'Active' ? 'text-cyan-400 border-cyan-500/30' : 'text-yellow-400 border-yellow-500/30'
                    }`}>
                      {phase.status}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ACTIVE STEP DETAILS CARD LAYOUT */}
          <div className="pt-8 max-w-4xl mx-auto">
            <div className={`p-6 sm:p-8 rounded-3xl border transition-all duration-300 grid grid-cols-1 md:grid-cols-12 gap-8 ${
              highContrast ? 'bg-black border-yellow-400 text-yellow-400' : 'bg-white/5 border-white/10 backdrop-blur-xl shadow-2xl relative overflow-hidden'
            }`}>
              
              {/* Background ambient shade layout (Vercel style) */}
              {!highContrast && (
                <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-[80px]" />
              )}

              {/* Left detail Column: text narrative */}
              <div className="md:col-span-8 flex flex-col justify-between text-left relative z-10">
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    <span className="font-mono text-xs font-extrabold text-cyan-400 tracking-wider">ERA LEVEL: {selectedPhase.id}</span>
                    <span className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded border font-semibold ${
                      selectedPhase.status === 'Completed' 
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                        : selectedPhase.status === 'Active'
                          ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20 animate-pulse'
                          : 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
                    }`}>
                      {selectedPhase.status} Status
                    </span>
                  </div>

                  <h4 className="text-xl sm:text-2xl font-display font-extrabold uppercase mt-1 leading-snug">
                    {selectedPhase.title} ({selectedPhase.year})
                  </h4>
                  <p className="text-xs opacity-85 leading-relaxed mt-2.5 mb-6 select-text text-slate-300">
                    {selectedPhase.desc}
                  </p>

                  <h5 className="text-[10px] font-mono uppercase tracking-widest font-bold opacity-60 mb-2">Key Targeted Accomplishments:</h5>
                  <ul className="space-y-2 mb-6">
                    {selectedPhase.detailedGoals.map((goal, idx) => (
                      <li key={idx} className="flex gap-2 items-start text-xs text-slate-305">
                        <CheckSquare className="w-4 h-4 text-[#06b6d4] flex-shrink-0 mt-0.5" />
                        <span>{goal}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Primary Action Button (CTA) */}
                <div className="mt-4 pt-4 border-t border-white/5 flex flex-col sm:flex-row gap-3 items-center justify-between">
                  <span className="text-[11px] font-mono text-slate-400">
                    Simulation data prepared for review.
                  </span>
                  <button
                    onClick={() => triggerRoadmapAction(selectedPhase.ctaActionId, selectedPhase.title)}
                    className={`px-5 py-2.5 rounded-xl font-bold uppercase text-xs tracking-wider transition-all flex items-center gap-2 ${
                      highContrast 
                        ? 'bg-yellow-400 text-black shadow-[0_5px_0_rgba(255,255,255,1)]' 
                        : 'bg-cyan-500 text-black hover:bg-cyan-400 font-bold shadow-[0_4px_14px_rgba(6,182,212,0.3)] hover:scale-105'
                    }`}
                  >
                    <Terminal className="w-4 h-4" /> {selectedPhase.ctaLabel}
                  </button>
                </div>
              </div>

              {/* Right Column: Key metrics indicators */}
              <div className="md:col-span-4 flex flex-col justify-between gap-4 text-center items-center relative z-10">
                {/* Metric circular dial card */}
                <div className={`p-6 rounded-2xl w-full border flex flex-col items-center justify-center ${
                  highContrast ? 'border-yellow-400' : 'bg-slate-900/30 border-white/5 backdrop-blur-md'
                }`}>
                  <span className="text-[10px] font-mono opacity-60 uppercase block mb-1">
                    {selectedPhase.metricsPlaceholder.label}
                  </span>
                  <div className="text-3xl font-display font-extrabold text-[#06b6d4]">
                    {selectedPhase.metricsPlaceholder.value}
                  </div>
                  <div className="mt-2 text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-white/5 text-slate-400 border border-white/5">
                    Verified Record
                  </div>
                </div>

                {/* Status indicator tracker block */}
                <div className={`p-4 rounded-xl text-left w-full border text-xs leading-relaxed ${
                  highContrast ? 'border-yellow-400' : 'bg-slate-900/20 border-white/5'
                }`}>
                  <h5 className="font-bold uppercase tracking-wider text-[9px] text-[#06b6d4] mb-1">DEPLOYMENT FOCUS</h5>
                  <p className="opacity-80">This milestone data represents standard outcome achievements logged dynamically inside JIT administrative files.</p>
                </div>
              </div>

            </div>
          </div>

          {/* INTERACTIVE COMPONENT DETAILS MODAL SIMULATOR */}
          {roadmapModalContent && (
            <div 
              className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
              role="dialog"
              aria-modal="true"
              id="roadmap-interactive-dossier"
            >
              <div className={`w-full max-w-xl rounded-3xl p-6 shadow-2xl relative border ${
                highContrast ? 'bg-black text-yellow-400 border-yellow-400' : 'bg-slate-950 border-white/10 text-white'
              }`}>
                {/* Cancel button */}
                <button
                  onClick={() => setRoadmapModalContent(null)}
                  className="absolute right-4 top-4 p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white"
                  aria-label="Close details"
                >
                  <XIcon />
                </button>

                <span className="text-[10px] font-mono uppercase tracking-widest text-[#06b6d4] block">
                  INTERACTIVE DETAILED DOSSIER
                </span>
                <h4 className="text-lg font-display font-extrabold uppercase mt-1 mb-3">
                  {roadmapModalContent.title}
                </h4>
                <p className="text-xs opacity-85 leading-relaxed mb-4">
                  {roadmapModalContent.description}
                </p>

                {/* Simulated Payload registry block */}
                {roadmapModalContent.blueprintSnippet && (
                  <div className="mb-4">
                    <span className="block text-[9px] font-mono opacity-60 uppercase mb-1">Simulated Registry Metadata:</span>
                    <pre className="p-3 rounded-lg bg-slate-900 text-[11px] font-mono text-cyan-400 border border-slate-800 overflow-x-auto text-left leading-tight">
                      {roadmapModalContent.blueprintSnippet}
                    </pre>
                  </div>
                )}

                {/* Quality checks */}
                <h5 className="text-[10px] font-mono uppercase tracking-widest opacity-60 mb-1.5 font-bold">Verifiable Indicators:</h5>
                <ul className="text-xs space-y-1.5 opacity-90 text-left mb-6">
                  {roadmapModalContent.indicators.map((chk, idx) => (
                    <li key={idx} className="flex gap-2 items-center text-slate-300">
                      <div className="w-1.5 h-1.5 rounded-full bg-cyan-500" />
                      <span>{chk}</span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => setRoadmapModalContent(null)}
                  className={`w-full py-2.5 rounded-xl font-bold uppercase text-xs tracking-wider transition ${
                    highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-500 hover:bg-cyan-600 text-black'
                  }`}
                >
                  Return to Roadmap Stepper
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* RENDER VIEW 3: HEADLESS CMS INTEGRATION STRATEGY */}
      {activeTab === 'cms' && (
        <div className="space-y-12 animate-fade-in" id="headless-cms-dashboard">
          {/* Section introduction */}
          <div className="max-w-2xl mx-auto text-center">
            <span className="text-xs font-mono font-bold tracking-widest text-indigo-400 uppercase flex items-center justify-center gap-1.5">
              <Database className="w-4 h-4" /> Headless Architecture
            </span>
            <h3 className="text-2xl font-display font-extrabold uppercase mt-1 mb-2">
              JIT ECE CMS Integration Strategy
            </h3>
            <p className="text-xs opacity-75">
              A comprehensive blueprints to link a decapitated Content Management System (headless Strapi or Contentful instance) directly into this high-performance Vercel React application.
            </p>
          </div>

          {/* Core Architecture Schema and Interactive Model Customizer */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left Box: Concept & Model Selection */}
            <div className={`lg:col-span-8 p-6 rounded-3xl border text-left ${
              highContrast ? 'bg-black border-yellow-400 text-yellow-400' : 'bg-white/5 border-white/10 backdrop-blur-xl'
            }`}>
              <h4 className="text-sm font-display font-bold uppercase tracking-wider mb-4 text-[#06b6d4] flex items-center gap-1.5">
                <Database className="w-4.5 h-4.5" /> Content Modeling & API Caching Pipeline
              </h4>
              <p className="text-xs opacity-85 leading-relaxed mb-6">
                Dynamic segments like News updates, physical laboratory facilities, calendar assemblies, and academic staff profiles will be structured model objects served over a fast GraphQL/REST API. This architecture guarantees non-technical administrators can adjust curriculum rosters, news briefs, or events with zero code updates.
              </p>

              {/* API and pipeline modeling highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                <div className="p-3 rounded-xl bg-slate-900/40 border border-white/5">
                  <div className="text-indigo-400 font-bold text-xs flex items-center gap-1">
                    <CheckSquare className="w-3.5 h-3.5" /> Strapi CMS Engine
                  </div>
                  <p className="text-[10px] opacity-75 mt-1">Docker hosted database panel for seamless database updates.</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/40 border border-white/5">
                  <div className="text-indigo-400 font-bold text-xs flex items-center gap-1">
                    <Globe className="w-3.5 h-3.5" /> Vercel Edge PoPs
                  </div>
                  <p className="text-[10px] opacity-75 mt-1">Global CDN edge cachers pull and serve JSON files in sub-20ms.</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/40 border border-white/5">
                  <div className="text-indigo-400 font-bold text-xs flex items-center gap-1">
                    <RefreshCw className="w-3.5 h-3.5" /> Automate Hooks
                  </div>
                  <p className="text-[10px] opacity-75 mt-1">Publishing updates automatically issues trigger events to Vercel builds.</p>
                </div>
              </div>

              {/* MODEL INTERACTIVE BUILDER TAB BLOCK */}
              <div className="border-t border-white/10 pt-6">
                <h5 className="text-[10px] font-mono uppercase tracking-widest opacity-60 font-bold mb-3">Model Schemas Playground:</h5>
                
                {/* Selector pills for Schema playground */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {(['faculty', 'labs', 'events', 'news'] as const).map((model) => (
                    <button
                      key={model}
                      onClick={() => {
                        setSelectedCmsModel(model);
                        if (model === 'faculty') setCustomFields(['Name', 'Designation', 'Specialization', 'OfficeMail', 'Bio']);
                        if (model === 'labs') setCustomFields(['LabName', 'Overview', 'InChargeTeacher', 'EquipmentsList', 'SafetyRosters']);
                        if (model === 'events') setCustomFields(['EventTitle', 'EventType', 'Date', 'RegistrationOpen', 'CoordinatorName']);
                        if (model === 'news') setCustomFields(['Title', 'PublicationDate', 'ContentRichText', 'NewsBannerMedia', 'Author']);
                      }}
                      className={`text-[11px] font-mono px-2.5 py-1.5 rounded transition ${
                        selectedCmsModel === model
                          ? highContrast ? 'bg-yellow-400 text-black' : 'bg-indigo-500 text-white'
                          : 'bg-white/5 text-slate-305 hover:bg-white/10'
                      }`}
                    >
                      {model.toUpperCase()} Schema
                    </button>
                  ))}
                </div>

                {/* Interactive Dynamic Field addition panel */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Fields list */}
                  <div className="p-4 rounded-xl bg-slate-950/60 border border-white/5">
                    <span className="text-[8px] font-mono opacity-50 block uppercase mb-1.5">Registered Fields in Database Model:</span>
                    <div className="flex flex-wrap gap-1.5">
                      {customFields.map((fld) => (
                        <span key={fld} className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-white/10 text-cyan-400">
                          {fld}
                        </span>
                      ))}
                    </div>
                    {/* Inline form to enter custom field */}
                    <form onSubmit={addNewCmsField} className="mt-4 flex gap-1.5">
                      <input
                        type="text"
                        value={newFieldName}
                        onChange={(e) => setNewFieldName(e.target.value)}
                        placeholder="Add new attribute (e.g. NIRF_Rank)"
                        className="text-[10px] font-mono p-1 bg-slate-900 border border-slate-800 text-white rounded outline-none focus:border-indigo-400 flex-1"
                      />
                      <button 
                        type="submit"
                        className="p-1 px-2.5 bg-indigo-500 hover:bg-indigo-600 rounded text-[10px] font-mono text-white font-bold"
                      >
                        + Add
                      </button>
                    </form>
                  </div>

                  {/* Schema JSON payload preview schema */}
                  <div className="p-4 rounded-xl bg-slate-950/60 border border-white/5 text-left">
                    <span className="text-[8px] font-mono opacity-50 block uppercase mb-1">Generated REST API Mock Response:</span>
                    <pre className="text-[10px] font-mono text-[#06b6d4] leading-tight overflow-x-auto whitespace-pre">
                      {`{
  "id": "CMS_ID_98${selectedCmsModel.toUpperCase().slice(0,3)}",
  "status": "published",
  "attributes": {
${customFields.map(field => `    "${field.toLowerCase()}": "Value_Placeholder"`).join(',\n')}
  }
}`}
                    </pre>
                  </div>
                </div>

              </div>

            </div>

            {/* Right Box: Admin Interface Simulation & Webhook trigger */}
            <div className="lg:col-span-4 flex flex-col justify-between gap-6 text-left">
              {/* Box 1: Non-Technical Administrator Interface Preview */}
              <div className={`p-5 rounded-3xl border flex-1 ${
                highContrast ? 'bg-black border-yellow-400 text-yellow-400' : 'bg-slate-900/20 border-white/5'
              }`}>
                <h5 className="text-[11px] font-mono font-bold tracking-widest uppercase text-indigo-400 mb-3 flex items-center gap-1.5">
                  <Settings className="w-4 h-4" /> Non-Technical Access
                </h5>
                <p className="text-[11px] opacity-80 leading-relaxed mb-4">
                  Non-technical academic staff or college executives leverage a beautiful sidebar panel dashboard with standard click-to-edit fields.
                </p>

                <div className="space-y-3">
                  <div className="p-2.5 rounded bg-slate-950/80 border border-white/5 text-[10px]">
                    <span className="opacity-50 block font-mono text-[8px] uppercase">Active Staff Member Account:</span>
                    <span className="font-bold text-slate-200">Prof. K. Prasath (HOD / Editor)</span>
                  </div>
                  
                  <div className="p-2.5 rounded bg-slate-950/80 border border-white/5 text-[10px]">
                    <span className="opacity-50 block font-mono text-[8px] uppercase">Workflow Rule:</span>
                    <span className="font-semibold text-emerald-400 block mt-0.5 select-none">✔ Editor Perms Auto-Approved for Posting updates</span>
                  </div>

                  {/* Mock live database action */}
                  <button
                    onClick={triggerCmsWebhook}
                    disabled={cmsWebhookStatus === 'triggered'}
                    className={`w-full py-2.5 rounded-xl text-xs uppercase font-bold tracking-wider transition ${
                      cmsWebhookStatus === 'triggered'
                        ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        : highContrast 
                          ? 'bg-yellow-400 text-black' 
                          : 'bg-indigo-500 hover:bg-indigo-600 text-white font-semibold flex items-center justify-center gap-1.5'
                    }`}
                  >
                    <RefreshCw className={`w-4 h-4 ${cmsWebhookStatus === 'triggered' ? 'animate-spin' : ''}`} /> 
                    {cmsWebhookStatus === 'triggered' ? 'Deploying to Vercel...' : 'Publish Update Webhook'}
                  </button>
                </div>
              </div>

              {/* Box 2: Live Deployment Console logs simulation */}
              <div className={`p-5 rounded-3xl border flex-1 flex flex-col justify-between ${
                highContrast ? 'bg-black border-yellow-400 text-yellow-400' : 'bg-black/40 border-white/5'
              }`}>
                <div>
                  <h5 className="text-[11px] font-mono font-bold tracking-widest uppercase text-slate-400 mb-2 flex items-center gap-1.5">
                    <Terminal className="w-4 h-4" /> API Logs Console
                  </h5>
                  <p className="text-[10px] opacity-75 mb-3 leading-tight text-slate-405">
                    API calls triggered by client routers or server webhooks during deployments:
                  </p>
                </div>

                <div className="p-3 rounded bg-slate-950/90 font-mono text-[10px] text-emerald-400 leading-snug border border-slate-900 flex-1 max-h-[140px] overflow-y-auto">
                  {cmsApiLogs.map((log, idx) => (
                    <div key={idx} className="truncate">· {log}</div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Simple internal interface icon components
function XIcon() {
  return (
    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
    </svg>
  );
}
