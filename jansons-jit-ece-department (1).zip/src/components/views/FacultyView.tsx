import React, { useState } from 'react';
import { Search, User, Mail, GraduationCap, Award, BookOpen, Clock, X, ChevronRight, ExternalLink } from 'lucide-react';
import { FACULTY_DATA } from '../../data/departmentData';
import { Faculty } from '../../types';

const getFacultyGradient = (name: string) => {
  const hash = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const gradients = [
    'from-indigo-600 to-purple-600',
    'from-blue-600 to-cyan-600',
    'from-teal-600 to-emerald-600',
    'from-rose-600 to-orange-600',
    'from-pink-600 to-purple-600',
    'from-violet-600 to-purple-600',
    'from-amber-600 to-red-600'
  ];
  return gradients[hash % gradients.length];
};

const getInitials = (name: string) => {
  return name
    .replace(/^(Dr\.|Mr\.|Mrs\.|Ms\.)\s+/i, '')
    .split(' ')
    .filter(Boolean)
    .map(p => p[0])
    .join('')
    .substring(0, 2)
    .toUpperCase();
};

interface FacultyViewProps {
  highContrast: boolean;
}

export default function FacultyView({ highContrast }: FacultyViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDesignation, setSelectedDesignation] = useState('All');
  const [selectedSpec, setSelectedSpec] = useState('All');
  const [activeProfile, setActiveProfile] = useState<Faculty | null>(null);

  // Derive unique specializations and designations for filter pills
  const designations = ['All', 'Professor', 'Associate Professor', 'Assistant Professor'];
  const specializations = ['All', 'VLSI', 'IoT', 'Embedded Systems', 'Communication', 'Signal Processing'];

  const filteredFaculty = FACULTY_DATA.filter((fac) => {
    const matchesSearch = 
      fac.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      fac.specialization.toLowerCase().includes(searchTerm.toLowerCase()) ||
      fac.researchAreas.some(area => area.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesDesignation = 
      selectedDesignation === 'All' || 
      fac.designation.includes(selectedDesignation);

    const matchesSpec = 
      selectedSpec === 'All' || 
      fac.specialization.toLowerCase().includes(selectedSpec.toLowerCase()) ||
      fac.researchAreas.some(area => area.toLowerCase().includes(selectedSpec.toLowerCase()));

    return matchesSearch && matchesDesignation && matchesSpec;
  });

  return (
    <div className="py-12 px-6 sm:px-12 max-w-7xl mx-auto animate-fade-in" id="faculty-view-container">
      {/* Intro Header */}
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase">Scholastic Leadership</span>
        <h2 className="text-2xl sm:text-4xl font-display font-bold uppercase tracking-tight mt-1 mb-3">
          Faculty Directory & Mentors
        </h2>
        <p className="text-xs opacity-75">
          Academic excellence begins with guidance. Our faculty body comprises seasoned academicians bringing decades of collective research depth, patents, and industrial solutions.
        </p>
      </div>

      {/* Interactive Controls Panel */}
      <div className={`p-4 rounded-2xl mb-8 flex flex-col md:flex-row gap-4 justify-between items-center ${
        highContrast ? 'bg-black border-2 border-yellow-400 text-yellow-400' : 'bg-slate-50 dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800'
      }`}>
        {/* Search Bar Input */}
        <div className="relative w-full md:w-80 flex items-center">
          <Search className="w-4 h-4 absolute left-3 text-slate-400" />
          <input
            type="search"
            placeholder="Search by name, research area..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={`w-full text-xs pl-9 pr-3 py-2.5 rounded-lg outline-none focus:ring-1 focus:ring-cyan-500 ${
              highContrast 
                ? 'bg-black border border-yellow-400 text-yellow-400' 
                : 'bg-white dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800'
            }`}
          />
        </div>

        {/* Designation Filter buttons */}
        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-xs font-mono opacity-60">Designation:</span>
          {designations.map((desig) => (
            <button
              key={desig}
              onClick={() => setSelectedDesignation(desig)}
              className={`text-[11px] px-2.5 py-1.5 rounded transition ${
                selectedDesignation === desig
                  ? highContrast ? 'bg-yellow-400 text-black font-extrabold' : 'bg-blue-600 text-white font-semibold'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
              }`}
            >
              {desig === 'All' ? 'All Roles' : desig}
            </button>
          ))}
        </div>
      </div>

      {/* Grid listing card */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredFaculty.map((fac) => (
          <div 
            key={fac.id}
            className={`rounded-2xl overflow-hidden border transition-all duration-300 group flex flex-col justify-between ${
              highContrast 
                ? 'bg-black border-yellow-400 text-yellow-400' 
                : 'bg-white dark:bg-slate-950 border-slate-100 dark:border-slate-900 shadow-sm hover:border-slate-350 dark:hover:border-slate-800 hover:-translate-y-1'
            }`}
          >
            <div>
              {/* Initials-based elegant gradient avatar (removed portrait photo) */}
              <div className="relative aspect-square overflow-hidden flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800">
                <div className={`w-28 h-28 rounded-full flex items-center justify-center text-white text-3xl font-display font-extrabold shadow-lg bg-gradient-to-br ${getFacultyGradient(fac.name)}`}>
                  {getInitials(fac.name)}
                </div>
                <div className="absolute top-3 right-3">
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${
                    highContrast ? 'bg-yellow-400 text-black' : 'bg-slate-950/80 text-cyan-400 backdrop-blur-md'
                  }`}>
                    Exp: {fac.experienceYears} Years
                  </span>
                </div>
              </div>

              {/* Core Details */}
              <div className="p-4">
                <span className="block text-[10px] font-mono uppercase tracking-wider opacity-60">
                  {fac.designation}
                </span>
                <h3 className="font-display font-extrabold text-base opacity-90 mt-0.5 group-hover:text-cyan-400 transition">
                  {fac.name}
                </h3>
                <p className="text-xs opacity-75 mt-1 text-slate-500 dark:text-slate-400 font-semibold italic flex items-center gap-1">
                  <GraduationCap className="w-3.5 h-3.5 flex-shrink-0" /> {fac.qualification}
                </p>

                {/* Micro specialization list */}
                <div className="flex flex-wrap gap-1 mt-3">
                  {fac.researchAreas.slice(0, 2).map((area, idx) => (
                    <span 
                      key={idx} 
                      className={`text-[9px] font-mono px-2 py-0.5 rounded border border-transparent ${
                        highContrast 
                          ? 'border-yellow-400 text-yellow-400' 
                          : 'bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {area}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Email and More actions panel */}
            <div className={`p-4 border-t flex items-center justify-between text-xs ${
              highContrast ? 'border-yellow-400' : 'border-slate-50 dark:border-slate-900'
            }`}>
              <a href={`mailto:${fac.email}`} className="text-slate-500 hover:text-cyan-400 truncate flex items-center gap-1">
                <Mail className="w-3.5 h-3.5 flex-shrink-0" /> <span className="truncate">{fac.email}</span>
              </a>
              <button
                onClick={() => setActiveProfile(fac)}
                className="text-cyan-400 font-bold hover:underline py-1 pl-2 flex items-center gap-0.5"
                aria-label={`View biography of ${fac.name}`}
              >
                Inquire <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredFaculty.length === 0 && (
        <div className="text-center py-12 text-slate-550 border rounded-xl p-8 uppercase font-mono text-xs">
          No faculty profiles match your active search settings.
        </div>
      )}

      {/* Detail Dialog overlay (Academic CV summary) */}
      {activeProfile && (
        <div 
          className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
          id="faculty-modal"
        >
          <div 
            className={`w-full max-w-2xl rounded-2xl p-6 shadow-2xl relative border ${
              highContrast ? 'bg-black text-yellow-400 border-yellow-400' : 'bg-slate-950 border-slate-900 text-white'
            }`}
          >
            <button
              onClick={() => setActiveProfile(null)}
              className="absolute right-4 top-4 p-1.5 rounded-full hover:bg-slate-800"
              aria-label="Close details"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex flex-col sm:flex-row gap-6 mt-2 pb-6 border-b border-white/10">
              <div className={`w-24 h-24 rounded-full flex items-center justify-center text-white text-3xl font-display font-extrabold border border-white/10 flex-shrink-0 bg-gradient-to-br ${getFacultyGradient(activeProfile.name)} shadow-md`}>
                {getInitials(activeProfile.name)}
              </div>
              <div>
                <span className="text-xs font-mono text-cyan-400 block uppercase tracking-wide">
                  {activeProfile.designation} (ECE @ JIT)
                </span>
                <h3 className="font-display font-extrabold text-xl">{activeProfile.name}</h3>
                <p className="text-xs opacity-75 font-semibold mt-0.5">{activeProfile.qualification}</p>
                <div className="text-xs mt-3 flex flex-wrap gap-4 font-mono opacity-80">
                  <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> Exp: {activeProfile.experienceYears} Years</span>
                  <span className="flex items-center gap-1"><BookOpen className="w-3.5 h-3.5 text-cyan-400" /> Publications: {activeProfile.publicationsCount}</span>
                </div>
              </div>
            </div>

            <div className="py-4 space-y-4 text-xs">
              <div>
                <span className="font-bold uppercase tracking-wider block opacity-60 text-[10px] mb-1">Core Research Specializations</span>
                <ul className="list-disc list-inside space-y-1 opacity-90">
                  {activeProfile.researchAreas.map((area, idx) => <li key={idx}>{area}</li>)}
                </ul>
              </div>

              {activeProfile.awards && activeProfile.awards.length > 0 && (
                <div>
                  <span className="font-bold uppercase tracking-wider block opacity-60 text-[10px] mb-1">Honors & Competency Recognitions</span>
                  <div className="flex flex-col gap-1">
                    {activeProfile.awards.map((aw, idx) => (
                      <div key={idx} className="flex items-center gap-1 text-cyan-400 select-all font-semibold">
                        <Award className="w-3.5 h-3.5 flex-shrink-0" /> <span>{aw}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeProfile.publications && activeProfile.publications.length > 0 && (
                <div>
                  <span className="font-bold uppercase tracking-wider block opacity-60 text-[10px] mb-1">Selected Journal Publications</span>
                  <ul className="space-y-1.5">
                    {activeProfile.publications.map((pub, idx) => (
                      <li key={idx} className="bg-slate-900 max-h-[80px] overflow-y-auto p-2 rounded border border-slate-800 italic opacity-85 select-all">
                        {pub}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {activeProfile.membership && activeProfile.membership.length > 0 && (
                <div>
                  <span className="font-bold uppercase tracking-wider block opacity-60 text-[10px] mb-1">Professional Body Affiliations</span>
                  <div className="flex flex-wrap gap-1.5">
                    {activeProfile.membership.map((mem, idx) => (
                      <span key={idx} className="bg-blue-950 text-cyan-300 font-semibold px-2 py-0.5 rounded border border-blue-900 font-mono text-[9px]">
                        {mem}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
