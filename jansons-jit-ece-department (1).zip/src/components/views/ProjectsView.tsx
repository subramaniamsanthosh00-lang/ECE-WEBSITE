import React, { useState } from 'react';
import { Cpu, Search, Calendar, User, Code, FileText, CheckCircle2, Star } from 'lucide-react';
import { PROJECTS_SHOWCASE } from '../../data/departmentData';
import { ProjectShowcase } from '../../types';

interface ProjectsViewProps {
  highContrast: boolean;
}

export default function ProjectsView({ highContrast }: ProjectsViewProps) {
  const [activeCategory, setActiveCategory] = useState<'All' | 'Embedded Systems' | 'AI' | 'IoT' | 'Robotics' | 'Communication Systems' | 'VLSI'>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = ['All', 'Embedded Systems', 'IoT', 'VLSI', 'Robotics', 'Communication Systems'];

  const filteredProjects = PROJECTS_SHOWCASE.filter((proj) => {
    const matchesCategory = 
      activeCategory === 'All' || 
      proj.category === activeCategory ||
      (activeCategory === 'Embedded Systems' && proj.category === 'VLSI'); // mapping logic fallback

    const matchesSearch = 
      proj.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      proj.brief.toLowerCase().includes(searchQuery.toLowerCase()) ||
      proj.students.some(st => st.toLowerCase().includes(searchQuery.toLowerCase())) ||
      proj.components.some(c => c.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesCategory && matchesSearch;
  });

  return (
    <div className="py-12 px-6 sm:px-12 max-w-7xl mx-auto animate-fade-in" id="projects-view-container">
      {/* Narrative Intro */}
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase">Capstone Portfolios</span>
        <h2 className="text-2xl sm:text-4xl font-display font-bold uppercase tracking-tight mt-1 mb-3">
          Student Projects Portal
        </h2>
        <p className="text-xs opacity-75">
          Validation of outcomes lies in fabrication. Our undergraduate capstone projects bridge simulation with multi-layered physical circuits, solving telemetry obstacles and building autonomous controllers.
        </p>
      </div>

      {/* Control panel */}
      <div className={`p-4 rounded-xl mb-8 flex flex-col md:flex-row justify-between items-center gap-4 ${
        highContrast ? 'bg-black border-2 border-yellow-400 text-yellow-400' : 'bg-slate-50 dark:bg-slate-900 border border-slate-205/50 dark:border-slate-800'
      }`}>
        <div className="relative w-full md:w-80 flex items-center">
          <Search className="w-4 h-4 absolute left-3 text-slate-400" />
          <input
            type="search"
            placeholder="Search by components (e.g. STM32, LoRa)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full text-xs pl-9 pr-3 py-2 rounded-lg outline-none focus:ring-1 focus:ring-cyan-500 ${
              highContrast 
                ? 'bg-black border border-yellow-400 text-yellow-400' 
                : 'bg-white dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-850'
            }`}
          />
        </div>

        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-xs font-mono opacity-65">Category:</span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat as any)}
              className={`text-[11px] px-2.5 py-1 rounded transition ${
                activeCategory === cat
                  ? highContrast ? 'bg-yellow-400 text-black font-extrabold' : 'bg-blue-600 text-white font-semibold'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Projects Grid List layout */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {filteredProjects.map((proj) => (
          <div 
            key={proj.id}
            className={`p-6 rounded-2xl border transition duration-300 flex flex-col justify-between ${
              highContrast 
                ? 'bg-black border-yellow-400 text-yellow-400' 
                : 'bg-slate-100/50 dark:bg-slate-950 border-slate-200/50 dark:border-slate-900 hover:border-slate-350 dark:hover:border-slate-800'
            }`}
          >
            <div>
              {/* Header category info */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1.5">
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded tracking-wider uppercase ${
                    highContrast ? 'border border-yellow-400 text-yellow-400' : 'bg-blue-600/10 text-cyan-400'
                  }`}>
                    {proj.category}
                  </span>
                  {proj.starred && (
                    <span className="flex items-center gap-0.5 text-xs text-yellow-400 font-extrabold font-mono">
                      <Star className="w-3.5 h-3.5 fill-yellow-400" /> Starred
                    </span>
                  )}
                </div>
                <span className="text-xs font-mono text-slate-500">{proj.year} Batch</span>
              </div>

              {/* Title & brief */}
              <h3 className="font-display font-extrabold text-base md:text-lg mb-2 opacity-95">
                {proj.title}
              </h3>
              <p className="text-xs opacity-80 leading-relaxed mb-4">
                {proj.brief}
              </p>

              {/* BOM / Component list tags */}
              <div className="mb-4">
                <span className="text-[10px] tracking-widest uppercase font-mono font-bold text-slate-500 block mb-1.5">
                  Core Materials utilised (BOM)
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {proj.components.map((material, idx) => (
                    <span 
                      key={idx} 
                      className={`text-[9.5px] font-mono px-2 py-0.5 rounded border ${
                        highContrast 
                          ? 'border-yellow-405 text-yellow-400' 
                          : 'bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-cyan-300 border-slate-200/50 dark:border-slate-800'
                      }`}
                    >
                      {material}
                    </span>
                  ))}
                </div>
              </div>

              {/* Learning / Technical Outcome check */}
              <div className="mb-6">
                <span className="text-[10px] tracking-widest uppercase font-mono font-bold text-slate-500 block mb-1.5">
                  Verifiable Performance Outcomes
                </span>
                <div className="flex flex-col gap-1.5">
                  {proj.outcomes.map((out, idx) => (
                    <div key={idx} className="flex gap-1.5 items-start text-[11px] opacity-85 leading-tight select-text">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0 mt-0.5" />
                      <p>{out}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Students metadata */}
            <div className={`pt-3 mt-auto border-t text-[11px] font-mono opacity-75 flex justify-between items-center gap-2 ${
              highContrast ? 'border-yellow-400' : 'border-slate-200/50 dark:border-slate-900'
            }`}>
              <div className="truncate text-slate-350">
                Inventors: <span className="font-bold">{proj.students.join(', ')}</span>
              </div>
              <div className="flex-shrink-0 text-cyan-400">
                Guide: <span className="font-bold">{proj.guide}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredProjects.length === 0 && (
        <div className="text-center py-12 text-slate-550 italic font-mono text-xs border rounded-xl">
          No student portfolios match your filter specifications.
        </div>
      )}
    </div>
  );
}
