import React from 'react';
import { Award, Briefcase, ChevronRight, TrendingUp, HelpCircle, HardHat, CheckSquare } from 'lucide-react';
import { PLACEMENT_RECORDS } from '../../data/departmentData';

interface PlacementsViewProps {
  highContrast: boolean;
}

export default function PlacementsView({ highContrast }: PlacementsViewProps) {
  const metrics = [
    { label: "Aggregate Placement Rate", value: `${PLACEMENT_RECORDS.placementPercentage}%`, desc: "Consistent peak ratios yearly" },
    { label: "Yearly Job Offers", value: PLACEMENT_RECORDS.totalOffers, desc: "Direct college-level linkages" },
    { label: "Highest CTC package", value: PLACEMENT_RECORDS.highestPackage, desc: "AMD Physical design roles" },
    { label: "Average CTC salary", value: PLACEMENT_RECORDS.averagePackage, desc: "Standard embedded candidates" }
  ];

  return (
    <div className="py-12 px-6 sm:px-12 max-w-7xl mx-auto animate-fade-in" id="placements-view-container">
      {/* Intro */}
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase">Career Roadmaps</span>
        <h2 className="text-2xl sm:text-4xl font-display font-bold uppercase tracking-tight mt-1 mb-3">
          Placement & Industry Readiness
        </h2>
        <p className="text-xs opacity-75">
          Connecting academic outcomes with industry roles. Our dedicated training programs, coordinate embedded bootcamps, and logical reasoning modules ensure graduates hit the ground running at peak technological enterprises.
        </p>
      </div>

      {/* Metrics Dashboard */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {metrics.map((met, idx) => (
          <div 
            key={idx}
            className={`p-5 rounded-2xl border text-center flex flex-col justify-between ${
              highContrast ? 'border-yellow-405 text-yellow-400' : 'bg-slate-900/40 border-slate-800'
            }`}
          >
            <div>
              <span className="text-xs font-mono font-bold opacity-60 uppercase block mb-1">
                {met.label}
              </span>
              <div className="text-3xl font-display font-extrabold text-cyan-400 tracking-tight">
                {met.value}
              </div>
            </div>
            <p className="text-[10px] opacity-60 mt-2">{met.desc}</p>
          </div>
        ))}
      </div>

      {/* Recruiters directory */}
      <div className="mb-14">
        <span className="text-xs font-mono font-bold tracking-widest text-slate-500 block uppercase mb-4 text-center">
          ⚡ Elite Corporate Linkage Partners
        </span>
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
          {PLACEMENT_RECORDS.recruiters.map((comp) => (
            <div 
              key={comp.id}
              className={`p-4 rounded-xl border text-center transition ${
                highContrast 
                  ? 'border-yellow-400 text-yellow-400' 
                  : 'bg-slate-50 dark:bg-slate-950 border-slate-200/50 dark:border-slate-900 hover:border-slate-300 dark:hover:border-slate-800'
              }`}
            >
              <div className="text-2xl mb-1.5">{comp.logo}</div>
              <h4 className="text-xs font-bold leading-tight truncate text-slate-300">{comp.name}</h4>
              <p className="text-[10px] opacity-60 mt-1 font-mono">{comp.offersCount} Selected</p>
            </div>
          ))}
        </div>
      </div>

      {/* Structured Training Frameworks */}
      <div>
        <h3 className="text-lg font-display font-bold uppercase tracking-wider mb-6 border-b pb-1.5 flex items-center gap-2">
          🎓 Curricular Placement Training Frameworks
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {PLACEMENT_RECORDS.trainingPrograms.map((prog, idx) => (
            <div 
              key={idx}
              className={`p-6 rounded-2xl border flex flex-col justify-between ${
                highContrast ? 'border-yellow-400 text-yellow-400' : 'bg-slate-100/50 dark:bg-slate-900/30 border-slate-200/50 dark:border-slate-850'
              }`}
            >
              <div>
                <div className="flex justify-between items-baseline mb-3">
                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${
                    highContrast ? 'bg-yellow-400 text-black border border-black' : 'bg-indigo-600/10 text-cyan-400'
                  }`}>
                    {prog.duration} Syllabus
                  </span>
                  <span className="text-[10px] font-mono text-slate-500 font-bold">{prog.targetYear}</span>
                </div>
                <h4 className="font-display font-extrabold text-sm mb-3">
                  {prog.syllabus}
                </h4>
                <p className="text-xs opacity-80 leading-relaxed mb-6">
                  {prog.outcomes}
                </p>
              </div>
              <div className="border-t border-slate-800 pt-2.5 mt-auto text-[10px] font-mono opacity-60 flex items-center gap-1">
                <CheckSquare className="w-3.5 h-3.5 text-emerald-500" /> Syllabus aligned with Autonomous Program Outcomes.
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Advisory placement box */}
      <div className={`p-6 rounded-2xl mt-12 border text-center ${
        highContrast ? 'border-yellow-400' : 'bg-gradient-to-tr from-slate-950 to-slate-900 border-slate-800 p-8'
      }`}>
        <Briefcase className="w-8 h-8 text-cyan-400 mx-auto mb-3 animate-bounce" />
        <h4 className="font-display font-bold text-base uppercase mb-1">Industrial Readiness Certifications</h4>
        <p className="text-xs opacity-75 max-w-lg mx-auto leading-relaxed">
          The ECE department hosts continuous technical evaluations in tie-ups with CISCO, Texas Instruments, and ARM University Programs. Students qualify for international standard certs alongside standard degree plans.
        </p>
      </div>
    </div>
  );
}
