import React, { useState } from 'react';
import { Award, Star, Trophy, Sparkles, HelpCircle, ChevronRight, Bookmark } from 'lucide-react';

interface AchievementsViewProps {
  highContrast: boolean;
}

export default function AchievementsView({ highContrast }: AchievementsViewProps) {
  const [activeTab, setActiveTab] = useState<'All' | 'Academic' | 'Hackathons' | 'Research' | 'Extra'>('All');

  const awardsList = [
    {
      id: "AW001",
      title: "First Prize - Smart India Hackathon 2023",
      category: "Hackathons",
      recipients: "M. Karthik Kumar, R. Swetha & Team (Final year ECE)",
      body: "Ministry of Jal Shakti, Government of India",
      desc: "Developed a self-powered LoRa hydrology node that maps water parameter telemetry and predicts potential regional flooding metrics.",
      prize: "Cash Prize of Rs. 1,00,000 & Incubation Offer",
      date: "Dec 2023"
    },
    {
      id: "AW002",
      title: "Autonomous Institute Academic Rank Holders",
      category: "Academic",
      recipients: "V. Dharshini (Class of 2024)",
      body: "Jansons Institute of Technology",
      desc: "Outstanding academic excellence, registering a cumulative CGPA of 9.38 out of 10.0 and standing in the top 10 positions zone-wide.",
      prize: "Gold Medal & Excellence Diploma",
      date: "May 2024"
    },
    {
      id: "AW003",
      title: "Best Paper Publication Award",
      category: "Research",
      recipients: "K. Priya (Faculty) & S. Prasath",
      body: "International Conference on Advanced Communications",
      desc: "Presented on the experimental realization of sub-6GHz wearable multi-band patch microstrips for medical telemetry loops.",
      prize: "Outstanding Researcher Certificate",
      date: "Feb 2024"
    },
    {
      id: "AW055",
      title: "TNSCST Student Funded Project Scheme Vetted",
      category: "Research",
      recipients: "S. Ajay, K. Naveen (Pre-final year)",
      body: "Tamil Nadu State Council for Science and Technology",
      desc: "Selected for state-level financial sponsorship to compile an embedded warehouse drone with integrated optical flow boards.",
      prize: "Funded Prototype Sponsorship",
      date: "Mar 2024"
    },
    {
      id: "AW004",
      title: "All-India Interuniversity Badminton Tournament",
      category: "Extra",
      recipients: "T. S. Gokul (Third year ECE)",
      body: "Association of Indian Universities",
      desc: "Represented the district/university cohort, securing consecutive wins and clinching the zonal sports silver trophy.",
      prize: "Silver Medal & Athletic Scholarship",
      date: "Jan 2024"
    }
  ];

  const filteredAwards = awardsList.filter(aw => {
    return activeTab === 'All' || aw.category === activeTab;
  });

  return (
    <div className="py-12 px-6 sm:px-12 max-w-7xl mx-auto animate-fade-in" id="achievements-view-container">
      {/* Introduction */}
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase">Laurels & Standards</span>
        <h2 className="text-2xl sm:text-4xl font-display font-bold uppercase tracking-tight mt-1 mb-3">
          Student Achievements
        </h2>
        <p className="text-xs opacity-75">
          Nurturing holistic engineers means validating their competence both inside and outside the classroom. Our students consistently bring home honors from elite national-level hackathons, research summits, and athletic championships.
        </p>
      </div>

      {/* Categories Selector */}
      <div className="flex flex-wrap gap-2 justify-center mb-10">
        {['All', 'Academic', 'Hackathons', 'Research', 'Extra'].map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveTab(cat as any)}
            className={`text-xs px-3.5 py-2 rounded-lg font-semibold transition ${
              activeTab === cat
                ? highContrast ? 'bg-yellow-400 text-black font-extrabold' : 'bg-blue-600 text-white shadow'
                : 'bg-slate-50 dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {cat === 'All' ? 'Show All' : cat === 'Extra' ? 'Extra / Sports' : `${cat} Wins`}
          </button>
        ))}
      </div>

      {/* Timeline Layout */}
      <div className="relative border-l-2 border-slate-200 dark:border-slate-800/80 pl-6 ml-2 space-y-8 max-w-3xl mx-auto">
        {filteredAwards.map((aw) => (
          <div key={aw.id} className="relative group animate-slide-up">
            {/* Pulsing indicator node */}
            <span className={`absolute -left-[31px] top-1 h-4 w-4 rounded-full border-2 bg-slate-950 flex items-center justify-center transition group-hover:scale-125 ${
              highContrast ? 'border-yellow-400' : 'border-cyan-400'
            }`}>
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />
            </span>

            <div className={`p-6 rounded-2xl border transition-all ${
              highContrast 
                ? 'bg-black text-yellow-400 border-yellow-400' 
                : 'bg-slate-900/10 border-slate-200/50 dark:border-slate-900 hover:border-slate-800 shadow-sm hover:shadow'
            }`}>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded uppercase ${
                  highContrast ? 'bg-yellow-400 text-black border border-black' : 'bg-blue-600/10 text-cyan-400'
                }`}>
                  {aw.category} Area
                </span>
                <span className="text-[10px] opacity-60 font-mono">{aw.date}</span>
              </div>

              <h3 className="font-display font-extrabold text-base md:text-lg mb-1 opacity-90 group-hover:text-cyan-400 transition">
                {aw.title}
              </h3>
              <p className="text-xs font-mono text-cyan-400/90 font-bold mb-1">
                Laureate(s): {aw.recipients}
              </p>
              <p className="text-xs opacity-75 leading-relaxed mb-4">
                {aw.desc}
              </p>

              <div className="border-t border-slate-800/50 pt-2.5 mt-4 flex flex-wrap justify-between items-center text-[11px] font-mono gap-2 opacity-80">
                <span className="flex items-center gap-1"><Bookmark className="w-3.5 h-3.5" /> Awarded by: <strong className="text-slate-300">{aw.body}</strong></span>
                <span className="text-cyan-400 font-extrabold flex items-center gap-1 scale-95 origin-right"><Trophy className="w-3.5 h-3.5" /> {aw.prize}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
