import React, { useState } from 'react';
import { 
  Mail, Phone, MapPin, Send, HelpCircle, CheckSquare, 
  Linkedin, Facebook, Compass, Info, MessageSquare
} from 'lucide-react';
import { DEPARTMENT_METADATA } from '../../data/departmentData';

interface ContactViewProps {
  highContrast: boolean;
}

export default function ContactView({ highContrast }: ContactViewProps) {
  const [formName, setFormName] = useState('');
  const [formMail, setFormMail] = useState('');
  const [formSubject, setFormSubject] = useState('');
  const [formMsg, setFormMsg] = useState('');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formMail) return;
    setIsSubmitting(true);
    // Simulate API storage securely
    setTimeout(() => {
      setIsSubmitting(false);
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        setFormName('');
        setFormMail('');
        setFormSubject('');
        setFormMsg('');
      }, 3000);
    }, 900);
  };

  return (
    <div className="py-12 px-6 sm:px-12 max-w-7xl mx-auto animate-fade-in" id="contact-view-container">
      {/* Intro */}
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-500 uppercase">Direct Linkage Channels</span>
        <h2 className="text-2xl sm:text-4xl font-display font-bold uppercase tracking-tight mt-1 mb-3">
          Contact ECE Department
        </h2>
        <p className="text-xs opacity-75">
          Have an inquiry regarding B.E. admissions, research collaborations, or placement drives? Send a direct dossier via the contact form or consult our official administrative contacts below.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
        {/* Contact Form Block */}
        <div 
          className={`p-6 sm:p-8 rounded-3xl border flex flex-col justify-between ${
            highContrast ? 'bg-black text-yellow-400 border-yellow-400' : 'bg-slate-50 dark:bg-slate-950 border-slate-205/60 dark:border-slate-905 shadow-sm'
          }`}
          id="contact-form-block"
        >
          <div>
            <h3 className="font-display font-extrabold text-base md:text-lg mb-1 mb-4 uppercase tracking-wider flex items-center gap-1.5 border-b pb-2">
              <MessageSquare className="w-5 h-5 text-cyan-400" /> Send Enquiries Dossier
            </h3>

            {success ? (
              <div className="py-12 text-center flex flex-col items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
                  <CheckSquare className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-sm">Feedback Dossier Sanitized!</h4>
                <p className="text-xs opacity-70">
                  Your communication has been logged securely under Ref ID: ECE-REQ-2026. A faculty peer will respond shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <label className="font-bold uppercase tracking-wider block opacity-60 text-[9px]">Full Sender Name</label>
                    <input
                      type="text"
                      required
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      placeholder="Your Name"
                      className={`p-2.5 rounded outline-none focus:ring-1 focus:ring-cyan-500 ${
                        highContrast ? 'bg-black border border-yellow-400 text-yellow-400' : 'bg-slate-900 border border-slate-800 text-white'
                      }`}
                      id="contact-sender-name"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="font-bold uppercase tracking-wider block opacity-60 text-[9px]">Mail Address</label>
                    <input
                      type="email"
                      required
                      value={formMail}
                      onChange={(e) => setFormMail(e.target.value)}
                      placeholder="sender@domain.com"
                      className={`p-2.5 rounded outline-none focus:ring-1 focus:ring-cyan-500 ${
                        highContrast ? 'bg-black border border-yellow-400 text-yellow-400' : 'bg-slate-900 border border-slate-800 text-white'
                      }`}
                      id="contact-sender-mail"
                    />
                  </div>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="font-bold uppercase tracking-wider block opacity-60 text-[9px]">Enquiry Subject Category</label>
                  <input
                    type="text"
                    required
                    value={formSubject}
                    onChange={(e) => setFormSubject(e.target.value)}
                    placeholder="Admissions B.E. / Research Collaboration / Placement recruitment..."
                    className={`p-2.5 rounded outline-none focus:ring-1 focus:ring-cyan-500 ${
                      highContrast ? 'bg-black border border-yellow-400 text-yellow-400' : 'bg-slate-900 border border-slate-800 text-white'
                    }`}
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <label className="font-bold uppercase tracking-wider block opacity-60 text-[9px]">Dossier Message / Inquiry detail</label>
                  <textarea
                    rows={4}
                    required
                    value={formMsg}
                    onChange={(e) => setFormMsg(e.target.value)}
                    placeholder="Describe your inquiry details..."
                    className={`p-2.5 rounded outline-none focus:ring-1 focus:ring-cyan-500 ${
                      highContrast ? 'bg-black border border-yellow-400 text-yellow-400' : 'bg-slate-900 border border-slate-800 text-white'
                    }`}
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`w-full py-2.5 rounded font-bold uppercase tracking-widest transition flex items-center justify-center gap-1.5 ${
                    highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-500 hover:bg-cyan-600 text-black font-semibold'
                  }`}
                  id="contact-submit-btn"
                >
                  <Send className="w-3.5 h-3.5" /> {isSubmitting ? 'Submitting...' : 'Submit Dossier'}
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Directions & official coordinates details */}
        <div className="flex flex-col justify-between gap-6" id="address-block">
          <div className={`p-6 rounded-3xl border flex-1 ${
            highContrast ? 'bg-black border-yellow-400 text-yellow-400' : 'bg-slate-900 border-slate-800 text-white'
          }`}>
            <h3 className="font-display font-extrabold text-sm uppercase tracking-widest text-cyan-400 mb-4 border-b pb-1.5">
              📌 Official Department Registry
            </h3>
            <div className="space-y-4 text-xs font-mono select-text">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-extrabold">Jansons Institute of Technology</h4>
                  <p className="opacity-80">Department of ECE, Karumathampatti,</p>
                  <p className="opacity-80">Coimbatore - 641659, Tamil Nadu, India.</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5 border-t border-slate-800 pt-3">
                <Phone className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                <div>
                  <span>Call Direct:</span>
                  <a href={`tel:${DEPARTMENT_METADATA.contactPhone}`} className="block font-bold hover:underline">
                    {DEPARTMENT_METADATA.contactPhone}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-2.5 border-t border-slate-800 pt-3">
                <Mail className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                <div>
                  <span>General Enquiries:</span>
                  <a href={`mailto:${DEPARTMENT_METADATA.contactMail}`} className="block font-bold hover:underline text-cyan-400">
                    {DEPARTMENT_METADATA.contactMail}
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Map widget fallback / live OpenStreetMap embed */}
          <div className="rounded-3xl overflow-hidden h-52 border border-slate-205/65 dark:border-slate-850 bg-slate-900 relative">
            {/* OpenStreetMap Iframe locator */}
            <iframe
              title="Jansons Institute of Technology Campus Location Coimbatore Map"
              width="100%"
              height="100%"
              style={{ border: 0, filter: 'contrast(1.2)' }}
              src="https://maps.google.com/maps?q=Jansons%20Institute%20of%20Technology,%20Karumathampatti,%20Coimbatore,%20Tamil%20Nadu&t=&z=14&ie=UTF8&iwloc=&output=embed"
              allowFullScreen
              loading="lazy"
            />
            {/* Ambient visual badge */}
            <div className="absolute bottom-2 left-2 bg-slate-950/80 backdrop-blur px-2 py-0.5 rounded text-[9px] font-mono text-cyan-400 font-bold uppercase tracking-widest">
              Live Campus Coordinates
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
