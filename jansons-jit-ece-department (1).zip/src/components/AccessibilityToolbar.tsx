import React, { useState, useEffect } from 'react';
import { Eye, Type, Volume2, VolumeX, RefreshCw, ZoomIn, ZoomOut, Sparkles } from 'lucide-react';

interface AccessibilityToolbarProps {
  highContrast: boolean;
  setHighContrast: (val: boolean) => void;
  fontSize: number;
  setFontSize: (val: number) => void;
  dyslexicFont: boolean;
  setDyslexicFont: (val: boolean) => void;
  currentViewTitle: string;
  viewSummaryText: string;
}

export default function AccessibilityToolbar({
  highContrast,
  setHighContrast,
  fontSize,
  setFontSize,
  dyslexicFont,
  setDyslexicFont,
  currentViewTitle,
  viewSummaryText
}: AccessibilityToolbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechSynth, setSpeechSynth] = useState<SpeechSynthesis | null>(null);
  const [currentUtterance, setCurrentUtterance] = useState<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      setSpeechSynth(window.speechSynthesis);
    }
  }, []);

  const handleSpeak = () => {
    if (!speechSynth) return;
    
    if (isSpeaking) {
      speechSynth.cancel();
      setIsSpeaking(false);
      return;
    }

    const textToSpeak = `You are viewing the ${currentViewTitle} section. ${viewSummaryText}`;
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    
    setCurrentUtterance(utterance);
    setIsSpeaking(true);
    speechSynth.speak(utterance);
  };

  useEffect(() => {
    return () => {
      if (speechSynth && isSpeaking) {
        speechSynth.cancel();
      }
    };
  }, [speechSynth, isSpeaking]);

  const resetSettings = () => {
    setHighContrast(false);
    setFontSize(100);
    setDyslexicFont(false);
    if (speechSynth) {
      speechSynth.cancel();
      setIsSpeaking(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end" id="accessibility-toolbar-root">
      {isOpen && (
        <div 
          className={`mb-3 flex flex-col gap-2 rounded-xl p-4 shadow-2xl transition-all duration-300 ${
            highContrast ? 'bg-black border-2 border-yellow-400 text-yellow-400' : 'bg-slate-900 text-white'
          }`}
          style={{ width: '280px' }}
          id="accessibility-panel"
        >
          <div className="flex items-center justify-between border-b pb-2">
            <span className="font-display text-sm font-semibold tracking-wider uppercase flex items-center gap-1.5">
              <Eye className="w-4 h-4" /> Accessibility HUD
            </span>
            <button 
              onClick={resetSettings}
              className={`rounded p-1 text-xs transition duration-200 hover:bg-slate-800 flex items-center gap-1 ${
                highContrast ? 'hover:bg-yellow-900 border border-yellow-400' : ''
              }`}
              title="Reset all settings to default"
              id="acc-reset-btn"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Reset
            </button>
          </div>

          {/* Contrast Controls */}
          <div className="flex flex-col gap-1.5 mt-2">
            <label className="text-xs font-semibold uppercase opacity-80" id="contrast-label">Contrast Mode</label>
            <button
              aria-labelledby="contrast-label"
              onClick={() => setHighContrast(!highContrast)}
              className={`w-full py-2 px-3 rounded-lg text-sm text-left flex items-center justify-between border transition duration-200 ${
                highContrast 
                  ? 'bg-yellow-400 text-black border-yellow-400 font-bold' 
                  : 'bg-slate-800 text-white border-slate-700 hover:bg-slate-700'
              }`}
            >
              <span>{highContrast ? 'High Contrast: Active' : 'Normal Contrast'}</span>
              <Eye className="w-4 h-4" />
            </button>
          </div>

          {/* Font Resizing Controls */}
          <div className="flex flex-col gap-1.5 mt-2">
            <span className="text-xs font-semibold uppercase opacity-80">Text Scaling ({fontSize}%)</span>
            <div className="flex gap-1.5">
              <button
                onClick={() => setFontSize(Math.max(80, fontSize - 10))}
                className={`flex-1 py-1 px-2 rounded bg-slate-800 border border-slate-700 text-center hover:bg-slate-700 transition ${
                  highContrast ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-950' : ''
                }`}
                aria-label="Decrease text size"
              >
                <ZoomOut className="w-4 h-4 mx-auto" />
              </button>
              <button
                onClick={() => setFontSize(Math.min(130, fontSize + 10))}
                className={`flex-1 py-1 px-2 rounded bg-slate-800 border border-slate-700 text-center hover:bg-slate-700 transition ${
                  highContrast ? 'border-yellow-400 text-yellow-400 hover:bg-yellow-950' : ''
                }`}
                aria-label="Increase text size"
              >
                <ZoomIn className="w-4 h-4 mx-auto" />
              </button>
            </div>
          </div>

          {/* Dyslexic Friendly Font */}
          <div className="flex flex-col gap-1.5 mt-2">
            <label className="text-xs font-semibold uppercase opacity-80" id="dyslexia-label">Dyslexia Font Helper</label>
            <button
              aria-labelledby="dyslexia-label"
              onClick={() => setDyslexicFont(!dyslexicFont)}
              className={`w-full py-2 px-3 rounded-lg text-sm text-left flex items-center justify-between border transition duration-200 ${
                dyslexicFont 
                  ? 'bg-cyan-500 text-black font-semibold border-cyan-400' 
                  : 'bg-slate-800 text-white border-slate-700 hover:bg-slate-700'
              }`}
            >
              <span>{dyslexicFont ? 'Active (Friendly Font)' : 'Standard Fonts'}</span>
              <Type className="w-4 h-4" />
            </button>
          </div>

          {/* Screen Reader Voice Synthesizer */}
          <div className="flex flex-col gap-1.5 mt-2">
            <span className="text-xs font-semibold uppercase opacity-80">Aura-Voice Reader</span>
            <button
              onClick={handleSpeak}
              className={`w-full py-2 px-3 rounded-lg text-sm text-left flex items-center justify-between border transition duration-200 ${
                isSpeaking 
                  ? 'bg-red-500 text-white font-bold border-red-400 pulse-slow' 
                  : 'bg-slate-800 text-white border-slate-700 hover:bg-slate-700'
              }`}
            >
              <span>{isSpeaking ? 'Mute Narrator' : 'Read Page Aloud'}</span>
              {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>

          <div className="text-[10px] opacity-60 text-center mt-2 border-t pt-2">
            Designed to WCAG 2.1 AA specifications
          </div>
        </div>
      )}

      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`flex h-12 w-12 items-center justify-center rounded-full shadow-2xl transition-all duration-300 hover:scale-105 active:scale-95 ${
          highContrast 
            ? 'bg-black border-2 border-yellow-400 text-yellow-400' 
            : 'bg-gradient-to-tr from-blue-700 via-blue-600 to-cyan-500 text-white'
        }`}
        title="Toggle Accessibility Options"
        aria-expanded={isOpen}
        id="acc-toggle-hud"
      >
        <Sparkles className="w-5 h-5 animate-pulse" />
      </button>
    </div>
  );
}
