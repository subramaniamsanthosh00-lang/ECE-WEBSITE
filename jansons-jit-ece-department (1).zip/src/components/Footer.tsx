import React, { useState } from 'react';
import { 
  Mail, Phone, MapPin, ExternalLink, Shield, Download, FileCheck, Info,
  Facebook, Twitter, Instagram, Linkedin, Send, Sparkles, AlertCircle
} from 'lucide-react';
import { DEPARTMENT_METADATA, DOWNLOADS_DATA } from '../data/departmentData';

interface FooterProps {
  onNavigate: (view: string) => void;
  highContrast: boolean;
}

export default function Footer({ onNavigate, highContrast }: FooterProps) {
  const [newsletterMail, setNewsletterMail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterMail) return;
    setSubmitting(true);
    // Simulate API flow securely
    setTimeout(() => {
      setSubmitting(false);
      setIsSubscribed(true);
      setNewsletterMail('');
    }, 850);
  };

  const currentYear = new Date().getFullYear();

  const containerStyle = highContrast
    ? 'bg-black text-yellow-400 border-t-2 border-yellow-400'
    : 'bg-slate-950 text-slate-200 border-t border-slate-900';

  return (
    <footer className={`py-12 px-6 sm:px-12 ${containerStyle}`} id="department-footer">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
        {/* Department Info */}
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2">
            <span className={`h-8 w-8 rounded flex items-center justify-center font-bold ${
              highContrast ? 'bg-yellow-400 text-black border border-black' : 'bg-blue-600 text-white'
            }`}>
              ⚡
            </span>
            <span className="font-display font-bold text-base tracking-wide uppercase">
              ECE JANSONS
            </span>
          </div>
          <p className="text-xs leading-relaxed opacity-75">
            Developing future-ready communication systems, hardware architectures, and internet frameworks since 2009.
          </p>
          <div className="flex flex-col gap-2.5 text-xs font-mono mt-2">
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
              <span>{DEPARTMENT_METADATA.location}</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-cyan-400 flex-shrink-0" />
              <a href={`tel:${DEPARTMENT_METADATA.contactPhone}`} className="hover:underline">
                {DEPARTMENT_METADATA.contactPhone}
              </a>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-cyan-400 flex-shrink-0" />
              <a href={`mailto:${DEPARTMENT_METADATA.contactMail}`} className="hover:underline">
                {DEPARTMENT_METADATA.contactMail}
              </a>
            </div>
          </div>
        </div>

        {/* Quick Links Catalog */}
        <div className="flex flex-col gap-4">
          <h3 className="font-display text-sm font-bold tracking-wider uppercase border-b pb-2 border-white/10 opacity-90">
            Syllabus Navigation
          </h3>
          <ul className="grid grid-cols-2 gap-2 text-xs">
            {[
              { label: 'Academic Overview', view: 'about' },
              { label: 'Faculty Directory', view: 'faculty' },
              { label: 'Practical Labs', view: 'laboratories' },
              { label: 'Research Papers', view: 'research' },
              { label: 'Alumni Network', view: 'alumni' },
              { label: 'Placements Wall', view: 'placements' },
              { label: 'Events Hub', view: 'events' },
              { label: 'Student Portfolios', view: 'projects' },
              { label: 'Media Highlights', view: 'gallery' },
              { label: 'Official Enquiries', view: 'contact' }
            ].map((link, idx) => (
              <li key={idx}>
                <button
                  onClick={() => onNavigate(link.view)}
                  className="hover:text-cyan-400 hover:underline text-left transition duration-150 py-1"
                >
                  {link.label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Essential Brochure / Document Downloads */}
        <div className="flex flex-col gap-4">
          <h3 className="font-display text-sm font-bold tracking-wider uppercase border-b pb-2 border-white/10 opacity-90">
            Resource Library
          </h3>
          <div className="flex flex-col gap-2">
            {DOWNLOADS_DATA.slice(0, 3).map((dl) => (
              <a
                key={dl.id}
                href={dl.url}
                onClick={(e) => { e.preventDefault(); alert(`Downloading PDF: ${dl.title}`); }}
                className={`p-2 rounded flex flex-col gap-1 text-[11px] border transition ${
                  highContrast 
                    ? 'border-yellow-400 hover:bg-yellow-950/40 text-yellow-400' 
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
                }`}
              >
                <div className="flex items-center justify-between font-semibold">
                  <span className="truncate max-w-[160px]">{dl.title}</span>
                  <Download className="w-3 h-3 text-cyan-400 flex-shrink-0" />
                </div>
                <div className="flex justify-between items-center opacity-60 font-mono text-[9px]">
                  <span>Format: {dl.format}</span>
                  <span>Size: {dl.fileSize}</span>
                </div>
              </a>
            ))}
          </div>
        </div>

        {/* Newsletter / Notifications Integration */}
        <div className="flex flex-col gap-4">
          <h3 className="font-display text-sm font-bold tracking-wider uppercase border-b pb-2 border-white/10 opacity-90">
            Academic Bulletin Signup
          </h3>
          <p className="text-xs opacity-75">
            Receive monthly updates regarding departmental research, placement drives, upcoming guest seminars, and hackathons.
          </p>

          {isSubscribed ? (
            <div className={`p-3 rounded-lg text-xs flex items-center gap-2 ${
              highContrast ? 'border border-yellow-400' : 'bg-emerald-950/80 text-emerald-300 border border-emerald-900'
            }`}>
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>Successfully enrolled in bulletin!</span>
            </div>
          ) : (
            <form onSubmit={handleSubscribe} className="flex flex-col gap-2">
              <div className="flex">
                <input
                  type="email"
                  placeholder="Enter academic email"
                  required
                  value={newsletterMail}
                  onChange={(e) => setNewsletterMail(e.target.value)}
                  className={`flex-1 rounded-l-md px-3 py-1.5 text-xs outline-none focus:ring-1 focus:ring-cyan-400 ${
                    highContrast 
                      ? 'bg-black border border-yellow-400 text-yellow-400 placeholder-yellow-800' 
                      : 'bg-slate-900 border border-slate-800 text-white placeholder-slate-500'
                  }`}
                  id="newsletter-email-input"
                />
                <button
                  type="submit"
                  disabled={submitting}
                  className={`px-3 py-1.5 rounded-r-md flex items-center justify-center transition-colors ${
                    highContrast 
                      ? 'bg-yellow-400 text-black border border-yellow-400' 
                      : 'bg-blue-600 hover:bg-blue-700 text-white'
                  }`}
                  aria-label="Submit newsletter register"
                >
                  {submitting ? '...' : <Send className="w-3.5 h-3.5" />}
                </button>
              </div>
              <div className="flex items-center gap-1.5 text-[9px] opacity-60">
                <Shield className="w-3 h-3" />
                <span>Encrypted delivery. Zero promotion waste.</span>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Outro Disclaimer Strip */}
      <div className={`pt-6 border-t font-mono text-xs flex flex-col md:flex-row justify-between items-center gap-4 ${
        highContrast ? 'border-yellow-400 text-yellow-400' : 'border-slate-900 text-slate-400'
      }`}>
        <p>© {currentYear} Jansons Institute of Technology | Dept. of ECE. All Rights Reserved.</p>
        <div className="flex gap-4">
          <a href="#privacy" className="hover:underline">Terms of Use</a>
          <span>·</span>
          <a href="#admin" className="hover:underline">Faculty Web-Access Portal</a>
          <span>·</span>
          <a href="#sitemap" className="hover:underline">Campus Directory</a>
        </div>
        <div className="flex gap-3 text-slate-400">
          <a href={DEPARTMENT_METADATA.socials.facebook} target="_blank" rel="noopener noreferrer" className="hover:text-cyan-400">
            <Facebook className="w-4 h-4" />
          </a>
          <a href={DEPARTMENT_METADATA.socials.twitter} target="_blank" rel="noopener noreferrer" className="hover:text-cyan-400">
            <Twitter className="w-4 h-4" />
          </a>
          <a href={DEPARTMENT_METADATA.socials.instagram} target="_blank" rel="noopener noreferrer" className="hover:text-cyan-400">
            <Instagram className="w-4 h-4" />
          </a>
          <a href={DEPARTMENT_METADATA.socials.linkedin} target="_blank" rel="noopener noreferrer" className="hover:text-cyan-400">
            <Linkedin className="w-4 h-4" />
          </a>
        </div>
      </div>
    </footer>
  );
}
