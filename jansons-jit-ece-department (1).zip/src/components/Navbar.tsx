import React, { useState, useEffect } from 'react';
import { 
  Menu, X, Search, BookOpen, Layers, Award, Radio, Users, 
  MapPin, ChevronDown, Award as Laurel, ArrowRight, FileText, Calendar 
} from 'lucide-react';
import { DEPARTMENT_METADATA } from '../data/departmentData';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  highContrast: boolean;
  onGlobalSearch: (term: string) => void;
}

export default function Navbar({
  currentView,
  onNavigate,
  darkMode,
  setDarkMode,
  highContrast,
  onGlobalSearch
}: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [activeMega, setActiveMega] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (totalScroll > 0) {
        setScrollProgress((window.pageYOffset / totalScroll) * 100);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      onGlobalSearch(searchTerm);
      setShowSearch(false);
      setSearchTerm('');
    }
  };

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About ECE' },
    { id: 'faculty', label: 'Faculty Directory' },
    { id: 'laboratories', label: 'Laboratories' },
    { id: 'research', label: 'Research & IP' },
    { id: 'projects', label: 'Projects' },
    { id: 'placements', label: 'Placements' },
    { id: 'achievements', label: 'Student Achievements' },
    { id: 'events', label: 'Events Hub' },
    { id: 'alumni', label: 'Alumni Network' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'contact', label: 'Contact' }
  ];

  const getBreadcrumb = () => {
    const item = navItems.find(n => n.id === currentView);
    return item ? item.label : 'Home';
  };

  const menuStyle = highContrast 
    ? 'bg-black text-yellow-400 border-b-2 border-yellow-400' 
    : darkMode 
      ? 'bg-white/5 text-slate-100 border-b border-white/10 backdrop-blur-md' 
      : 'bg-white/40 text-slate-900 border-b border-slate-200/50 backdrop-blur-md shadow-sm';

  return (
    <header className="sticky top-0 z-40 w-full" id="site-header">
      {/* Scroll Progress Bar */}
      <div 
        className="h-1 bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-600 transition-all duration-100 ease-out" 
        style={{ width: `${scrollProgress}%` }}
        id="scroll-progress-bar"
      />

      {/* Institutional Affiliation Top Strip */}
      <div className={`text-xs py-1.5 px-4 flex justify-between items-center ${
        highContrast ? 'bg-yellow-400 text-black font-bold' : 'bg-slate-900 text-slate-300'
      }`}>
        <div className="flex items-center gap-2">
          <Laurel className="w-3.5 h-3.5 text-cyan-400" />
          <span className="tracking-wide hidden sm:inline">Approved by AICTE | Accredited by NAAC & NBA</span>
          <span className="tracking-wide sm:hidden">AICTE, NAAC & NBA</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="font-mono text-[11px] select-all uppercase tracking-wider font-bold text-cyan-400">Autonomous Institution</span>
        </div>
      </div>

      {/* Primary Brand Header */}
      <div className={`px-4 sm:px-8 py-3.5 flex items-center justify-between transition-all duration-300 ${menuStyle}`}>
        {/* Department / Institution Logo & Brand Group */}
        <div 
          onClick={() => onNavigate('home')} 
          className="flex items-center gap-3 cursor-pointer group"
          id="brand-container"
        >
          <div className={`h-11 w-11 rounded-lg flex items-center justify-center transition-all ${
            highContrast 
              ? 'bg-yellow-400 text-black border border-black' 
              : 'bg-gradient-to-tr from-blue-700 via-blue-600 to-cyan-500 text-white'
          }`}>
            <Radio className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <span className="block font-display text-xs font-bold tracking-widest text-cyan-500 uppercase">
              Jansons Institute of Technology
            </span>
            <h1 className="text-sm sm:text-base font-display font-extrabold tracking-tight uppercase flex items-center gap-1.5">
              Electronics & Communication Engineering
            </h1>
          </div>
        </div>

        {/* Desktop Central Actions */}
        <div className="hidden lg:flex items-center gap-4" id="desktop-tools">
          {/* Global Search Bar Trigger */}
          <button
            onClick={() => setShowSearch(!showSearch)}
            className={`p-2 rounded-full transition-all duration-200 ${
              highContrast ? 'bg-yellow-400 text-black' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
            title="Global Search"
            aria-label="Toggle Global Search"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Quick Access Syllabus Download Accent */}
          <a
            href="#dl-syllabus"
            onClick={(e) => { e.preventDefault(); onNavigate('about'); }}
            className={`text-xs font-semibold px-3 py-1.5 rounded-md flex items-center gap-1 transition ${
              highContrast 
                ? 'bg-yellow-400 text-black border border-black' 
                : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-950/80'
            }`}
          >
            <FileText className="w-3.5 h-3.5" /> Regulation 2021
          </a>
        </div>

        {/* Mobile Toggle & Quick Actions */}
        <div className="flex lg:hidden items-center gap-2">
          <button
            onClick={() => setShowSearch(!showSearch)}
            className="p-1.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600"
            aria-label="Toggle global search dialog"
          >
            <Search className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsOpen(!isOpen)}
            className={`p-2 rounded-lg transition-all ${
              highContrast ? 'bg-yellow-400 text-black border border-black' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
            }`}
            aria-label="Toggle main menu"
          >
            {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Global Search Expansion Overlay Panel */}
      {showSearch && (
        <form 
          onSubmit={handleSearchSubmit}
          className={`absolute top-full left-0 w-full z-50 p-4 border-b transition-all duration-150 flex items-center gap-2 ${
            highContrast ? 'bg-black text-yellow-400 border-yellow-400' : darkMode ? 'bg-black/80 text-white border-white/10 backdrop-blur-xl' : 'bg-white/85 text-slate-900 border-slate-200/60 backdrop-blur-xl'
          }`}
          id="global-search-form"
        >
          <Search className="w-5 h-5 text-slate-400" />
          <input
            type="search"
            placeholder="Search Faculty, Laboratories, Projects, Placement statistics... (try 'VLSI' or 'IoT')"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={`flex-1 overflow-hidden bg-transparent border-0 outline-none p-1.5 text-sm ring-0 flex-shrink-0 ${
              highContrast ? 'placeholder-yellow-600 text-yellow-400' : 'placeholder-slate-400 text-white'
            }`}
            autoFocus
          />
          <button 
            type="submit" 
            className={`px-3 py-1.5 text-xs rounded transition-all font-semibold ${
              highContrast ? 'bg-yellow-400 text-black' : 'bg-cyan-500 hover:bg-cyan-600 text-black'
            }`}
          >
            Search DB
          </button>
          <button
            type="button"
            onClick={() => { setShowSearch(false); setSearchTerm(''); }}
            className="text-xs px-2 py-1 flex-shrink-0 opacity-70 hover:opacity-100"
          >
            Cancel
          </button>
        </form>
      )}

      {/* Desktop Horizontal Navigation & Mega-menu Triggers */}
      <nav 
        className={`hidden lg:flex items-center justify-between px-8 py-2 relative transition-all border-b ${
          highContrast ? 'bg-black border-yellow-400 text-yellow-400' : darkMode ? 'bg-white/5 text-slate-300 border-white/10 backdrop-blur-md' : 'bg-white/45 text-slate-700 border-slate-200/50 backdrop-blur-md'
        }`}
        id="desktop-primary-nav"
      >
        <div className="flex items-center gap-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                onNavigate(item.id);
                setActiveMega(null);
              }}
              className={`text-[12.5px] font-display font-medium px-3 py-1.5 rounded-md transition-all duration-200 relative ${
                currentView === item.id 
                  ? highContrast 
                    ? 'bg-yellow-400 text-black font-extrabold' 
                    : 'bg-blue-600/10 text-blue-600 dark:text-cyan-400 font-semibold' 
                  : 'hover:bg-slate-200/50 dark:hover:bg-slate-800/80 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {item.label}
              {currentView === item.id && (
                <span className="absolute bottom-0 left-1/3 right-1/3 h-0.5 bg-cyan-400 rounded-full" />
              )}
            </button>
          ))}
        </div>

        {/* Dynamic Mega Menu Triggers (Virtual Directories helper) */}
        <div className="flex items-center gap-1.5">
          <div className="relative">
            <button
              onClick={() => setActiveMega(activeMega === 'resources' ? null : 'resources')}
              className={`text-xs px-2.5 py-1.5 rounded flex items-center gap-1 font-mono transition ${
                activeMega === 'resources' ? 'bg-slate-800 text-cyan-400' : 'hover:bg-slate-200/50 dark:hover:bg-slate-800'
              }`}
            >
              Academic Blueprint <ChevronDown className="w-3 h-3" />
            </button>
            {activeMega === 'resources' && (
              <div className={`absolute right-0 top-full mt-2 w-72 rounded-xl p-3 shadow-2xl z-50 border transition-all ${
                highContrast ? 'bg-black text-yellow-400 border-yellow-400' : darkMode ? 'bg-white/5 border-white/15 text-white backdrop-blur-xl' : 'bg-white/80 border-slate-200 text-slate-900 backdrop-blur-xl'
              }`}>
                <span className="block text-[10px] uppercase tracking-widest font-bold opacity-60 pb-1.5 mb-2 border-b border-white/10">
                  Autonomous Blueprint Mapping
                </span>
                <div className="flex flex-col gap-1">
                  {[
                    { title: 'Core Laboratories Checklist', view: 'laboratories' },
                    { title: 'Research & Funded Patency', view: 'research' },
                    { title: 'Autonomous PO & PSO Framework', view: 'about' },
                    { title: 'Placement Drive Readiness Portal', view: 'placements' }
                  ].map((blue, idx) => (
                    <button
                      key={idx}
                      onClick={() => { onNavigate(blue.view); setActiveMega(null); }}
                      className="text-left text-xs p-2 rounded hover:bg-slate-800 transition flex items-center justify-between group"
                    >
                      <span className="group-hover:text-cyan-400">{blue.title}</span>
                      <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition duration-150" />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Secondary Dynamic Breadcrumb Navigator */}
      <div className={`px-4 sm:px-8 py-2 text-[11px] font-mono flex items-center justify-between ${
        highContrast ? 'bg-black text-yellow-400 border-b border-yellow-400' : darkMode ? 'bg-black/20 text-slate-400 border-b border-white/5 backdrop-blur-sm' : 'bg-white/30 text-slate-600 border-b border-slate-200/40 backdrop-blur-sm'
      }`}>
        <div className="flex items-center gap-1">
          <span className="opacity-70">JIT ECE</span>
          <span>/</span>
          <span className="font-bold text-slate-700 dark:text-cyan-400">{getBreadcrumb()}</span>
        </div>
        <div className="hidden md:flex items-center gap-4">
          <span className="flex items-center gap-1">
            <MapPin className="w-3 h-3 text-red-500" /> Coimbatore, India
          </span>
          <span className="flex items-center gap-1">
            <Calendar className="w-3 h-3 text-cyan-500" /> JIT Term Cycle: 2026-2027
          </span>
        </div>
      </div>

      {/* Mobile Drawer Slide Navigation Menu */}
      {isOpen && (
        <div 
          className={`lg:hidden fixed inset-x-0 top-[110px] bottom-0 z-30 flex flex-col p-6 animate-fade-in transition-all ${
            highContrast ? 'bg-black text-yellow-400 border-t border-yellow-400' : 'bg-slate-900/95 text-white backdrop-blur-xl'
          }`}
          id="mobile-drawer-root"
        >
          <div className="text-xs uppercase tracking-widest font-mono opacity-60 mb-4 border-b border-white/10 pb-2">
            Primary Department Sections
          </div>
          <div className="flex-1 flex flex-col gap-2 overflow-y-auto">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  setIsOpen(false);
                }}
                className={`py-2 text-left font-display text-base font-semibold border-b border-white/5 flex items-center justify-between transition-colors ${
                  currentView === item.id ? 'text-cyan-400 font-extrabold' : 'hover:text-cyan-300'
                }`}
              >
                <span>{item.label}</span>
                {currentView === item.id && <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />}
              </button>
            ))}
          </div>

          <div className="mt-auto border-t border-white/10 pt-4 flex flex-col gap-2">
            <div className="text-[11px] font-mono text-slate-400">
              ECE Official Hub : hod.ece@jit.ac.in
            </div>
            <div className="flex gap-4 text-xs">
              <a href="#about" onClick={(e) => { e.preventDefault(); onNavigate('about'); setIsOpen(false); }} className="hover:underline">PO Outcomes</a>
              <span>·</span>
              <a href="#labs" onClick={(e) => { e.preventDefault(); onNavigate('laboratories'); setIsOpen(false); }} className="hover:underline">Equipments</a>
              <span>·</span>
              <a href="#downloads" onClick={(e) => { e.preventDefault(); onNavigate('about'); setIsOpen(false); }} className="hover:underline">Resources</a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
