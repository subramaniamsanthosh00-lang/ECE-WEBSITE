export interface Faculty {
  id: string;
  name: string;
  designation: string;
  qualification: string;
  specialization: string;
  experienceYears: number;
  email: string;
  researchAreas: string[];
  publicationsCount: number;
  patentsCount: number;
  awards: string[];
  image: string;
  detailedBio?: string;
  publications?: string[];
  membership?: string[];
}

export interface Laboratory {
  id: string;
  name: string;
  roomNo: string;
  areaSqM: number;
  labInCharge: string;
  assistantInCharge?: string;
  overview: string;
  learningOutcomes: string[];
  majorEquipment: { name: string; specs: string; quantity: number }[];
  experiments: string[];
  softwareBuilt?: string[];
  image: string;
  schedule?: string;
}

export interface Publication {
  id: string;
  title: string;
  authors: string[];
  journal: string;
  year: number;
  doi?: string;
  category: 'International Journal' | 'National Journal' | 'International Conference' | 'National Conference';
  indexing: ('Scopus' | 'Web of Science' | 'IEEE Explore' | 'Google Scholar')[];
}

export interface Patent {
  id: string;
  title: string;
  inventors: string[];
  applicationNo: string;
  status: 'Published' | 'Filed' | 'Granted';
  year: number;
}

export interface ResearchProject {
  id: string;
  title: string;
  pInvestigator: string;
  coPI?: string;
  fundingAgency: string;
  amount: string;
  status: 'Ongoing' | 'Completed';
  duration: string;
  domain: string;
}

export interface ProjectShowcase {
  id: string;
  title: string;
  brief: string;
  category: 'Embedded Systems' | 'AI' | 'IoT' | 'Robotics' | 'Communication Systems' | 'VLSI';
  students: string[];
  guide: string;
  year: number;
  outcomes: string[];
  components: string[];
  starred?: boolean;
}

export interface PlacementCompany {
  id: string;
  name: string;
  logo: string;
  offersCount: number;
  highestPackage?: string;
}

export interface AlumniStory {
  id: string;
  name: string;
  batch: string;
  designation: string;
  company: string;
  message: string;
  linkedIn?: string;
  image: string;
}

export interface NewsItem {
  id: string;
  title: string;
  date: string;
  category: 'Announcement' | 'Academic' | 'Achievement' | 'Placement' | 'Research';
  content: string;
  isUrgent?: boolean;
  link?: string;
}

export interface AcademicEvent {
  id: string;
  title: string;
  date: string;
  type: 'Symposium' | 'Workshop' | 'Seminar' | 'Conference' | 'Guest Lecture' | 'Industrial Visit';
  mode: 'Offline' | 'Online' | 'Hybrid';
  description: string;
  speakers?: string[];
  registrationOpen: boolean;
  registrationLink?: string;
  coordinator: string;
  reportLink?: string;
  image: string;
}

export interface MediaItem {
  id: string;
  title: string;
  category: 'Lab' | 'Event' | 'Project' | 'Campus';
  url: string;
  description: string;
}

export interface ResourceDownload {
  id: string;
  title: string;
  category: 'Syllabus' | 'Brochure' | 'Lab Manual' | 'Newsletter' | 'Academic Calendar';
  fileSize: string;
  format: string;
  url: string;
}
