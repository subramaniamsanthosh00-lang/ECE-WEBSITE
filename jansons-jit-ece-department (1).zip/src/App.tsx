import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

// Import Views
import HomeView from './components/views/HomeView';
import AboutView from './components/views/AboutView';
import FacultyView from './components/views/FacultyView';
import ResearchView from './components/views/ResearchView';
import LaboratoriesView from './components/views/LaboratoriesView';
import AchievementsView from './components/views/AchievementsView';
import ProjectsView from './components/views/ProjectsView';
import PlacementsView from './components/views/PlacementsView';
import EventsView from './components/views/EventsView';
import AlumniView from './components/views/AlumniView';
import GalleryView from './components/views/GalleryView';
import ContactView from './components/views/ContactView';

// Import Data for global search
import { 
  FACULTY_DATA, 
  LABORATORIES_DATA, 
  PROJECTS_SHOWCASE,
  RESEARCH_PORTFOLIO
} from './data/departmentData';

import { 
  Search, X, ArrowUpRight, ArrowRight, ShieldCheck, Mail, Cpu, BookOpen
} from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState('home');
  const [darkMode, setDarkMode] = useState(true);
  const [highContrast, setHighContrast] = useState(false);
  const [fontSize, setFontSize] = useState(100); // percentage sizing
  const [dyslexicFont, setDyslexicFont] = useState(false);

  // Global Search states
  const [globalSearchActive, setGlobalSearchActive] = useState(false);
  const [globalQuery, setGlobalQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{
    faculty: any[];
    laboratories: any[];
    projects: any[];
    publications: any[];
  }>({ faculty: [], laboratories: [], projects: [], publications: [] });

  // Native Hash-Routing controller
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.toLowerCase();
      if (hash && hash.startsWith('#/')) {
        const view = hash.replace('#/', '');
        const validViews = [
          'home', 'about', 'faculty', 'laboratories', 'research', 
          'projects', 'placements', 'achievements', 'events', 
          'alumni', 'gallery', 'contact'
        ];
        if (validViews.includes(view)) {
          setCurrentView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      } else {
        // Fallback to home hash
        window.location.hash = '#/home';
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Run initial lookup
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateToView = (view: string) => {
    window.location.hash = `#/${view}`;
  };

  // Perform Global Database scan
  const executeGlobalSearch = (term: string) => {
    if (!term.trim()) return;
    const query = term.toLowerCase();

    // Faculty matches
    const matchedFaculty = FACULTY_DATA.filter(
      fac => fac.name.toLowerCase().includes(query) || 
             fac.specialization.toLowerCase().includes(query) ||
             fac.researchAreas.some(area => area.toLowerCase().includes(query))
    );

    // Lab matches
    const matchedLabs = LABORATORIES_DATA.filter(
      lab => lab.name.toLowerCase().includes(query) || 
             lab.overview.toLowerCase().includes(query) ||
             lab.majorEquipment.some(eq => eq.name.toLowerCase().includes(query))
    );

    // Project matches
    const matchedProjects = PROJECTS_SHOWCASE.filter(
      proj => proj.title.toLowerCase().includes(query) || 
              proj.brief.toLowerCase().includes(query) ||
              proj.components.some(c => c.toLowerCase().includes(query))
    );

    // Publication matches
    const matchedPubs = RESEARCH_PORTFOLIO.publications.filter(
      pub => pub.title.toLowerCase().includes(query) || 
             pub.authors.some(a => a.toLowerCase().includes(query)) ||
             pub.journal.toLowerCase().includes(query)
    );

    setSearchResults({
      faculty: matchedFaculty,
      laboratories: matchedLabs,
      projects: matchedProjects,
      publications: matchedPubs
    });

    setGlobalQuery(term);
    setGlobalSearchActive(true);
  };

  const getSpeakSummary = () => {
    const viewSummaries: Record<string, string> = {
      home: "Welcome to Jansons ECE homepage. Here we feature our outstanding 2009 established academic frameworks, placement metrics exceeding 92%, and active center of excellence highlights.",
      about: "This is the About Department chapter. Explore our Autonomous Outcomes Based Syllabus, 12 core Program Outcomes, and strategic history progression milestones.",
      faculty: "This page is our Faculty Directory. Use filters to explore designations and specializations of our senior research guides, professor credentials, and office emails.",
      laboratories: "This is the Laboratories Directory exposing our advanced submicron VLSI CAD labs, microwave antennas benched setups, and embedded IoT hardware suites.",
      research: "Welcome to our active Research and IP registry. Review our Scopus publications, awarded and indexed patents, and consult dynamic funded projects lists.",
      projects: "This is the Pupil Capstone Projects portal. Filter between embedded and VLSI creations, examining lists of bills of materials and key design solutions.",
      placements: "This directory contains Placement Statistics. View lists of recruiters, highest compensation packages, and curricular student development programs.",
      achievements: "Welcome to Student Achievements. Discover trophies from the Smart India Hackathon, state level contest allocations, and athletic records.",
      events: "This is the Departmental Events Platform. Register for the upcoming Intelect Symposia, or specialized local workshops.",
      alumni: "Here is the Alumni networking hub. Read stories from AMD physical design leaders and Bosch specialists who mentor active cohorts.",
      gallery: "Welcome to our Media Gallery. View photographs of students testing antennas, coding microcontrollers, and organizing symposia.",
      contact: "Here is our Contact Directory. Dial our direct communication line, inspect campus maps location, or send a request dossier."
    };
    return viewSummaries[currentView] || "Welcome to Jansons Institute of Technology.";
  };

  const getViewTitle = () => {
    const titles: Record<string, string> = {
      home: "Home",
      about: "About JIT ECE",
      faculty: "Faculty Directory",
      laboratories: "Core Laboratories",
      research: "Research and Patents",
      projects: "Capstones Projects Portal",
      placements: "Placement Portal",
      achievements: "Student Achievements",
      events: "Events Platform",
      alumni: "Alumni Network",
      gallery: "Media Gallery",
      contact: "Contact and Enquiries"
    };
    return titles[currentView] || "Department Portal";
  };

  const renderActiveView = () => {
    switch (currentView) {
      case 'home':
        return <HomeView onNavigate={navigateToView} highContrast={highContrast} />;
      case 'about':
        return <AboutView highContrast={highContrast} />;
      case 'faculty':
        return <FacultyView highContrast={highContrast} />;
      case 'laboratories':
        return <LaboratoriesView highContrast={highContrast} />;
      case 'research':
        return <ResearchView highContrast={highContrast} />;
      case 'projects':
        return <ProjectsView highContrast={highContrast} />;
      case 'placements':
        return <PlacementsView highContrast={highContrast} />;
      case 'achievements':
        return <AchievementsView highContrast={highContrast} />;
      case 'events':
        return <EventsView highContrast={highContrast} />;
      case 'alumni':
        return <AlumniView highContrast={highContrast} />;
      case 'gallery':
        return <GalleryView highContrast={highContrast} />;
      case 'contact':
        return <ContactView highContrast={highContrast} />;
      default:
        return <HomeView onNavigate={navigateToView} highContrast={highContrast} />;
    }
  };

  // Determine global document visual classes
  const modeClass = darkMode ? 'dark-mode' : 'light-mode';
  const contrastClass = highContrast ? 'high-contrast' : '';

  const contrastClasses = highContrast 
    ? 'bg-black text-yellow-400 font-bold' 
    : darkMode 
      ? 'bg-[#000a16] text-slate-100' 
      : 'bg-[#f1f6fc] text-slate-900';

  const dyslexicClasses = dyslexicFont ? 'font-sans tracking-wide antialiased' : '';

  return (
    <div 
      className={`min-h-screen transition-all flex flex-col justify-between relative overflow-x-hidden ${contrastClasses} ${dyslexicClasses} ${modeClass} ${contrastClass}`}
      style={{ fontSize: `${fontSize}%` }}
      id="main-app-root"
    >
      {/* Mesh Background Glows */}
      {!highContrast && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0" aria-hidden="true">
          <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-blue-600/15 dark:bg-blue-600/10 rounded-full blur-[130px] animate-pulse"></div>
          <div className="absolute bottom-[-5%] right-[-5%] w-[400px] h-[400px] bg-cyan-500/15 dark:bg-cyan-500/10 rounded-full blur-[110px] pulse-slow"></div>
          <div className="absolute top-[30%] right-[10%] w-[350px] h-[350px] bg-indigo-600/8 dark:bg-indigo-600/5 rounded-full blur-[90px]"></div>
          <div className="absolute bottom-[20%] left-[5%] w-[300px] h-[300px] bg-purple-500/5 rounded-full blur-[80px]"></div>
        </div>
      )}
      {/* 1. Global Navigation Bar */}
      <Navbar
        currentView={currentView}
        onNavigate={navigateToView}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        highContrast={highContrast}
        onGlobalSearch={executeGlobalSearch}
      />

      {/* 2. Main Active Render View (Framed with screen borders) */}
      <main className="flex-grow" role="main" aria-label="Department Current View Content">
        {renderActiveView()}
      </main>

      {/* 3. Global Information Footer */}
      <Footer 
        onNavigate={navigateToView} 
        highContrast={highContrast} 
      />

      {/* 5. Global Omnibox Search Modal Overlay */}
      {globalSearchActive && (
        <div 
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in"
          id="global-omnibox-overlay"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-2xl bg-slate-950 border border-slate-800 rounded-2xl p-6 text-white max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-850 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Search className="w-5 h-5 text-cyan-400" />
                <h3 className="font-display font-extrabold text-base uppercase">
                  Global ECE Query Engine
                </h3>
              </div>
              <button 
                onClick={() => setGlobalSearchActive(false)}
                className="p-1 rounded-full hover:bg-slate-850"
                aria-label="Close global results"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs opacity-75 mb-4">
              Search results matching query: <strong className="text-cyan-400 select-all font-mono">"{globalQuery}"</strong>
            </p>

            <div className="space-y-6 text-xs text-left">
              {/* Faculty Matches */}
              {searchResults.faculty.length > 0 && (
                <div>
                  <span className="font-bold font-mono tracking-wider opacity-60 text-[9px] uppercase block mb-2 text-cyan-400">
                    Matched Faculty profiles ({searchResults.faculty.length})
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {searchResults.faculty.map((f) => (
                      <div 
                        key={f.id} 
                        onClick={() => { navigateToView('faculty'); setGlobalSearchActive(false); }}
                        className="p-3 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer flex gap-3"
                      >
                        <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0 bg-slate-800">
                          <img src={f.image} referrerPolicy="no-referrer" alt={f.name} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <h4 className="font-bold text-slate-200">{f.name}</h4>
                          <p className="text-[10px] opacity-70">{f.specialization}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Lab Matches */}
              {searchResults.laboratories.length > 0 && (
                <div>
                  <span className="font-bold font-mono tracking-wider opacity-60 text-[9px] uppercase block mb-2 text-pink-400">
                    Matched Laboratories ({searchResults.laboratories.length})
                  </span>
                  <div className="flex flex-col gap-2">
                    {searchResults.laboratories.map((lab) => (
                      <div 
                        key={lab.id}
                        onClick={() => { navigateToView('laboratories'); setGlobalSearchActive(false); }}
                        className="p-3 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer flex items-center justify-between"
                      >
                        <div>
                          <h4 className="font-bold text-slate-200">{lab.name}</h4>
                          <p className="text-[10px] opacity-60 truncate max-w-[400px]">Spec: {lab.overview}</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-pink-400" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Project Matches */}
              {searchResults.projects.length > 0 && (
                <div>
                  <span className="font-bold font-mono tracking-wider opacity-60 text-[9px] uppercase block mb-2 text-emerald-400">
                    Matched Capstone Projects ({searchResults.projects.length})
                  </span>
                  <div className="flex flex-col gap-2">
                    {searchResults.projects.map((proj) => (
                      <div 
                        key={proj.id}
                        onClick={() => { navigateToView('projects'); setGlobalSearchActive(false); }}
                        className="p-3 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer flex items-center justify-between animate-slide-up"
                      >
                        <div>
                          <h4 className="font-bold text-slate-200">{proj.title}</h4>
                          <p className="text-[10px] opacity-60 truncate max-w-[400px]">Material: {proj.components.join(', ')}</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-emerald-400" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Publication Matches */}
              {searchResults.publications.length > 0 && (
                <div>
                  <span className="font-bold font-mono tracking-wider opacity-60 text-[9px] uppercase block mb-2 text-indigo-400">
                    Matched Journal Publications ({searchResults.publications.length})
                  </span>
                  <div className="flex flex-col gap-2">
                    {searchResults.publications.map((pub) => (
                      <div 
                        key={pub.id}
                        onClick={() => { navigateToView('research'); setGlobalSearchActive(false); }}
                        className="p-3 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer"
                      >
                        <h4 className="font-bold text-slate-200 italic font-sans">"{pub.title}"</h4>
                        <p className="text-[10px] opacity-75 mt-0.5">Authors: {pub.authors.join(', ')}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {searchResults.faculty.length === 0 && 
               searchResults.laboratories.length === 0 && 
               searchResults.projects.length === 0 && 
               searchResults.publications.length === 0 && (
                <div className="text-center py-8 opacity-65 font-mono text-[11px] uppercase">
                  No ECE database records found matching terms. Try "VLSI" or "IoT" or "Prasath".
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
