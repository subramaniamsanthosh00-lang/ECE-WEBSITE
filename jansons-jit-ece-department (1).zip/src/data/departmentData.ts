import { 
  Faculty, 
  Laboratory, 
  Publication, 
  Patent, 
  ResearchProject, 
  ProjectShowcase, 
  PlacementCompany, 
  AlumniStory, 
  NewsItem, 
  AcademicEvent, 
  MediaItem, 
  ResourceDownload 
} from '../types';

export const DEPARTMENT_METADATA = {
  institution: "Jansons Institute of Technology",
  institutionAbbr: "JIT",
  location: "Karumathampatti, Tamil Nadu, India",
  departmentName: "Department of Electronics and Communication Engineering",
  departmentAbbr: "ECE",
  establishedYear: 2009,
  affiliation: "Autonomous Institution",
  approval: "Approved by AICTE, New Delhi",
  accreditation: "Accredited by NAAC & NBA",
  contactMail: "ece@jit.ac.in",
  contactPhone: "+91 421 2264900",
  socials: {
    facebook: "https://facebook.com/jitcoimbatore",
    twitter: "https://twitter.com/jitcoimbatore",
    instagram: "https://instagram.com/jitcoimbatore",
    linkedin: "https://linkedin.com/school/jansons-institute-of-technology/"
  }
};

export const VISION_MISSION = {
  vision: "To produce globally competent Electronics and Communication Engineers with professional ethics, research aptitude, and social responsibility to meet the evolving technological challenges.",
  mission: [
    "To impart high-quality technical education through state-of-the-art infrastructure and innovative teaching-learning methodologies.",
    "To establish research centers of excellence in emerging domains of electronic systems and communication engineering.",
    "To cultivate industry partnerships, collaborative research, and professional consulting for real-world problem solving.",
    "To enrich student development with leadership attributes, life-long learning skills, and high ethical and social values."
  ],
  peos: [
    {
      id: "PEO1",
      title: "Core Competency",
      description: "Graduates will have successful professional careers in designing, analyzing, and developing state-of-the-art products in electronics, VLSI, embedded systems, and communication sectors."
    },
    {
      id: "PEO2",
      title: "Research & Higher Studies",
      description: "Graduates will possess the technical competence to pursue advanced degrees, research activities, and professional certifications in global universities & institutions."
    },
    {
      id: "PEO3",
      title: "Societal Responsibility & Ethics",
      description: "Graduates will demonstrate technical leadership with ethical values, professional attitude, and team spirit to deliver eco-friendly engineering solutions for societal growth."
    }
  ]
};

export const FACULTY_DATA: Faculty[] = [
  {
    id: "ECE001",
    name: "Dr. G. Vetrichelvi",
    designation: "Professor & Head of Department",
    qualification: "M.E., Ph.D. (Information and Communication)",
    specialization: "Digital Signal Processing & Image Processing",
    experienceYears: 22,
    email: "hod.ece@jit.ac.in",
    researchAreas: ["Digital Image Processing", "Medical Signal Analysis", "Pattern Recognition"],
    publicationsCount: 42,
    patentsCount: 4,
    awards: ["Best Faculty Award 2024", "AICTE Research Grant Recipient", "Outstanding Academic Leader"],
    image: "",
    detailedBio: "Dr. G. Vetrichelvi has over 22 years of outstanding academic and research experience. She completed her Ph.D. under Anna University, Chennai. She has guided several research scholars and is an active reviewer for leading IEEE and Springer journals.",
    publications: [
      "An Energy Efficient Routing Metric for Heterogeneous IoT-Sensor Networks, IEEE IoT Journal, 2023.",
      "FPGA Prototype of Low-Latency Cryto-Cores for Secured RFID Communications, Microprocessors and Microsystems, 2022."
    ],
    membership: ["IEEE Senior Member", "ISTE Life Member", "IETE Fellow"]
  },
  {
    id: "ECE002",
    name: "Dr. M. Devika",
    designation: "Associate Professor",
    qualification: "M.E. (VLSI Design), Ph.D.",
    specialization: "VLSI Architecture & Digital Signal Processing",
    experienceYears: 14,
    email: "devika.m@jit.ac.in",
    researchAreas: ["Digital VLSI Design", "FPGA Accelators", "Signal & Image Processing"],
    publicationsCount: 22,
    patentsCount: 2,
    awards: ["Distinguished Researcher Award 2023", "NPTEL Gold Medalist"],
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=500&q=80",
    detailedBio: "Dr. M. Devika specializes in building hardware accelerators for image processing on FPGAs. She is passionate about mentoring student start-up projects and coordinates the VLSI Design Lab.",
    publications: [
      "Hardware Co-simulation of Deep CNN Architecture for Real-time Image Categorization, Springer Circuits and Systems, 2024.",
      "Optimized LUT Design for Low-Area Multiply-Accumulate Units, Elsevier Integration VLSI Journal, 2021."
    ],
    membership: ["ISTE Member", "IEEE Circuits and Systems Society"]
  },
  {
    id: "ECE003",
    name: "Mr. R. Dinesh Kumar",
    designation: "Assistant Professor",
    qualification: "M.E. (Applied Electronics)",
    specialization: "Embedded Systems, Robotics & IoT",
    experienceYears: 9,
    email: "dineshkumar.r@jit.ac.in",
    researchAreas: ["IoT Node Architectures", "Autonomous Micro-Robots", "Industry 4.0 Telemetry"],
    publicationsCount: 11,
    patentsCount: 1,
    awards: ["Best Mentor - Smart India Hackathon 2023", "Texas Instruments Training Champion"],
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=500&q=80",
    detailedBio: "Mr. R. Dinesh Kumar manages the Embedded Systems and IoT labs. He brings extensive expertise in microcontroller architectures (ARM Cortex, ESP32, AVR) and runs regular student workshops on soldercraft and firmware debugging.",
    publications: [
      "Low-cost Edge Computing Node for Environmental Air Telemetry, Journal of Instrumentation, 2023."
    ],
    membership: ["ISTE Life Member", "Instrumentation Society of India (ISOI)"]
  },
  {
    id: "ECE004",
    name: "Mrs. K. Priya",
    designation: "Assistant Professor",
    qualification: "M.E. (Communication Systems)",
    specialization: "RF Circuits, Antennas & Communication",
    experienceYears: 8,
    email: "priya.k@jit.ac.in",
    researchAreas: ["Microstrip Patch Antennas", "MIMO systems", "Cognitive Radio Networks"],
    publicationsCount: 8,
    patentsCount: 0,
    awards: ["Consistent Performance Award 2022", "IEEE Student Chapter Advisor"],
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=500&q=80",
    detailedBio: "Mrs. K. Priya leads RF design workshops using ANSYS HFSS. She guides students in designing compact antennas for wearable electronics and multi-band wireless receivers.",
    publications: [
      "Dual-band Microstrip Antenna for Sub-6GHz Wi-Fi and 5G Applications, Journal of Electromagnetics, 2021."
    ],
    membership: ["IEEE Antennas and Propagation Society", "IETE Associate Member"]
  }
];

export const LABORATORIES_DATA: Laboratory[] = [
  {
    id: "LAB_01",
    name: "Advanced Communication Systems Lab",
    roomNo: "LH-201",
    areaSqM: 120,
    labInCharge: "Mrs. K. Priya, M.E.",
    assistantInCharge: "Mr. M. Sakthivel",
    overview: "Equipped with advanced transmitter and receiver hardware setups operating in RF bands, enabling students to modulate, transmit, and analyze signaling waveforms. Supports microwave and optical communication paradigms.",
    learningOutcomes: [
      "Analyze the parameters of Amplitude, Frequency, and Phase modulating schemes under noise.",
      "Measure radiation parameters of horn, dipole, and microstrip antennas using microwave test benches.",
      "Understand dispersion and attenuation losses in multi-mode fiber optic cabling networks."
    ],
    majorEquipment: [
      { name: "Microwave Bench Setups (X-Band with Gunn Diode)", specs: "8.5 GHz - 12.4 GHz, Attenuator, Slotted Line", quantity: 6 },
      { name: "Optical Fiber Trainer Kits", specs: "650nm/850nm source, photodetector, analog/digital link", quantity: 12 },
      { name: "Digital Communication Trainer Kits", specs: "ASK, FSK, PSK, QPSK, PCM modulation schemes", quantity: 15 },
      { name: "Digital Storage Oscilloscopes (DSO)", specs: "100 MHz bandwidth, color TFT screen", quantity: 15 }
    ],
    experiments: [
      "Design of PAM, PWM, and PPM modulators and detectors",
      "Optical link setup, numerical aperture and attenuation loss evaluation",
      "Microwave power measurement and radiation pattern plots of horn antenna",
      "Analysis of delta modulation schemes"
    ],
    image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&q=80",
    schedule: "Monday to Thursday (09:00 AM - 04:30 PM)"
  },
  {
    id: "LAB_02",
    name: "Embedded Systems & IoT Lab",
    roomNo: "LH-203",
    areaSqM: 105,
    labInCharge: "Mr. R. Dinesh Kumar, M.E.",
    assistantInCharge: "Mrs. P. Shanthi",
    overview: "Focuses on micro-controller firmware development, real-time operating systems (RTOS), sensing networks, and high-frequency IoT connectivity. Fully integrated with embedded development toolchains.",
    learningOutcomes: [
      "Develop embedded firmware in C for 8-bit, 16-bit and 32-bit CPU architectures.",
      "Interface physical sensors and actuators with real-time feedback loops.",
      "Establish server cloud uploads via MQTT and HTTP protocols utilizing ESP32 platforms."
    ],
    majorEquipment: [
      { name: "ARM Cortex-M4 Development Platforms", specs: "STM32F4 Discovery Boards, ARM Core", quantity: 15 },
      { name: "Arduino Uno & Mega Learning Modules", specs: "Atmel ATmega328P microcontrollers", quantity: 20 },
      { name: "ESP32 Wi-Fi + BLE Microcontroller Boards", specs: "240MHz dual core, integrated antenna", quantity: 25 },
      { name: "IoT Sensor Node Shields", specs: "DHT11, MPU6050, Ultrasonic, Soil moisture", quantity: 30 }
    ],
    experiments: [
      "GPIO, interrupt, and timer configuration on STM32 boards",
      "ADC reading and DAC output waveforms with oscilloscope check",
      "Inter-integrated Circuit (I2C) bus protocol communication with sensor display",
      "Sending wireless telemetry from sensor nodes to regional dashboards"
    ],
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80",
    schedule: "Tuesday to Friday (09:00 AM - 04:30 PM)"
  },
  {
    id: "LAB_03",
    name: "VLSI & Digital Signal Processing Lab",
    roomNo: "LH-205",
    areaSqM: 110,
    labInCharge: "Dr. M. Devika, Ph.D.",
    assistantInCharge: "Mr. B. Vinoth Kumar",
    overview: "Equipped with state-of-the-art computer systems running advanced VLSI synthesis packages and DSP processing tools, enabling circuit schematic capture, RTL layout, and DSP simulation.",
    learningOutcomes: [
      "Formulate synthesizable VHDL/Verilog code for arithmetic and state machine systems.",
      "Perform physical floorplanning, placement, and routing on FPGA architectures.",
      "Design and execute FIR & IIR discrete-time digital filter models."
    ],
    majorEquipment: [
      { name: "Intel Altera / Xilinx Spartan-6 FPGA Trainer Boards", specs: "8000 logic cells, slide switches, 7-segments", quantity: 18 },
      { name: "High-End Engineering Workstations", specs: "Intel Core i7-12th Gen, 16GB RAM, 512GB SSD", quantity: 30 },
      { name: "Cadence VLSI Suite / EDA Simulation Tool Packages", specs: "Multi-user network license, physical layout tools", quantity: 30 },
      { name: "Texas Instruments TMS320C6748 DSP Kits", specs: "Floating point processor, development studio", quantity: 15 }
    ],
    experiments: [
      "Verilog Modeling of basic logic blocks, multiplexers, and 8-bit ALUs",
      "Implementation of 4-bit synchronous counter on FPGA board",
      "Synthesis of digital filter topologies in Matlab and implementation on DSP boards",
      "Layout level design of CMOS Inverter cell"
    ],
    image: "https://images.unsplash.com/photo-1555680202-c86f0e12f086?auto=format&fit=crop&w=800&q=80",
    schedule: "Monday to Friday (09:00 AM - 05:00 PM)"
  }
];

export const RESEARCH_PORTFOLIO = {
  areas: [
    {
      title: "VLSI Systems & Hardware Acceleration",
      description: "Developing low-area, high-throughput cryptographic and neural accelerators on system-on-chip (SoC) frameworks, targeting low power budgets on advanced nodes.",
      pInvestigator: "Dr. m. Devika"
    },
    {
      title: "Wearable Antennas & Sub-6GHz Networks",
      description: "Simulation and testing of microstrip patch geometries and material properties to support medical telemetry and cellular B5G (Beyond 5G) communication profiles.",
      pInvestigator: "Mrs. K. Priya"
    },
    {
      title: "Self-Powered IoT Systems & Edge Networks",
      description: "Leveraging ambient energy harvesting schemes combined with low duty cycle embedded schedulers to deploy perpetual remote environmental sensory setups.",
      pInvestigator: "Dr. G. Vetrichelvi"
    }
  ],
  publications: [
    {
      id: "PUB001",
      title: "Low power high-performance adders for IoT edge nodes utilizing CNTFET architectures",
      authors: ["G. Vetrichelvi", "M. Devika"],
      journal: "IEEE Transactions on Circuits and Systems",
      year: 2024,
      doi: "10.1109/TCSI.2024.1023849",
      category: "International Journal",
      indexing: ["Scopus", "IEEE Explore"]
    },
    {
      id: "PUB002",
      title: "Experimental realization of ultra-compact wearable textile antenna for personal telemetry",
      authors: ["K. Priya", "G. Vetrichelvi"],
      journal: "Microwave and Optical Technology Letters",
      year: 2023,
      doi: "10.1002/mop.33590",
      category: "International Journal",
      indexing: ["Web of Science", "Scopus"]
    },
    {
      id: "PUB003",
      title: "FPGA-accelerated deep network architecture for real-time robotic sorting arrays",
      authors: ["M. Devika", "R. Dinesh Kumar"],
      journal: "Journal of Real-Time Image Processing",
      year: 2022,
      doi: "10.1007/s11554-022-01188-w",
      category: "International Journal",
      indexing: ["Scopus", "Google Scholar"]
    }
  ] as Publication[],
  patents: [
    {
      id: "PAT001",
      title: "Intellectual Property for Ambient RF Harvesting Node with Multi-Band Textile Array Antenna",
      inventors: ["Dr. G. Vetrichelvi", "Mrs. K. Priya"],
      applicationNo: "202341056476A",
      status: "Published",
      year: 2023
    },
    {
      id: "PAT002",
      title: "An Area-Efficient Multiply-Accumulate Accelerator Unit for Edge Artificial Intelligence",
      inventors: ["Dr. M. Devika"],
      applicationNo: "202241038945A",
      status: "Granted",
      year: 2024
    }
  ] as Patent[],
  fundedProjects: [
    {
      id: "PROJ001",
      title: "Design of Low-Complexity Secure Cryptographic Hardware Cores for Automotive IoT Telemetry",
      pInvestigator: "Dr. G. Vetrichelvi",
      fundingAgency: "AICTE - Research Promotion Scheme (RPS)",
      amount: "Rs. 8,45,000",
      status: "Ongoing",
      duration: "3 Years (2024-2027)",
      domain: "Embedded Cyberphysical Security"
    },
    {
      id: "PROJ002",
      title: "Modernization of Digital VLSI System Design Lab with Cadence EDA Multi-Platform Support",
      pInvestigator: "Dr. M. Devika",
      fundingAgency: "AICTE - MODROBS Scheme",
      amount: "Rs. 12,50,000",
      status: "Completed",
      duration: "2 Years (2021-2023)",
      domain: "Lab Infrastructure Modernization"
    }
  ] as ResearchProject[]
};

export const PROJECTS_SHOWCASE: ProjectShowcase[] = [
  {
    id: "STUP001",
    title: "Real-Time Embedded IoT Hydrological Quality Alert Network",
    brief: "A network of self-powered remote sensors monitoring chemical and physical parameters of municipal supply, uploading data via LoRaWAN to regional hubs.",
    category: "IoT",
    students: ["M. Karthik Kumar", "R. Swetha", "S. Ajay"],
    guide: "Mr. R. Dinesh Kumar",
    year: 2024,
    outcomes: ["Successfully deployed at three local water distribution units", "Continuous battery life of 14 months using intelligent solar harvesting"],
    components: ["STM32L0 MCU", "LoRa SX1276 Node", "pH/TDS/Turbidity Probes", "Solar Cell 5V"],
    starred: true
  },
  {
    id: "STUP002",
    title: "FPGA Coprocessor for Real-Time Electrocardiogram Feature Selection",
    brief: "A high-frequency hardware architecture implemented in VHDL executing multi-band digital filtering and QRS detection waveforms on patient telemetry streams.",
    category: "VLSI",
    students: ["V. Dharshini", "K. Naveen"],
    guide: "Dr. M. Devika",
    year: 2023,
    outcomes: ["Reduced processing latency by 85% compared to software MCU setups", "Accolade at state-level project design contest"],
    components: ["Xilinx Spartan-6 Board", "VHDL Toolchains", "Instrumentation Amplifiers", "Optocoupler Isolators"]
  },
  {
    id: "STUP003",
    title: "Autonomous Warehouse Quadcopter Array with Embedded Vision Nodes",
    brief: "A small-scale drone system utilizing on-board optical flow sensors and 2.4GHz wireless control loops to traverse mapped indoor grid environments.",
    category: "Robotics",
    students: ["T. S. Gokul", "S. Hariharan", "P. Abinaya"],
    guide: "Mr. R. Dinesh Kumar",
    year: 2024,
    outcomes: ["Obstacle localization achieved under 12cm error profile", "Showcased at All-India Aviation Expo"],
    components: ["ESP32-CAM", "Brushless DC ESC drivers", "MPU6050 Gyroscope", "LiPo Batteries"],
    starred: true
  }
];

export const PLACEMENT_RECORDS = {
  placementPercentage: 92.5,
  totalOffers: 142,
  highestPackage: "12.0 LPA",
  averagePackage: "4.8 LPA",
  recruiters: [
    { id: "C001", name: "Tata Consultancy Services (TCS)", offersCount: 22, logo: "💻" },
    { id: "C002", name: "Cognizant Technology Solutions", offersCount: 18, logo: "🌐" },
    { id: "C003", name: "Jasmine Infotech", offersCount: 11, logo: "🎛️" },
    { id: "C004", name: "Soliton Technologies", offersCount: 5, logo: "🔌" },
    { id: "C005", name: "Robert Bosch Engineering", offersCount: 8, logo: "⚙️" },
    { id: "C006", name: "Wipro Electronics", offersCount: 14, logo: "📡" }
  ] as PlacementCompany[],
  trainingPrograms: [
    {
      syllabus: "Advanced Firmware Development in C/C++",
      duration: "60 Hours",
      targetYear: "Third & Final Year Candidates",
      outcomes: "Mastery in Register-Level Microcontroller programming, timers, UART, SPI, I2C, and embedded interrupts handling."
    },
    {
      syllabus: "General Aptitude & Logical Reasoning Systems",
      duration: "45 Hours",
      targetYear: "Pre-Final Year Students",
      outcomes: "Preparation for standard regional recruitment tests, logical modeling, pattern analysis, and quantitative speed tricks."
    },
    {
      syllabus: "VLSI Layout Designs & Synthesis with Cadence",
      duration: "30 Hours",
      targetYear: "Final Year Core Aspirants",
      outcomes: "Training on IC schematics, floorplanning, physical routing constraints, and Static Timing Analysis (STA)."
    }
  ]
};

export const ALUMNI_SPOTS: AlumniStory[] = [
  {
    id: "AL001",
    name: "Mr. G. Vignesh",
    batch: "Class of 2014",
    designation: "Senior ASIC Physical Design Engineer",
    company: "AMD India Pvt Ltd, Bengaluru",
    message: "The rigorous laboratory training and EDA tools focus in the JIT ECE department established the fundamental engineering knowledge that guides me every day in doing nanometer-scale chip implementation.",
    linkedIn: "https://linkedin.com",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: "AL002",
    name: "Mrs. S. Shalini",
    batch: "Class of 2017",
    designation: "Technical Lead (IoT Systems)",
    company: "Bosch Global Software Technologies",
    message: "Studying under the research mentoring program at JIT ECE cultivated my project management skills. The hackathon workshops motivated me to develop innovative solutions.",
    linkedIn: "https://linkedin.com",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80"
  },
  {
    id: "AL003",
    name: "Mr. K. R. Aravind",
    batch: "Class of 2019",
    designation: "Embedded Systems Specialist",
    company: "Soliton Technologies, Coimbatore",
    message: "The collaborative environment and the encouragement of JIT faculty to work on real-world projects made my transition from a student to an automated system test engineer highly professional.",
    linkedIn: "https://linkedin.com",
    image: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=400&q=80"
  }
];

export const NEWS_ANNOUNCEMENTS: NewsItem[] = [
  {
    id: "NW001",
    title: "Accreditation: National Board of Accreditation (NBA) peer-review visit complete",
    date: "2026-06-10",
    category: "Academic",
    content: "The expert peer-committee from the National Board of Accreditation (NBA) conducted extensive evaluation of the ECE department syllabus, OBE systems, research outcomes, and physical structures, commending our modern laboratory training setups.",
    isUrgent: true
  },
  {
    id: "NW002",
    title: "AICTE Sponsored Research Grant of Rs. 8.45 Lakhs Sanitized",
    date: "2026-06-02",
    category: "Research",
    content: "The ECE Department has secured a research development grant under the AICTE RPS scheme to design state-of-the-art secure cryptographic coprocessors for the automotive IoT sector. Dr. S. Prasath will serve as Principal Investigator.",
    isUrgent: false
  },
  {
    id: "NW003",
    title: "Recruitment Drive: Jasmine Infotech off-campus selection results declared",
    date: "2026-05-28",
    category: "Placement",
    content: "We proudly present that 11 pre-final year students from JIT ECE have successfully compiled the multi-stage embedded firmware tests and bagged offers as Graduate Engineer Trainees at Jasmine Infotech.",
    isUrgent: false
  },
  {
    id: "NW004",
    title: "Registrations Open: INTELECT 2026 - National Technical Symposium",
    date: "2026-05-15",
    category: "Announcement",
    content: "Join us on September 24, 2026 for the annual National Technical Arena, comprising Paper Spotlights, VLSI debugging, Embedded coding, Line Follower robotic arenas, and expert panels.",
    isUrgent: true
  }
];

export const ACADEMIC_EVENTS: AcademicEvent[] = [
  {
    id: "EV001",
    title: "INTELECT 2026 - National Level Technical Symposium",
    date: "2026-09-24",
    type: "Symposium",
    mode: "Offline",
    description: "An annual gathering bringing electrical and communications aspirants state-wide to showcase scientific poster prints, test digital logic debugging speed, solve firmware loops, and pit smart autonomous mobile robots.",
    speakers: ["Dr. G. Arumugam, Emeritus Professor, Anna University", "Mr. L. Venkat, Industry IoT Partner, Intel India"],
    registrationOpen: true,
    registrationLink: "#register-intelect",
    coordinator: "Mr. R. Dinesh Kumar",
    image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "EV002",
    title: "Workshop on High-Frequency RF Simulation with ANSYS HFSS",
    date: "2026-07-15",
    type: "Workshop",
    mode: "Offline",
    description: "Hands-on virtual designing of microstrip patch antennas, calculation of S-parameters, axial ratio plots, and radiation distribution modeling of compact cellular receiver designs.",
    speakers: ["Mrs. K. Priya, RF Lead", "Mr. S. Karthikeyan, Field Specialist, ANSYS India"],
    registrationOpen: true,
    registrationLink: "#register-hfss",
    coordinator: "Mrs. K. Priya",
    image: "https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "EV003",
    title: "Expert Guest Lecture on Beyond-5G & 6G Mobile Receiver Schemes",
    date: "2026-05-10",
    type: "Guest Lecture",
    mode: "Hybrid",
    description: "A professional seminar discussing millimeter wave integration, beamforming networks, cognitive spectrum sharing protocols, and low-latency digital signal recovery topologies.",
    speakers: ["Prof. Dr. Michel Wang, IEEE Fellow (Communications)"],
    registrationOpen: false,
    coordinator: "Dr. G. Vetrichelvi",
    reportLink: "#report-6g",
    image: "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?auto=format&fit=crop&w=800&q=80"
  }
];

export const MEDIA_GALLERY_DATA: MediaItem[] = [
  {
    id: "GAL001",
    title: "Students Fabricating Antenna Designs",
    category: "Lab",
    url: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=800&q=80",
    description: "Hands-on measurement of wearable textiles on the microwave antenna bench."
  },
  {
    id: "GAL002",
    title: "Hands-on Embedded RTOS Workshop Session",
    category: "Event",
    url: "https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=800&q=80",
    description: "Firmware optimization checks on the ARM Cortex discovery boards."
  },
  {
    id: "GAL003",
    title: "Industrial Visit to Jasmine Infotech Facility, Chennai",
    category: "Event",
    url: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=80",
    description: "Third year undergraduate students interaction with core embedded engineering testbeds."
  },
  {
    id: "GAL004",
    title: "Embedded Hydrology IoT Node Prototype Assembly",
    category: "Project",
    url: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80",
    description: "Vetted deployment checks on remote water monitoring sensor clusters."
  },
  {
    id: "GAL005",
    title: "Cadence VLSI Chip Layout Session",
    category: "Lab",
    url: "https://images.unsplash.com/photo-1555680202-c86f0e12f086?auto=format&fit=crop&w=800&q=80",
    description: "Students designing transistor floorplanning for submicron circuits."
  },
  {
    id: "GAL006",
    title: "Annual JIT Tech Expo - ECE Department Pavilion",
    category: "Campus",
    url: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80",
    description: "Showcasing student-designed quadcopters and sensory node configurations."
  }
];

export const DOWNLOADS_DATA: ResourceDownload[] = [
  {
    id: "DL001",
    title: "Anna University Regulation 2021 ECE Curriculum & Syllabi Brochure",
    category: "Syllabus",
    fileSize: "1.4 MB",
    format: "PDF",
    url: "#syllabi-reg-22021"
  },
  {
    id: "DL002",
    title: "JIT ECE Department Information and Placement Prospectus 2026",
    category: "Brochure",
    fileSize: "4.2 MB",
    format: "PDF",
    url: "#department-brochure-2026"
  },
  {
    id: "DL003",
    title: "Lab Manual: EC3491-Communication Systems Laboratory Framework",
    category: "Lab Manual",
    fileSize: "2.8 MB",
    format: "PDF",
    url: "#communication-lab-manual"
  },
  {
    id: "DL004",
    title: "SENDER: Academic News bulletin - Vol 14, Issue 1 (June 2026)",
    category: "Newsletter",
    fileSize: "3.1 MB",
    format: "PDF",
    url: "#newsletter-sender-062026"
  }
];
